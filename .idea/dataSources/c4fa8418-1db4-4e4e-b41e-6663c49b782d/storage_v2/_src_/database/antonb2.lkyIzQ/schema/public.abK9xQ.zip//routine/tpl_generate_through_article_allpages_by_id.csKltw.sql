create function tpl_generate_through_article_allpages_by_id(integer) returns boolean
  language plpgsql
as
$$
DECLARE 
  articleId alias for $1; 
  rec record; 
BEGIN 
    FOR rec IN select * from page LOOP     
        perform tpl_generate_article_through_by_id(rec.id, articleId);
    END LOOP;
    return true;
END;
$$;

alter function tpl_generate_through_article_allpages_by_id(integer) owner to antonb2;

