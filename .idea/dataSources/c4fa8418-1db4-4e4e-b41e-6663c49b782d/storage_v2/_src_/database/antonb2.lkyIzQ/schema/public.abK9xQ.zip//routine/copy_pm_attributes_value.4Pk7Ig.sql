create function copy_pm_attributes_value() returns boolean
  strict
  language plpgsql
as
$$
declare
 rec record;
begin
for rec in select * from pm_attribute_value where type_id=291 loop
    update pm_attribute_value set real_value=rec.real_value where type_id=73 and product_id=rec.product_id;
end loop;
return null;
end
$$;

alter function copy_pm_attributes_value() owner to antonb2;

