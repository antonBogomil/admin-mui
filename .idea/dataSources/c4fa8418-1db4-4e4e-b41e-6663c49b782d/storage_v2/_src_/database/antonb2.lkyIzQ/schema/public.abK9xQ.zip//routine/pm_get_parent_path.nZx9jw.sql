create function pm_get_parent_path(bigint, bigint, bigint) returns SETOF pm_path
  language plpgsql
as
$$
DECLARE
  catId alias for $1;
  rootId alias for $2;
  langId alias for $3;
  
  categoryRd RECORD; 
  parentId integer := -1;
  was_found boolean := false;
BEGIN
  parentId := catId;
  WHILE (parentId IS NOT null) OR (parentId != rootId) LOOP
      
      FOR categoryRd IN SELECT pm_category.id, COALESCE(title_rs.text, rs_title) , parent_id FROM pm_category 
      LEFT JOIN string_resource AS title_rs 
      ON (rs_title = title_rs.id AND title_rs.lang_id=langId) 
      WHERE pm_category.id=parentId 
      LOOP
    parentId := categoryRd.parent_id; 
    RETURN NEXT categoryRd;
    was_found := true;
      END LOOP;

      IF was_found THEN
    was_found := false;
      ELSE 
    EXIT;
            END IF;
  END LOOP;
  
  RETURN;
END;
$$;

alter function pm_get_parent_path(bigint, bigint, bigint) owner to antonb2;

