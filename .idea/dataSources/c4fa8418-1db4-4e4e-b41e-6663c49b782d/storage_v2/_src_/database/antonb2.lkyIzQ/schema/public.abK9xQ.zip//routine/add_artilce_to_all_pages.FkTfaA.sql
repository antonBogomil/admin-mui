create function add_artilce_to_all_pages() returns boolean
  language plpgsql
as
$$
  /* New function body */
declare
  rec record;
  articleId int4;
begin
    for rec in select * from page  where lang_id=2 and id!=13 loop
        perform tpl_generate_article_by_id(rec.id, 2601);

    end loop;
  return true;
end;
$$;

alter function add_artilce_to_all_pages() owner to antonb2;

