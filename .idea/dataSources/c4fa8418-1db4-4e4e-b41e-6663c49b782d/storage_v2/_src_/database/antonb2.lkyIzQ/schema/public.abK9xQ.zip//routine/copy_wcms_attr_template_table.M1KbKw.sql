create function copy_wcms_attr_template_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;       	
    
	for rec in select * from wcms_attr_template1 loop
    	INSERT into wcms_attr_template(wcms_templ_id, name, is_mandatory, comment)
			values (rec.wcms_templ_id, rec.name, rec.is_mandatory, rec.comment);
		n:=n+1;
    end loop;

    return n;
END;
$$;

alter function copy_wcms_attr_template_table() owner to antonb2;

