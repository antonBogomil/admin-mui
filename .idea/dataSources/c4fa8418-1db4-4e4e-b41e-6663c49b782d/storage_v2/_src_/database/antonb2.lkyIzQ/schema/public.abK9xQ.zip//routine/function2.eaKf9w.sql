create function function2() returns boolean
  language plpgsql
as
$$
  /* New function body */
declare
i integer;
begin
for i in 1..(select max(id) from page where lang_id=1)
loop
           insert into article(lang_id, head, text) values(1,'','Page is under construction');
end loop;
return true;
end
$$;

alter function function2() owner to antonb2;

