create function function7() returns boolean
  language plpgsql
as
$$
declare
  rec record;
begin
    for rec in select * from page WHERE attribute_set_id IS NULL  loop
	    INSERT INTO images_set
               VALUES(nextval('images_set_image_set_id_seq'), 'simple', Null, Null, Null, Null, Null, Null, NULL);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/deuren.jpg', Null, Null, Null, Null, Null, 520,690,1);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/galley.jpg', Null, Null, Null, Null, Null, 520,690,2);
                       INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/houten_dekken.jpg', Null, Null, Null, Null, Null, 520,690,3);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/isolatie.jpg', Null, Null, Null, Null, Null, 520,690,4);
                       INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/meubels.jpg', Null, Null, Null, Null, Null, 520,690,5);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/offshore.jpg', Null, Null, Null, Null, Null, 520,690,6);
                       INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/plafond.jpg', Null, Null, Null, Null, Null, 520,690,7);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/polyester.jpg', Null, Null, Null, Null, Null, 520,690,8);
                       INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/vloer.jpg', Null, Null, Null, Null, Null, 520,690,9);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/front_slider/wetunit.jpg', Null, Null, Null, Null, Null, 520,690,10);
               
        UPDATE page SET attribute_set_id=(SELECT MAX(image_set_id) FROM images_set LIMIT 1) WHERE id=rec.id;
        INSERT INTO wcms_attribute_set VALUES (nextval('wcms_attribute_set_wcms_attribute_set_id_seq'), Null);        
        INSERT INTO wcms_attribute VALUES (nextval('wcms_attribute_wcms_attr_id_seq'), 1, '',(SELECT MAX(image_set_id) FROM images_set LIMIT 1), (SELECT MAX(wcms_attribute_set_id) FROM wcms_attribute_set LIMIT 1), Null, 'animation');
        INSERT INTO animation_properties values (nextval('animation_properties_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1));
    end loop;
  return true;
end;
$$;

alter function function7() owner to antonb2;

