create function add_downloads() returns boolean
  language plpgsql
as
$$
  /* New function body */
Declare
i integer;
rec record;

Begin
 for rec in select * from pm_category
     loop
         if rec.downloads is null then
            update pm_category set downloads = 'pm_category2:'||rec.id  where id = rec.id;
            for i in 1 .. 3 loop
                insert into string_resource (id, lang_id, text)
                   values( 'pm_category2:'||rec.id , i, '');
            end loop;
         end if;
     end loop;
return true;
end
$$;

alter function add_downloads() owner to antonb2;

