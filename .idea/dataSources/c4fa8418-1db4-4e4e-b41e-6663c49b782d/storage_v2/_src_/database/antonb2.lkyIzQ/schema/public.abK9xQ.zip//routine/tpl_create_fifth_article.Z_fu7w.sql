create function tpl_create_fifth_article(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, langId, '', '<table width=847 height=421 border=0 cellpadding=0 cellspacing=0><tr><td colspan=3 width=847 height=19><img src=/site/images/spacer.gif width=847 height=19 /></td></tr><tr><td rowspan=4 width=565 height=380 class=contentFirst>Page is under construction</td><td rowspan="4" width="1" height="380" class=bgTop><img src=/site/images/spacer.gif width=1 height=380 /></td><td width="281" height=1><img src=/site/images/line.gif width=281 height=1 /></td></tr><tr><td width="281" height=25 class=bgTempHeader><div class=headerTemp>Wist u dat?</div></td></tr><tr><td width=281 height=1><img src=/site/images/line.gif width=281 height=1 /></td></tr><tr><td width=281 height=353 class=rightWist><p>Some link  <a href=http://>lees meer >>></a></p></td></tr><tr><td colspan=3 width=847 height=22><img src=/site/images/spacer.gif width=847 height=22 /></td></tr></table>
    ');
    return articleId;
end;
$$;

alter function tpl_create_fifth_article(integer) owner to antonb2;

