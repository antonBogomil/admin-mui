create function tpl_add_nearest_event_module(integer) returns integer
  language plpgsql
as
$$
declare
	    pageId alias for $1;
	begin
		insert into page_component
			(page_id, class_name) values (pageId, 'near-events-component');
		return pageId;
	end;
$$;

alter function tpl_add_nearest_event_module(integer) owner to antonb2;

