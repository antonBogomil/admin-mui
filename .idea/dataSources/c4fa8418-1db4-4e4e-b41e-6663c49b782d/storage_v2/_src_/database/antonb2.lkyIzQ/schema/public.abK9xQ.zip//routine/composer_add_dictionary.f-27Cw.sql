create function composer_add_dictionary(character varying) returns integer
  language plpgsql
as
$$
DECLARE
    pageName alias for $1;
    alphabet_count varchar:= 0;
    PAGE_CLASS varchar := 'glossary_module';
    addRet int;
BEGIN
    SELECT add_standard_component(pageName, 'glossary-component', PAGE_CLASS) INTO addRet;

    IF addRet=-1 THEN
        RETURN -1;
    END IF;


    SELECT INTO alphabet_count count(*) FROM d_alphabet ;

    if alphabet_count = 0 then
        --Alphabet
        INSERT INTO d_alphabet ("letter") VALUES ('A');
        INSERT INTO d_alphabet ("letter") VALUES ('B');
        INSERT INTO d_alphabet ("letter") VALUES ('C');
        INSERT INTO d_alphabet ("letter") VALUES ('D');
        INSERT INTO d_alphabet ("letter") VALUES ('E');
        INSERT INTO d_alphabet ("letter") VALUES ('F');
        INSERT INTO d_alphabet ("letter") VALUES ('G');
        INSERT INTO d_alphabet ("letter") VALUES ('H');
        INSERT INTO d_alphabet ("letter") VALUES ('I');
        INSERT INTO d_alphabet ("letter") VALUES ('J');
        INSERT INTO d_alphabet ("letter") VALUES ('K');
        INSERT INTO d_alphabet ("letter") VALUES ('L');
        INSERT INTO d_alphabet ("letter") VALUES ('M');
        INSERT INTO d_alphabet ("letter") VALUES ('N');
        INSERT INTO d_alphabet ("letter") VALUES ('O');
        INSERT INTO d_alphabet ("letter") VALUES ('P');
        INSERT INTO d_alphabet ("letter") VALUES ('Q');
        INSERT INTO d_alphabet ("letter") VALUES ('R');
        INSERT INTO d_alphabet ("letter") VALUES ('S');
        INSERT INTO d_alphabet ("letter") VALUES ('T');
        INSERT INTO d_alphabet ("letter") VALUES ('U');
        INSERT INTO d_alphabet ("letter") VALUES ('V');
        INSERT INTO d_alphabet ("letter") VALUES ('W');
        INSERT INTO d_alphabet ("letter") VALUES ('X');
        INSERT INTO d_alphabet ("letter") VALUES ('Y');
        INSERT INTO d_alphabet ("letter") VALUES ('Z');
    end if;

  RETURN 1;
END;
$$;

alter function composer_add_dictionary(varchar) owner to antonb2;

