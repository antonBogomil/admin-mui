create function add_component_to_pages() returns boolean
  strict
  language plpgsql
as
$$
declare
 rec record;
begin
for rec in select * from page where id!=58 loop
    insert into page_component(page_id,class_name) values (rec.id,'job-module-component');    
end loop;
return null;
end
$$;

alter function add_component_to_pages() owner to antonb2;

