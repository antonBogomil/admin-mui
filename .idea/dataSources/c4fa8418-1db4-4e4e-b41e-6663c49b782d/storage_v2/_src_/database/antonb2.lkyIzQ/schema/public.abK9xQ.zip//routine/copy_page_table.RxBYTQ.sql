create function copy_page_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;	
    	n1 integer:=0;	
	containerId integer;
    visible_param boolean;
    page_id_param integer;
    component_id_param integer;	
    rec record;
    rec1 record;
    rec2 record;
BEGIN
	n:=0;    
    visible_param:=false;

    delete from page_component_params;
   	delete from page_component;
    delete from page;
    
    for rec in (select * from page1) loop
		if (rec.visible = 1) then
	        visible_param:=true;        
        end if;
		
		if (rec.container_id is null) then
	        select id into containerId from containers where name = 'Default'; 
            n1:=n1+1;       
        end if;
		
    	INSERT into page(lang_id, filename, title, contents, class, category, last_modified, 
						 protected, publish_date, expired_date, visible, container_id, 
						 attribute_set_id, site_id, meta_description, meta_keywords, property_name, 
						 property_value, google_script, is_search,
						 is_sitemap, sitemap_prior, sitemap_freq						 
                        )
			values (rec.lang_id, rec.filename, rec.title, rec.contents, rec.class, rec.category, rec.last_modified, 
					rec.protected, rec.publish_date, rec.expired_date, visible_param, containerId, rec.attribute_set_id, 
					1, null, null, null, null, true, true, true, '0.5', 'DAILY'
                   );

		select max(id) into page_id_param from page;
        for rec1 in (select * from page_element1 where page_id = rec.id) loop
              INSERT into page_component(page_id, class_name)
                  values (page_id_param, rec1.class_name);
              select max(id) into component_id_param from page_component;
         	
              for rec2 in (select * from page_element_params1 where element_id = rec1.id) loop        
                  INSERT into page_component_params(element_id, name, value)
                      values (component_id_param, rec2.name, rec2.value);
	    	end loop;
	    end loop;
    
    	n:=n+1;

    end loop;
    return n1;
END;
$$;

alter function copy_page_table() owner to antonb2;

