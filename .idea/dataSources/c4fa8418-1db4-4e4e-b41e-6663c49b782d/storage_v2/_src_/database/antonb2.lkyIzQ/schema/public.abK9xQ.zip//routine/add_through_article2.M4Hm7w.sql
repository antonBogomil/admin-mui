create function add_through_article2() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  articleId integer := -1;
  curLang INTEGER := -1;
BEGIN
  
 	FOR rec in  select * from page where class = 'pr' order by lang_id asc loop
    if (curLang <> rec.lang_id) then
    	curLang := rec.lang_id;
    	SELECT nextval('article_id_seq') INTO articleId;
        INSERT INTO article (id, lang_id, head, text, class)
        VALUES (articleId, curLang, 'login', '<p>If you don''t have a Negeso portal account please run registration wizard</p>
        <p>If you would like to try the Negeso/SEO tools, please run the SEO registration wizard</p>', NULL);
    END if;
    
    
    perform tpl_generate_article_through_by_id(rec.id, articleId);
  end loop;
  return true;
END;
$$;

alter function add_through_article2() owner to antonb2;

