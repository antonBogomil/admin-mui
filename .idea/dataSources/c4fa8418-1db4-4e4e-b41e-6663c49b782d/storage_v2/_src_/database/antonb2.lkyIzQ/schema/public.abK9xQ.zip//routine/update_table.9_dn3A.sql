create function update_table() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  langId int4;  
begin	
  for rec in select * from dictionary_old loop
  	IF (select (count(id)=0) from dictionary where dictionary.entry_id=rec.entry_id and dictionary.lang_code=rec.lang_code) THEN
    	INSERT INTO dictionary(dictionary_file_id, entry_id, lang_code, entry) 
        	VALUES(rec.dictionary_file_id, rec.entry_id, rec.lang_code, rec.entry);
	END IF;
  end loop;
  return true;
end;
$$;

alter function update_table() owner to antonb2;

