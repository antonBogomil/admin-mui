create function add_article_to_page(integer, integer) returns boolean
  language plpgsql
as
$$
declare
  pageId alias for $1;
  articleId alias for $2;
begin
    perform tpl_generate_article_by_id(pageId, articleId);
  	return TRUE;
end;
$$;

alter function add_article_to_page(integer, integer) owner to antonb2;

