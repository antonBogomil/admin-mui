create function add_through_article_to_page("pageId" integer, "articleId" integer) returns boolean
  strict
  language plpgsql
as
$$
DECLARE
  pageId alias for $1;
  articleId alias for $2;
BEGIN    
	perform tpl_generate_article_through_by_id(pageId, articleId);
    return true;
END;
$$;

alter function add_through_article_to_page(integer, integer) owner to antonb2;

