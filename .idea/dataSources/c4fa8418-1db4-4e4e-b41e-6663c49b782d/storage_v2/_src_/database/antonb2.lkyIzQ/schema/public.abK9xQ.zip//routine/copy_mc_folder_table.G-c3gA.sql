create function copy_mc_folder_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
    
	delete from dc_category;
	delete from mc_folder;
	
   	for rec in select * from mc_folder1 loop
    	INSERT into mc_folder(id, path, container_id, site_id)
			values (rec.id, rec.path, rec.container_id, 1);
		n:=n+1;
	end loop;
    
    INSERT into dc_category(id, name, mc_folder_id, order_number, site_id) values(1, 'Root category', 1,1,1);

    return n;
END;
$$;

alter function copy_mc_folder_table() owner to antonb2;

