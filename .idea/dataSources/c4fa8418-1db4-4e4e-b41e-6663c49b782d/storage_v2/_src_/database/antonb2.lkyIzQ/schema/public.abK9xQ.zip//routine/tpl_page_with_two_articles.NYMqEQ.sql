create function tpl_page_with_two_articles(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    articleId int4;
begin
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    return 1;
end;
$$;

alter function tpl_page_with_two_articles(integer) owner to antonb2;

