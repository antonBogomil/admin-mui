create function add_pict_frame() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
  for rec in select * from image loop
      if (rec.image_set_id < 96 or rec.image_set_id > 101) and rec.image_set_id != 1 and rec.image_id < 300  then
         INSERT INTO image VALUES(nextval('image_image_id_seq'), rec.image_set_id,rec.src, Null, Null,Null, Null, Null, 350, 284,2);
         INSERT INTO image VALUES(nextval('image_image_id_seq'), rec.image_set_id,rec.src, Null, Null,Null, Null, Null, 350, 284,3);
      end if;
  end loop;
  return true;
end;
$$;

alter function add_pict_frame() owner to antonb2;

