create function add_list_to_all_pages() returns integer
  language plpgsql
as
$$
declare
  rec record;
begin
 for rec in select * from page loop
    IF rec.lang_id = 1 THEN
      perform tpl_generate_list_by_id(rec.id, 3);
    END IF;	
    IF rec.lang_id = 2 THEN
      perform tpl_generate_list_by_id(rec.id, 1);
    END IF;
  end loop;
  return 1;
end;
$$;

alter function add_list_to_all_pages() owner to antonb2;

