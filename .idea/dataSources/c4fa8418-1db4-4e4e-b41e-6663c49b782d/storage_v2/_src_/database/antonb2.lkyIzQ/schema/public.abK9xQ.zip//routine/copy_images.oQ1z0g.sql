create function copy_images() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;    
   	delete from image; 
  	delete from images_set;
   	delete from wcms_attribute;
   	delete from wcms_attribute_set;
    delete from wcms_attr_template;
    
    for rec in select * from images_set1 loop
    	INSERT into images_set(image_set_id, name, required_width, required_height, 
        					max_width, max_height, min_height, min_width, 
                            number_of_images)
			values (rec.image_set_id, name, rec.required_width, rec.required_height, 
            		rec.max_width, rec.max_height, rec.min_height, rec.min_width, 
                    rec.number_of_images);
    	n:=n+1;
    end loop;

	for rec in select * from image1 loop
    	INSERT into image(image_id, image_set_id, src, alt, max_width, max_height, 
        				  min_width, min_height, required_height, required_width, 
                          _order)
			values (rec.image_id, rec.image_set_id, rec.src, rec.alt, 
            		rec.max_width, rec.max_height, rec.min_width, rec.min_height, 
                    rec.required_height, rec.required_width, rec._order);
    end loop;
    
  	for rec in select * from wcms_attr_template1 loop
    	INSERT into wcms_attr_template(wcms_templ_id, name, is_mandatory, comment)
			values (rec.wcms_templ_id, rec.name, rec.is_mandatory, rec.comment);
    end loop;
    
   	for rec in select * from wcms_attribute_set1 loop
    	INSERT into wcms_attribute_set(wcms_attribute_set_id, wcms_templ_id)
			values (rec.wcms_attribute_set_id, rec.wcms_templ_id);
    end loop;
    
   	for rec in select * from wcms_attribute1 loop
    	INSERT into wcms_attribute(wcms_attr_id, wcms_attr_type_id, name, image_set_id, 
        				  wcms_attribute_set_id, str_value, class)
			values (rec.wcms_attr_id, rec.wcms_attr_type_id, rec.name, 
            		rec.image_set_id, rec.wcms_attribute_set_id, rec.str_value, 
                    rec.class);
    end loop;

    return n;
END;
$$;

alter function copy_images() owner to antonb2;

