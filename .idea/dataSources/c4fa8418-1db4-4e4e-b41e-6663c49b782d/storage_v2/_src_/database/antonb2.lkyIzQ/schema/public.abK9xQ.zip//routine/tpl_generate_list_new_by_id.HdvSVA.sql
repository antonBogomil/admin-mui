create function tpl_generate_list_new_by_id(integer, integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    listId alias for $2;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;

        
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'list-component');
       
    insert into page_component_params
        (element_id, name, value) values
        (pageElemId, 'listId', listId);
    return pageElemId;
end;
$$;

alter function tpl_generate_list_new_by_id(integer, integer) owner to antonb2;

