create function tpl_add_webpoll_module(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    pcId int4;
    pcId2 int4;
    langId int4;
    tmpId int4;
begin
	SELECT lang_id INTO langId FROM page WHERE id=pageId;
    SELECT nextval('page_component_id_seq') INTO pcId;
    INSERT INTO page_component (id, page_id, class_name)
    VALUES (pcId, pageId, 'poll-result-component');
   
    	INSERT INTO page_component_params (element_id, name, value) 
    	VALUES (pcId, 'listId', 8);
   
    SELECT setval('page_component_id_seq', pcId+1) INTO tmpId;
    
    SELECT nextval('page_component_id_seq') INTO pcId2;
    INSERT INTO page_component (id, page_id, class_name)
    VALUES (pcId2, pageId, 'poll-component');
  
    	INSERT INTO page_component_params (element_id, name, value) 
    	VALUES (pcId2, 'listId', 8);
   

    return pcId;
end;
$$;

alter function tpl_add_webpoll_module(integer) owner to antonb2;

