create function fix_export1() returns integer
  language plpgsql
as
$$
DECLARE
  rec record;
  i int4;
BEGIN
  i:=0;
  for rec in SELECT * FROM nl_subscriber where NOT EXISTS     
(select nl_subscription.subscriber_id from nl_subscription where nl_subscriber.id=nl_subscription.subscriber_id) loop
    insert into nl_subscription(subscriber_id,lang_id,category_id,is_html) values(rec.id,1,3,1);
i=i+1;
  end loop;
  return i;
END;
$$;

alter function fix_export1() owner to antonb2;

