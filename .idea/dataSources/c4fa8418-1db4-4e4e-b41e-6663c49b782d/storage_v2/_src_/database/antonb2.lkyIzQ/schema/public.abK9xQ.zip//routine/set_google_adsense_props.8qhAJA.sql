create function set_google_adsense_props() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
  for rec in select id from site loop
	    INSERT INTO core_property(module_id, name, value, title, site_id, required, visible) values
        ((select id from module where name = 'google_analytics' and site_id = rec.id),
         'google_adsense_client_code',
         '',
         'GOOGLE_ADSENSE_CLIENT_CODE',
         rec.id,
         false,
         true);
         INSERT INTO core_property(module_id, name, value, title, site_id, required, visible) values
        ((select id from module where name = 'google_analytics' and id = rec.id),
         'google_adsense_script_template',
         '<script type=\"text/javascript\">google_ad_client = \"pub-\";google_ad_slot = \"5200582458\";google_ad_width = 728;google_ad_height = 90;</script><script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"></script>',
         '',
         rec.id,
         true,
         false);
  end loop;
	return true;
END;
$$;

alter function set_google_adsense_props() owner to antonb2;

