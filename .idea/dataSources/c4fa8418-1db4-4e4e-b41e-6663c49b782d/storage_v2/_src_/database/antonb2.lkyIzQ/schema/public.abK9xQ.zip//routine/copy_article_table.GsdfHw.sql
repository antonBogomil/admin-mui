create function copy_article_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;    
   	delete from forms;
   	delete from article;
    
    for rec in select * from article1 loop
    	INSERT into article(id, lang_id, head, text, class, container_id)
			values (rec.id, rec.lang_id, rec.head, rec.text, rec.class, rec.container_id);
    	n:=n+1;
    end loop;
	
	for rec in select * from forms1 loop
    	INSERT into forms(id, lang_id, article_id, site_id, form_id, name, description, email, creation_date, last_modification_date, ex)
			values (rec.id, rec.lang_id, rec.article_id, 1, rec.form_id, rec.name, rec.description, rec.email, rec.creation_date, rec.last_modification_date, '');
    end loop;
	
    return n;
END;
$$;

alter function copy_article_table() owner to antonb2;

