create function dc_sample() returns integer
  language plpgsql
as
$$
declare
    rootCategoryId int4 :=1;
    categoryId int4 :=1;
    documentId int4 :=1;
    categoryXId int4 :=1;
    mcFolderId int4 :=1;
begin
    -- --------------------------------SETUP ROOT FOLDER/CATEGORY ------------
  -- SELECT id FROM dc_category INTO rootCategoryId WHERE parent_id = NULL;
    
    -- -------------------------------- ROOT FOLDER CONTENTS ------------
  -- categories
  -- f1
  mcFolderId = mc_create_folder('media/documents/orders/', NULL);
  
  SELECT nextval('dc_category_id_seq') INTO categoryId;
    INSERT INTO dc_category(id, name, mc_folder_id, parent_id) 
      VALUES(categoryId, 'orders', mcFolderId, rootCategoryId);

  -- f2
  mcFolderId = mc_create_folder('media/documents/reports/', NULL);
    
  SELECT nextval('dc_category_id_seq') INTO categoryId;
    INSERT INTO dc_category(id, name, mc_folder_id, parent_id) 
      VALUES(categoryId, 'reports', mcFolderId, rootCategoryId);

  -- f3
  mcFolderId = mc_create_folder('media/documents/screenplays/', NULL);
    
  SELECT nextval('dc_category_id_seq') INTO categoryXId;
    INSERT INTO dc_category(id, name, mc_folder_id, parent_id) 
      VALUES(categoryXId, 'screenplays', mcFolderId, rootCategoryId);

  -- documents
  SELECT nextval('dc_document_id_seq') INTO documentId;
    INSERT INTO dc_document(id, name, category_id, document_link, description, owner, last_modified) 
      VALUES(documentId, 'my_summer_vacation.doc', rootCategoryId, 'media/folder1/asd.doc', 'LA-LA-LA', 'Lexa', now());

  SELECT nextval('dc_document_id_seq') INTO documentId;
    INSERT INTO dc_document(id, name, category_id, document_link, description, owner, last_modified) 
      VALUES(documentId, 'bobbys_requiem.doc', rootCategoryId, 'media/folder1/asd.doc', 'Chunga-changa', 'Bobby', now());


  -- f3
  mcFolderId = mc_create_folder('media/documents/screenplays/terminator/', 1);
    
  SELECT nextval('dc_category_id_seq') INTO categoryId;
    INSERT INTO dc_category(id, name, mc_folder_id, parent_id) 
      VALUES(categoryId, 'terminator', mcFolderId, categoryXId);

  SELECT nextval('dc_document_id_seq') INTO documentId;
    INSERT INTO dc_document(id, name, category_id, document_link, description, owner, last_modified) 
      VALUES(documentId, 'terminator_II_db_schema.mdb', categoryXId, 'media/folder1/asd.doc', 'Top-secret, for real dudes only', 'Flint', now());

    return 1;
end;
$$;

alter function dc_sample() owner to antonb2;

