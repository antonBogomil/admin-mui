create function tpl_create_gb_id(integer) returns integer
  language plpgsql
as
$$
declare 
 pageId alias for $1;
 siteId int4;
 gbId int4; 
 posted timestamp := now();
begin   
	select site_id into siteId  from page where id=pageId;
    select min(id) into gbId from guestbook_enumerator where site_id = siteId;
    if gbId is not null then
    	return gbId;
    end if;
	select nextval('public.guestbook_enumerator_id_seq') into gbId; 
	INSERT INTO guestbook_enumerator (id, name, site_id)
		VALUES (gbId, 'Guest book', siteId) ; 
    return gbId;
end;
$$;

alter function tpl_create_gb_id(integer) owner to antonb2;

