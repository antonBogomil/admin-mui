create function job_sample() returns integer
  language plpgsql
as
$$
declare
    deptId int4 :=1;
    articleId int4 :=1;
    langId int4 :=1;
    vacancyId int4 :=1;
    fieldTypeId int4 :=1;
    stringId int4 :=1;

    jTechTypeId int4 :=1;

    applicationId int4 :=1;

    fieldId int4 :=1;

    -- constatnts
  GENERAL_DEPT_ID integer := 1;
  
    genTmp int4 :=1;
    
begin
    SELECT * FROM job_insert_menu(5, 1) INTO genTmp;
    SELECT * FROM job_insert_menu(17, 2) INTO genTmp;
    -- ----------------------------------------------Departments
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Sales', 'sales@negeso.com', 'Saling managers and technologiesn live here');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Software development', 'it@negeso.com', 'Software development');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Human resources', 'pr@negeso.com', 'Humain resources management and planning');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Analytics & statistics', 'sales@negeso.com', 'Analytic research and statistics colections');


    -- Java technology
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO jTechTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (jTechTypeId, 'check_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Java technology');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Java technology_nl');

    -- Servlets option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Servlets');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Servlets');

    -- JSP option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Java Server Pages (JSP)');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Java Server Pages (JSP)_nl');

    -- EJB option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Enterprise Java Beans (EJB)');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Enterprise Java Beans (EJB)_nl');

    -- ------------------------------------------------Vacancies
    -- Information manager
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', '
    Experience Capable of handling projects with minimum directions and supervision and must have the following abilities: Technical -technical review and evaluation of material & subcontractors -value engineering -quality control -safety audit & review Commercial -contracts administration -valuations -variations Project management -planning & scheduling -sub-contractors administration Management -leadership quality -internal & external people management Report directly to Executive Director and carry out the full range of professional tasks and services to meet client requirements to the highest standa - * - * - * - Please apply to: James Bond james.bond@negeso.com. Engineering job search for Engineering Services Manager Building Services Manager 
    ', 'job');
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Information manager', articleId, 'Project manager', '500', '3', now(), NULL, 2);


    -- IT department vacancy
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', '
      To apply you will need to have at least 4 years development experience working on dynamic, highly technical Java applications. You will have development experience in JSP, Servlets, Custom tags, Struts, CVS, XML and Tomcat working within Object Oriented Analysis and design. Any experience of RUP, UML, EJB and the J2EE environment a strong benefit. Ideally you will also have knowledge of Unix / Linux environments. Team leading experience is a distinct advantage along with strong communication skills and a strong, relevant academic background. They offer a young, dynamic, highly thought of development team / environment and cutting edge projects. Excellent opportunities to grow with the company and build on your career as they expand. Huntress Search Ltd is acting as an Employment Agency in relation to this vacancy. - IT job search for Java Development Team Leader
    ', 'job'
  );
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Java Development Team Leader', articleId, NULL, '500', '3', now(), NULL, 3);

  SELECT nextval('job_extra_fields_id_seq') INTO fieldId;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id) 
      VALUES (fieldId, jTechTypeId, 0, vacancyId);


    -- ------------------------------------------------Application
    -- general application
  SELECT nextval('job_applications_id_seq') INTO applicationId;
    INSERT INTO job_applications (id, name, surname, address, telephone, mobile, email, birthdate, birthplace, citizenship, cv, post_date)
        VALUES (applicationId, 'Jonny', 'Smith', 'New Avenu 115', '8-800-287-99-00', NULL, 'jonny@negeso.com', '1980-01-03','New-York', 'Washington', NULL, now());

    INSERT INTO job_application_field_values (application_id, extra_field_value_id, extra_field_value, extra_field_id) 
        VALUES (applicationId, NULL, '1,2,3', fieldId);

    INSERT INTO job_dva (application_id, department_id, vacancy_id, application_status) 
      VALUES (applicationId, 3, vacancyId, 'new');

    return 1;
end;
$$;

alter function job_sample() owner to antonb2;

