create function add_latest_vacancies_list_component("Page ID" integer, "Amount of vacancies on page" character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  pageId alias FOR $1;
  limitation alias FOR $2;
  corePropNextID int4;
BEGIN
  SELECT nextval('core_property_id_seq') INTO corePropNextID;
  INSERT INTO page_component
    (page_id, class_name) values
    (pageId, 'latestVacanciesComponent');
  INSERT INTO core_property
  	(id, module_id , name, value, title, description, required, readonly, visible, reset_cache, site_id) VALUES
    (   corePropNextID,
    	(SELECT id FROM module WHERE module.name = 'job_module' LIMIT 1),
      	'latestVacanciesLimit',
        limitation,
        'Amount of visible latest vacancies',
        'Limit of amount latest vacancies on page',
        TRUE,
        FALSE,
        TRUE,
        TRUE,
        1
    );
  RETURN TRUE;
END;
$$;

alter function add_latest_vacancies_list_component(integer, varchar) owner to antonb2;

