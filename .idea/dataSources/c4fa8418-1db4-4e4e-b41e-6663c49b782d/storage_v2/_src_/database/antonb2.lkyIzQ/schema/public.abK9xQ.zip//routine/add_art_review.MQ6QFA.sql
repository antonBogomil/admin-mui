create function add_art_review() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  langId int4;  
begin
  for rec in select * from page where lang_id = 3 loop
    perform tpl_generate_article_through_by_id(rec.id,
    	(SELECT id from article WHERE head='review' AND lang_id=3 LIMIT 1));
  end loop;
  return true;
end;
$$;

alter function add_art_review() owner to antonb2;

