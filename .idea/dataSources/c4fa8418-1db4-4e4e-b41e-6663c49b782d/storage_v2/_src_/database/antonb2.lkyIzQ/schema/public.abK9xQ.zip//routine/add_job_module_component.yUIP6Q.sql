create function add_job_module_component(character varying, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    pageName alias for $1;
    startPageType alias for $2;
    componentName alias for $3;
    pageClass alias for $4;

    addRet int;
BEGIN
    SELECT add_standard_component(pageName, componentName, pageClass) INTO addRet;
    IF addRet=-1 THEN
        RETURN -1;
    END IF;
    INSERT INTO page_component_params(element_id, name, value)
        VALUES (addRet, 'start', startPageType);
RETURN 1;
END;
$$;

alter function add_job_module_component(varchar, varchar, varchar, varchar) owner to antonb2;

