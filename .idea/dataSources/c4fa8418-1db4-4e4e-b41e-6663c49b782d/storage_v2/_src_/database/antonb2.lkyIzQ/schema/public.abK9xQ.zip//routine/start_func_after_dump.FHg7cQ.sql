create function start_func_after_dump() returns boolean
  language plpgsql
as
$$
BEGIN
  UPDATE page SET sitemap_freq = 'DAILY';
  UPDATE page SET sitemap_prior = 0.5;
  UPDATE page SET attribute_set_id = 13 WHERE id=134;
  UPDATE article SET text = '<p class="sita-suez">Welkom <span class="sita-wordt">bij</span> SUEZ Global</p>' WHERE id=13;
  UPDATE article SET text = '<p class="sita-suez">Welkom <span class="sita-wordt">bij</span> SUEZ Global</p>' WHERE id=47;
  UPDATE article SET text = '<p class="FooterText">Eenvoudig online je afval regelen</p><p class="footer-line">OOK OPLOSSINGEN VOOR PARTICULIER EN ZAKELIJK. GA NAAR&nbsp; <a style="color: #e96a0c;" href="http://www.sitawordtsuez.nl" target="_blank">www.suez.nl</a></p>' WHERE id=121;
  RETURN TRUE;
END;
$$;

alter function start_func_after_dump() owner to antonb2;

