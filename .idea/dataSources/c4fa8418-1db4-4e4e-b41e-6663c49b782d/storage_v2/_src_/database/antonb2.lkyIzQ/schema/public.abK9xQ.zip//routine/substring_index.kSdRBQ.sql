create function substring_index(str text, delim text, count integer) returns text
  language sql
as
$$
SELECT CASE WHEN $3 > 0 
THEN array_to_string((string_to_array($1, $2))[1:$3], $2)
ELSE array_to_string(ARRAY(SELECT unnest(string_to_array($1,$2))
                             OFFSET array_upper(string_to_array($1,$2),1) + $3),
                     $2)
END
$$;

alter function substring_index(text, text, integer) owner to antonb2;

