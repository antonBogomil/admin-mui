create function copy_images_set_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;    
	
    for rec in select * from images_set1 loop
    	INSERT into images_set(image_set_id, name, required_width, required_height, 
        					max_width, max_height, min_height, min_width, 
                            number_of_images)
			values (rec.image_set_id, rec.name, rec.required_width, rec.required_height, 
            		rec.max_width, rec.max_height, rec.min_height, rec.min_width, 
                    rec.number_of_images);
    	n:=n+1;
    end loop;

    return n;
END;
$$;

alter function copy_images_set_table() owner to antonb2;

