create function test_ebay() returns integer
  language plpgsql
as
$$
declare
    var_articleIdSeq integer;
    var_temp integer;
    i integer;
begin
    /* Insert values into the article table */
    select into var_articleIdSeq last_value from article_id_seq;
    if var_articleIdSeq > 1 then
       var_articleIdSeq := var_articleIdSeq + 1;
    end if;

    delete from article where class = 'ebay_bid';
    delete from ebay_category;

    /* categories */
    insert into ebay_category (id) values (1);
    insert into ebay_category (id) values (2);
    insert into ebay_category (id) values (3);
    insert into ebay_category (id) values (4);
    insert into ebay_category (id) values (5);
    select into var_temp setval ('ebay_category_id_seq', 5);

    insert into ebay_category_name (category_id, lang_id, name) values (1, 1, 'Auto''s');
    insert into ebay_category_name (category_id, lang_id, name) values (1, 2, 'Auto''s');
    insert into ebay_category_name (category_id, lang_id, name) values (2, 1, 'Vacations / tourism');
    insert into ebay_category_name (category_id, lang_id, name) values (2, 2, 'Vacanties / toerisme');
    insert into ebay_category_name (category_id, lang_id, name) values (3, 1, 'Water sport / boating');
    insert into ebay_category_name (category_id, lang_id, name) values (3, 2, 'Watersport / boten');
    insert into ebay_category_name (category_id, lang_id, name) values (4, 1, 'Photo');
    insert into ebay_category_name (category_id, lang_id, name) values (4, 2, 'Foto');
    insert into ebay_category_name (category_id, lang_id, name) values (5, 1, 'faked bids');
    insert into ebay_category_name (category_id, lang_id, name) values (5, 2, 'faked bids');

  /* bids descriptions */
    insert into article (head, text, class) VALUES ('', 'Te koop:<br>Mazda 626 1.8 GLX HB Ambition<br>5 deurs, benzine<br>bouwjaar juni 1997, APK t/m juni 2006<br>kleur: donkerblauw metallic<br>voorzien van:<br>- airbag<br>- airconditioning<br>- armsteun achter<br>- autoradio / 6 speakers / stuurbediening / electrische antenne<br>- bevestigingsbeugels voor dakdragers<br>- centale portiervergrendeling met handzender<br>- electrisch bedienbare ramen voor en achter<br>- electrisch bedienbare zijspiegels<br>- getint glas<br>- hoofdsteunen achter<br>- hoogte verstelbare bestuurdersstoel<br>- hoogte verstelbare koplampen<br>- lichtmetalen velgen<br>- startonderbreking<br>- stuurbekrachtiging<br>- toerenteller<br>- trekhaak<br>volledige onderhoudshistorie aanwezig<br>verbruik ruim 1 op 14', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'te koop: opel corsa grijs kenteken bouwjaar 1992 apk tot september 2005 incl: radio zonnedak in zeer nette staat kmst: 110.000 rijdt wel maar op 3 cilinders er zit een kromme klep in dus als je handig bent doe een bod!!!!!!!!', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Zeer mooie en nette toyota corolla automaat met een APK . Bouwjaar 1989 , grijs metalic , en een zeer lage prijs , 950,- eurotjes. WAAR ??? Bij Auto Edison te Utrecht , kijk ook een op onze site', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'DAEWOO TACUMA CDX 2.0<br>BOUWJAAR 2000 APK,NOV-2005 KLEUR-ROOD<br>KM.65.000 ALARM, AIRCO, ELEKTRISCHE RAMEN EN SPIEGELS<br>VRAAGPRIJS:10.650,00', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Te koop onze impreza auto is volledig getuned en heeft op dit moment een vermogen van 310 pk,s apk tot sept 2005 bouwjaar sept 1998 km stand 103000 grote beurt uitgevoer in mrt 2004 waarbij alle olie is vervangen distr.riem en spanners filters ect.0:100 in 5.1 sec.', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'TE KOOP<br>Renault Laguna luxe uitvoering<br>Kleur:n groen<br>Bouwjaar: 1995<br>Km stand: 185.000 km<br>APK tot 30-08-2005<br>Brandstof: Benzine<br>Extra''s:<br>- alarm klasse 2 met certificaat en startonderbreker<br>- radio met cd-wisselaar<br>-sportvelgen<br>- stuurbekrachtiging<br>- stuur in hoogte verstelbaar<br>- airco (climate control)<br>- electrische ramen voor + verwarmde buitenspiegels<br>- buitentemp. meter<br>- centrale deurvergrendeling met 2x sleutel en afstandbedieningen<br>- mistlampen voor<br>-Armsteun met opbergvak en bekerhouders<br>-Zonnescherm in hoedeplank verwerkt<br>de verkeert in goede staat', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Nieuwe dienst!<br>U bent op zoek naar een mooie maar betaalbare accommodatie in Italie voor de zomervakantie? U wilt niet alle reisgidsen uitpluizen? U wilt niet dagen op Internet surfen? Wij zoeken voor u een passende accommodatie welke , bijna altijd, rechtstreeks bij de eigenaar geboekt kan worden.', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'On the Move Travel biedt i.s.m. het Phuket Palace Resort u de<br>mogelijkheid om losse hotel overnachtingen via onze website te boeken tegen zeer lage tarieven (vanaf 10 Euro p.p.p.n. inclusief ontbijt). Het Phuket Palace Resort , dat de beschikking heeft over tal van faciliteiten en gelegen is 500m van het strand en gezellige centrum van Patong.<br>Het tropische eiland Phuket, welke het grootste is van Thailand, ligt aan de zuidkust van Thailand en +1 uur vliegen vanuit Bangkok. Het is met het vasteland verbonden door een brug en toegankelijk over de weg. De afstand van Bangkok naar Phuket is + 870 km. Het eiland heeft prachtige witte stranden, baaien en een zeer mooi afwisselend bergachtig landschap.<br>Patong Beach is de meest populaire vakantie bestemming en tevens bekend vanwege haar bruisende nachtleven, de vele winkelmogelijkheden en talloze restaurants. Verder kunt u hier de meeste watersporten beoefenen, zoals surfen, zeilen, zwemmen, duiken en snorkelen.<br>Zie onze uitgebreide website voor meer informatie en prijzen.<br>', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Wat wij u bieden<br>U kunt gebruik maken van onze fraaie vrijstaande vakantie bungalow in het prachtige Brabant op de grens van Limburg bij Venray. De bungalow staat midden in de bossen, en is geschikt voor vier personen. Tijdens uw verblijf in de bungalow kunt u heerlijk genieten van rust die u in de bosrijke omgeving vindt. De bossen waarin deze vakantie bungalow staat lenen zich bij uitstek voor een lange wandeling of fietstocht. Uitrusten van de dagelijkse sleur, er zomaar even tussenuit of heerlijk gezond recreлren in de natuur. In vakantiepark de Helderseduinen is het mogelijk.<br>De unieke ligging, de rust en pracht van de omgeving<br>en de vele bezienswaardigheden op korte afstand<br>staan garant voor een zeer aangenaam verblijf', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Yamaha motor 25 pk. Bouwjaar 1998. Elektrisch gestart, goed onderhouden ieder jaar bij dealer. + Trailer + 2 nieuwe zwemvesten + anker + pikhaak + benzine tank en een nieuwe accu 2002. Nieuw afdekzijl 2002 met orginele ligstoelen en achterin een bank. totaal 6 pers.', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'te koop : sony DSC-P50<br>Resolutie max. 1600 x 1200<br>Beeldpunten 2,1 megapixel<br>Optische zoom 3 x<br>Digitale zoom 6 x<br>Scherpstelling automatisch, handmatig<br>Zoeker optisch, LCD<br>LCD-scherm 1,5 inch<br>Geluid opnemen<br>Geheugen 8 MB<br>Opslagmedium MemoryStick<br>Interface USB ,video-out<br>Gewicht 214 gram<br>Afmetingen (H x B x D) 142 x 103 x 79 mm<br>Vraagprijs: 140 euro', 'ebay_bid');
    insert into article (head, text, class) VALUES ('', 'Digital camera Nikon Coolpix 950 met compact Flash kaart- 8xNiMh batterijen - lader - tas - handleiding - CD - kabels en alles in de originale doos. De kamera ziet er nog als nieuw uit en is heel weinig gebruikt.', 'ebay_bid');

    /* bids */
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Mazda 626', 'Boris', 'boris@somehost.com', '030-7465839', '2450 euro', var_articleIdSeq, 'media/ebay/mazda626.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Opel Corsa', 'Robert', 'robert@somehost.com', '030-8405836', 't.e.a.b', var_articleIdSeq+1, 'media/ebay/opel_corsa.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Toyota Corolla', 'Taya', 'taya@somehost.com', '030-5739205', '950 euro', var_articleIdSeq+2, 'media/ebay/toyota_corolla.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Daewoo Tacuma', 'Woo', 'woo@somehost.com', '030-4903586', '10650 euro', var_articleIdSeq+3, 'media/ebay/daewoo_tacuma.jpg', '2005-06-09 13:32:00', 'true');    
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Subaru Impreza', 'Barry', 'barry@somehost.com', '030-3289506', '15000 euro', var_articleIdSeq+4, 'media/ebay/subaru_impreza.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 1, 'Renault Laguna', 'van der', 'vander@somehost.com', '030-4830697', '3750 euro', var_articleIdSeq+5, 'media/ebay/renault_laguna.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 2, 'Accommodatie in Italie', 'Jerry', 'jerry@somehost.com', '030-2389650', NULL, var_articleIdSeq+6, 'media/ebay/accomodation_italy.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 2, 'Phuket Palace Resort', 'Phuket', 'phuket@somehost.com', '030-04956836', NULL, var_articleIdSeq+7, 'media/ebay/phuket.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 2, 'Vakantie bungalow', 'Tom', 'tom@somehost.com', '030-1389547', '300 $', var_articleIdSeq+8, 'media/ebay/bungalow.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 3, 'Plakon motorboot', 'Keith', 'keith@somehost.com', '030-6804826', '6500 euro', var_articleIdSeq+9, 'media/ebay/motorboat.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 4, 'Sony DSC-P50', 'Mark', 'mark@somehost.com', '030-74386935', 'vraagprijs 140 euro', var_articleIdSeq+10, 'media/ebay/sony_dscp50.jpg', '2005-06-09 13:32:00', 'true');
    insert into ebay_bid (type, category_id, title, name, email, phone, price, article_id, image_link, bid_date, approved) values (1, 4, 'Nikon Coolpix 950', 'der van', 'dervan@somehost.com', '030-9053943', '250 euro', var_articleIdSeq+11, 'media/ebay/nikon_coolpix950.jpg', '2005-06-09 13:32:00', 'true');

    var_articleIdSeq := var_articleIdSeq + 12;
    for i in 1..100 loop
        insert into article (head, text, class) VALUES ('', 'Faked bid ' || i, 'ebay_bid');
        insert into ebay_bid (type, category_id, title, name, article_id, bid_date) values (1, 5, 'Thingamajig with ' || i || ' widgets', 'Someone', var_articleIdSeq, '2005-06-09 13:32:00');
        var_articleIdSeq := var_articleIdSeq + 1;
    end loop;

    select into var_temp 1 from module where name = 'Ebay module';
    if not found then
       select into var_temp add_ebay();
    end if;

    raise notice 'test_ebay done';
    return 0;
end;
$$;

alter function test_ebay() owner to antonb2;

