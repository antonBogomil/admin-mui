create function "incCategoryOrder"(character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  categoryName alias for $1;
  currentOrder int := -1;
  maxOrder int := -1;
BEGIN

SELECT category.order_in_list FROM category WHERE category."name" = categoryName INTO currentOrder;

IF currentOrder is null
-- name parameter is wrong
   THEN RETURN false;
END IF;

SELECT "getNextCategoryOrder"() INTO maxOrder;

IF currentOrder = maxOrder-1
-- it is already in max order
   THEN RETURN false;
END IF;

UPDATE category SET order_in_list = currentOrder WHERE category."order_in_list" = currentOrder+1;
UPDATE category SET order_in_list = currentOrder+1 WHERE category."name" = categoryName;

RETURN TRUE;

END;
$$;

alter function "incCategoryOrder"(varchar) owner to antonb2;

