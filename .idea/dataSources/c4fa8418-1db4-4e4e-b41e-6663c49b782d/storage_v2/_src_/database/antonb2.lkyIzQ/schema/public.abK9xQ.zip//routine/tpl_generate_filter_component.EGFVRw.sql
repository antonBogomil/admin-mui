create function tpl_generate_filter_component(integer, integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
	filterId alias for $2;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'pm-filter');
	insert into page_component_params
        (element_id, name, value) values
        (pageElemId, 'filterId', filterId);		
    return pageElemId;
end;
$$;

alter function tpl_generate_filter_component(integer, integer) owner to antonb2;

