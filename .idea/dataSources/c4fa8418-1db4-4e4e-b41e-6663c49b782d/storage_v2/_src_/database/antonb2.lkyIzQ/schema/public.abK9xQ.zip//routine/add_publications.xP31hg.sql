create function add_publications() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
for rec in  select * from a_publiction loop
      insert into nl_publication (category_id, state_id, mail_template_id, feedback_email, i18n, publish_date)
          VALUES(4, 3, 4, 'info@veiligheidsbranche.nl', TRUE, rec.publish_date);
      insert into nl_publication2group (publication_id, group_id) values ((select currval('nl_publication_id_seq')), 5);
      insert into nl_publication_i18n_fields (publication_id, title, description, "text", plain_text, lang_id)
      values ((select currval('nl_publication_id_seq')), rec.title, '', rec.text, '', 1);
    end loop;
return true;
END;
$$;

alter function add_publications() owner to antonb2;

