create function "add-new-article-to-all-pages"() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  PageId int4;
BEGIN
	FOR rec IN select * from page LOOP    
        select rec.id into PageId;
		UPDATE page
        SET attribute_set_id='45';
	END LOOP;
    return true;
END;
$$;

alter function "add-new-article-to-all-pages"() owner to antonb2;

