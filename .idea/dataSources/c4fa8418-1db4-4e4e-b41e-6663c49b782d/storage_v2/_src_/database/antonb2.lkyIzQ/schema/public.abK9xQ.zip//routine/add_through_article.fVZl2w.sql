create function add_through_article("articleId" integer, "langId" integer) returns boolean
  language plpgsql
as
$$
declare
 rec record;
 articleId alias for $1;
 langId alias for $2;
begin
 for rec in select DISTINCT ON (id) * from page where lang_id=langId loop
 perform tpl_generate_article_through_by_id(rec.id, 
 (SELECT id from article WHERE article.id=articleId and article.lang_id=rec.lang_id LIMIT 1));
 end loop;
 return true;
end;
$$;

alter function add_through_article(integer, integer) owner to antonb2;

