create function temp_add_animation_opt() returns boolean
  language plpgsql
as
$$
DECLARE
  i record;
BEGIN
    for i in select * from images_set loop

    	INSERT INTO animation_properties values (nextval('animation_properties_id_seq'), i.image_set_id, 5000, 30, 5);

    end loop;

  return true;
END;
$$;

alter function temp_add_animation_opt() owner to antonb2;

