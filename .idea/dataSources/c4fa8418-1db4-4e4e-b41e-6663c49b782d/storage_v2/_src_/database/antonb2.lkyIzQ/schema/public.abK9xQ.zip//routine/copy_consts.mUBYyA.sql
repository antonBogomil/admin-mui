create function copy_consts() returns integer
  language plpgsql
as
$$
DECLARE
 rec record;
 n int4;
 tmp_id int4;
 tmp_name varchar;
BEGIN
	n:=0;
	tmp_name:='';
	FOR rec IN select * from tmp_const LOOP
		if(tmp_name <> rec.key) then
			select key into tmp_name from tmp_const where id = rec.id;                  
                  
            select dic_custom_const.id into tmp_id from dic_custom_const where dic_custom_const.key = rec.key;
			if (tmp_id is NULL) then
               	insert into dic_custom_const(module_id,key) values(rec.module_id,rec.key);
                insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),1,(select rec.translation from tmp_const where lang_id = 1 and key = rec.key));
 				insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),2,(select rec.translation from tmp_const where lang_id = 2 and key = rec.key));

				insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),3,(select rec.translation from tmp_const where lang_id = 3 and key = rec.key));
				insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),4,(select rec.translation from tmp_const where lang_id = 4 and key = rec.key));
				insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),5,(select rec.translation from tmp_const where lang_id = 5 and key = rec.key));
				insert into dic_custom_translation(const_id,lang_id,translation) 
					values((select id from dic_custom_const where key=rec.key),6,(select rec.translation from tmp_const where lang_id = 6 and key = rec.key));
				n:= n+1;
            end if;

        end if;
    END LOOP;
    return n;
END;
$$;

alter function copy_consts() owner to antonb2;

