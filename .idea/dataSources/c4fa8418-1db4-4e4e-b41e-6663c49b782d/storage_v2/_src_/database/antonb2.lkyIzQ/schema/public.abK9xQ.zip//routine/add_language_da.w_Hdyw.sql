create function add_language_da(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
	langCode alias for $1;
	langTitle alias for $2;
	
	categoryRd RECORD;
	langId integer := -1;
	menuId integer := -1;
	menuItemId integer := -1;
	pageId integer := -1;
	articleId integer := -1;
	pageElementId integer := -1;
BEGIN

	-- add new language
	SELECT nextval('language_id_seq') INTO langId;
	INSERT INTO language (id, language, code)
    VALUES (langId, langTitle, langCode);

	----------------------------------------------------------
	-- add main menu
	----------------------------------------------------------
	SELECT nextval('menu_id_seq') INTO menuId;
	INSERT INTO menu (id, lang_id, parent_menu_item_id, level, frozen, class)
	VALUES (menuId, langId, NULL, 1, 0, '1');

	-- Home page
	INSERT INTO menu_item (menu_id, title, link,  order_, class, visible, link_type)
	VALUES (menuId, 'Home page','home_' || langCode || '.html',1,NULL,1,'page');

	-- Article
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id, lang_id, head, text, class)
	VALUES (articleId, langId, 'head', 'This is the homepage text', NULL);

	-- Page 
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'home_' || langCode || '.html','Welcome',NULL,'homepage','page','2004-02-27 11:52:46','nodelete',NULL,NULL,1);

	-- menu-component 
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- article-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);

	-- "Front page"
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id,lang_id, head, text, class)
	VALUES (articleId,langId,'head','This is the frontpage text',NULL);

	-- page
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'index_' || langCode || '.html','Welcome',NULL,'frontpage','page','2004-02-27 11:52:46','nodelete',NULL,NULL,1);
	
	-- menu-component
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- artilce-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);


	----------------------------------------------------------
	-- add special pages menu
	----------------------------------------------------------
	-- Special pages menu for the first language
	SELECT nextval('menu_id_seq') INTO menuId;
	INSERT INTO menu (id, lang_id, parent_menu_item_id, level, frozen, class) 
	VALUES (menuId, langId, NULL, 0, 0, 'popups');
	
	-----------------
	-- "Error page" in "Special pages" menu
	SELECT nextval('menu_item_id_seq') INTO menuItemId;
	INSERT INTO menu_item (id, menu_id, title, link,  order_, class, visible, link_type) 
	VALUES (menuItemId, menuId, 'Resource not found', 'error_' || langCode || '.html', 1, NULL, 1, 'page');
	
	-- Article
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id, lang_id, head, text, class)
	VALUES (articleId, langId, 'head', 'Resourse not found', NULL);
	
	-- Page 
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'error_' || langCode || '.html','Resource not found', NULL, NULL,'not_found','2004-02-27 11:52:46','nodelete',NULL,NULL,1);

	-- menu-component 
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- article-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);
	



	-----------------
	-- "Mail success page" in "Special pages" menu
	SELECT nextval('menu_item_id_seq') INTO menuItemId;
	INSERT INTO menu_item (id, menu_id, title, link,  order_, class, visible, link_type) 
	VALUES (menuItemId, menuId, 'Mail success', 'success_' || langCode || '.html', 1, NULL, 1, 'page');
	
	-- Article
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id, lang_id, head, text, class)
	VALUES (articleId, langId, 'head', 'Successfully mailed text', NULL);
	
	-- Page 
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'success_' || langCode || '.html','Success', NULL, NULL,'mail_success','2004-02-27 11:52:46','nodelete',NULL,NULL,1);

	-- menu-component 
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- article-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);


	-----------------
	-- "Mail failure page" in "Special pages" menu
	SELECT nextval('menu_item_id_seq') INTO menuItemId;
	INSERT INTO menu_item (id, menu_id, title, link,  order_, class, visible, link_type) 
	VALUES (menuItemId, menuId, 'Mail failure', 'failure_' || langCode || '.html', 1, NULL, 1, 'page');
	
	-- Article
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id, lang_id, head, text, class)
	VALUES (articleId, langId, 'head', 'Mailed with failure', NULL);
	
	-- Page 
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'failure_' || langCode || '.html','Failure', NULL, NULL,'mail_failure','2004-02-27 11:52:46','nodelete',NULL,NULL,1);

	-- menu-component 
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- article-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);

	-----------------
	-- "Access denied page" in "Special pages" menu
	SELECT nextval('menu_item_id_seq') INTO menuItemId;
	INSERT INTO menu_item (id, menu_id, title, link,  order_, class, visible, link_type) 
	VALUES (menuItemId, menuId, 'Access denied', 'access_denied_' || langCode || '.html', 1, NULL, 1, 'page');
	
	-- Article
	SELECT nextval('article_id_seq') INTO articleId;
	INSERT INTO article (id, lang_id, head, text, class)
	VALUES (articleId, langId, 'head', 'Access is denied', NULL);
	
	-- Page 
	SELECT nextval('page_id_seq') INTO pageId;
	INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible)
	VALUES (pageId, langId,'access_denied_' || langCode || '.html','Access denied', NULL, NULL,'access_denied','2004-02-27 11:52:46','nodelete',NULL,NULL,1);

	-- menu-component 
	insert into page_element (page_id, table_name, domain_table_record_id, class_name)
	values (pageId, '0', '0', 'menu-component');

	-- article-component
	SELECT nextval('page_element_id_seq') INTO pageElementId;
	insert into page_element (id, page_id, table_name, domain_table_record_id, class_name)
	values (pageElementId, pageId, '0', '0', 'article-component');
	insert into page_element_params (element_id, name, value)
	values (pageElementId, 'id', articleId);

	RETURN 1;
END;
$$;

alter function add_language_da(varchar, varchar) owner to antonb2;

