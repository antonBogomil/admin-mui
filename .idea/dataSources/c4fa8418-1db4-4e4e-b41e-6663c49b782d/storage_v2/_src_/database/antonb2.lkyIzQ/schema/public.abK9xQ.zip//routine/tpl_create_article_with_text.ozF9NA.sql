create function tpl_create_article_with_text(integer, text) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    articleText alias for $2;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, langId, '', articleText);
    return articleId;
end;
$$;

alter function tpl_create_article_with_text(integer, text) owner to antonb2;

