create function tpl_generate_own_pages_article("Custom Head" character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  custoHead alias for $1;
  articleId int4;
  rec record; 
BEGIN 
    FOR rec IN select * from page LOOP     
        select tpl_create_article(rec.id, custoHead) into articleId;
        perform tpl_generate_article_by_id(rec.id, articleId);
    END LOOP;
    return true;
END;
$$;

alter function tpl_generate_own_pages_article(varchar) owner to antonb2;

