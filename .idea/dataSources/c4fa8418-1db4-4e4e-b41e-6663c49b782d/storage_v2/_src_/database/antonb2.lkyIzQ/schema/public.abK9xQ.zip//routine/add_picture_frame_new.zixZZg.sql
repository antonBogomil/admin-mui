create function add_picture_frame_new() returns boolean
  language plpgsql
as
$$
declare
  rec record;
begin

    for rec in select * from page WHERE attribute_set_id IS NULL and class='sitemap3'loop

	    INSERT INTO images_set
               VALUES(nextval('images_set_image_set_id_seq'), 'through_frame', Null, Null, 992, Null, Null, Null, 1);

        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/picture_frame/pic.jpg', Null, Null, Null, Null, Null, 340,992,1);

               
        UPDATE page SET attribute_set_id=(SELECT MAX(image_set_id) FROM images_set LIMIT 1) WHERE id=rec.id;

        INSERT INTO wcms_attribute_set VALUES (nextval('wcms_attribute_set_wcms_attribute_set_id_seq'), Null);
        
        INSERT INTO wcms_attribute VALUES (nextval('wcms_attribute_wcms_attr_id_seq'), 1, '',(SELECT MAX(image_set_id) FROM images_set LIMIT 1), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), Null, 'animation');
        
    end loop;

  return true;
end;
$$;

alter function add_picture_frame_new() owner to antonb2;

