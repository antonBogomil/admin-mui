create function fill_filter_attributes_from_pm_product_type() returns boolean
  language plpgsql
as
$$
DECLARE
  	attr_type_rec RECORD;
    product_type_rec RECORD;
    filter_rec RECORD;
    attr_max_val BIGINT;
    attr_type VARCHAR;
    mask BOOLEAN;
    SKIP BOOLEAN;
BEGIN
  delete from pm_filter;
  delete from pm_filter_attribute;
  delete from pm_filter_attr2product_attr;
  delete from pm_filter_float_interval_attribute;
  FOR product_type_rec IN SELECT * FROM pm_product_type LOOP
  	insert into pm_filter(name_id) values(product_type_rec.id);
  END LOOP;
  FOR attr_type_rec IN SELECT * FROM pm_attribute_type order by pm_attribute_type.order_number LOOP
        SKIP:=FALSE;
        IF ( attr_type_rec.type_name='string' ) THEN
        	attr_type:= 'attribute_type';
            mask:= true; 
        ELSIF (attr_type_rec.type_name='real_value') THEN
	        attr_type:= 'real_interval_type';
            mask:= false;
        ELSE 
        	SKIP:= true;
        END IF;
        IF (SKIP=FALSE) THEN
        SELECT INTO filter_rec * FROM pm_filter WHERE name_id = attr_type_rec.product_type_id;

          insert into pm_filter_attribute(filter_id, 
                                          name,
                                          drop_down_option,
                                          is_multiple,
                                          is_hidden,
                                          is_mask,
                                          order_number,
                                          type,
                                          is_predefined)
          values(filter_rec.id,
                      attr_type_rec.name,
                      false,
                      false,
                      false,
                      mask,
                      attr_type_rec.order_number,
                      attr_type,
                      false);
          SELECT INTO attr_max_val max(id) from pm_filter_attribute;
          
          insert into pm_filter_attr2product_attr(filter_attr_id,
                                                  product_attr_id)
          values(attr_max_val,
                  attr_type_rec.id);
          IF (attr_type_rec.type_name='real_value') THEN        
            insert into pm_filter_float_interval_attribute(filter_attr_id,
                                                          interval_point)
            VALUES(attr_max_val,
                  0);
          END IF; 
          
                  
        END IF;
  END LOOP; 
 
  RETURN true;
END;
$$;

alter function fill_filter_attributes_from_pm_product_type() owner to antonb2;

