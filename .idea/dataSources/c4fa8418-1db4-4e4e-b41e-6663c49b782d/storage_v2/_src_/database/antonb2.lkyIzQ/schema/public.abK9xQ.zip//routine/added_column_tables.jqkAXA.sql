create function added_column_tables() returns boolean
  language plpgsql
as
$$
BEGIN
  ALTER TABLE groups ADD COLUMN subsite_id INTEGER;   
  RETURN TRUE; 
END;
$$;

alter function added_column_tables() owner to antonb2;

