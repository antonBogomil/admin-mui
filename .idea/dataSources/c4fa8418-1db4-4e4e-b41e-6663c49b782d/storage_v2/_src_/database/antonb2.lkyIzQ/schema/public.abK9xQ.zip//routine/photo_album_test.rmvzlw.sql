create function photo_album_test() returns integer
  language plpgsql
as
$$
declare
    var_mcFolderIdSeq integer;
    var_imageIdSeq integer;
    var_articleIdSeq integer;
    var_photoAlbumIdSeq integer;
begin
    /* Insert values into the mc_folder table */
    select into var_mcFolderIdSeq last_value from mc_folder_id_seq;
    if var_mcFolderIdSeq > 1 then
       var_mcFolderIdSeq := var_mcFolderIdSeq + 1;
    end if;

    insert into mc_folder(path, title) VALUES('media/photo_album', 'Photo Album');
    insert into mc_folder(path, title) VALUES('media/photo_album/Atoll_reefs/', 'Atoll Reefs');
    insert into mc_folder(path, title) VALUES('media/photo_album/Cars/', 'Cars');
    insert into mc_folder(path, title) VALUES('media/photo_album/Cities/', 'Cities');
    insert into mc_folder(path, title) VALUES('media/photo_album/Cities/New_York/', 'New York');
    insert into mc_folder(path, title) VALUES('media/photo_album/Cities/Rio_de_Janeiro/', 'Rio de Janeiro');
    insert into mc_folder(path, title) VALUES('media/photo_album/Grand_canyon/', 'Grand Canyon');
    insert into mc_folder(path, title) VALUES('media/photo_album/Nature/', 'Nature');
    insert into mc_folder(path, title) VALUES('media/photo_album/Waterfalls/', 'Waterfalls');

    /* Insert values into the image table */
    select into var_imageIdSeq last_value from image_image_id_seq;
    if var_imageIdSeq > 1 then
       var_imageIdSeq := var_imageIdSeq + 1;
    end if;

    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Atoll_reefs/GreatBarrierReef_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Cars/audia6_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Cities/cafe_chantant_goldengates_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Cities/New_York/new-york-city_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Cities/Rio_de_Janeiro/RioDeJaneiro_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Grand_canyon/GrandCanyon_100x75.jpg', 100, 75);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Nature/golf_100x62.jpg', 100, 62);
    insert into image (src, max_width, max_height) VALUES ('media/photo_album/Waterfalls/VictoriaFalls_100x75.jpg', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Atoll_reefs/GreatBarrierReef.jpg', 'Great Barrier Reef', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Atoll_reefs/GreatBarrierReef_100x75.jpg', 'Great Barrier Reef', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/audia6.jpg', 'Audi A6', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/audia6_100x75.jpg', 'Audi A6', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/auditt.jpg', 'Audi TT', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/auditt_100x75.jpg', 'Audi TT', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/crossfire.jpg', 'Crossfire', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/crossfire_100x75.jpg', 'Crossfire', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/salsa.jpg', 'Salsa', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cars/salsa_100x75.jpg', 'Salsa', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/New_York/new-york-city.jpg', 'New York', 447, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/New_York/new-york-city_100x75.jpg', 'New York', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/Rio_de_Janeiro/RioDeJaneiro.jpg', 'Rio de Janeiro', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/Rio_de_Janeiro/RioDeJaneiro_100x75.jpg', 'Rio de Janeiro', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/cafe_chantant_goldengates.jpg', 'Cafe chantant goldengates', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/cafe_chantant_goldengates_100x75.jpg', 'Cafe chantant goldengates', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/dnieper_river_north.jpg', 'Dnieper river north', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/dnieper_river_north_100x75.jpg', 'Dnieper river north', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/historicalmuseum_andreevskachurch.jpg', 'Historical museum - Andreevskaya church', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/historicalmuseum_andreevskachurch_100x75.jpg', 'Historical museum - Andreevskaya church', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/house_withdevils.jpg', 'House with devils', 476, 635);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/house_withdevils_74x100.jpg', 'House with devils', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic.jpg', 'Kreshatik', 1075, 1434);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic_74x100.jpg', 'Kreshatik', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic1.jpg', 'Kreshatik', 1075, 1434);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic1_74x100.jpg', 'Kreshatik', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic2.jpg', 'Kreshatik', 1434, 1075);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic2_100x74.jpg', 'Kreshatik', 100, 74);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic_lenina.jpg', 'Kreshatik - Lenina', 1434, 1075);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/kreshchatic_lenina_100x74.jpg', 'Kreshatik - Lenina', 100, 74);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/lenina.jpg', 'Lenina', 1434, 1075);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/lenina_100x74.jpg', 'Lenina', 100, 74);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/national_bank.jpg', 'National bank', 476, 635);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/national_bank_74x100.jpg', 'National bank', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/pagan_temple_perun_idol.jpg', 'Pagan temple perun idol', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/pagan_temple_perun_idol_100x75.jpg', 'Pagan temple perun idol', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/park_vladimirska_hill.jpg', 'Park Vladimirskaya Hill', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/park_vladimirska_hill_100x75.jpg', 'Park Vladimirskaya Hill', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/picturesque_allee.jpg', 'Picruresque allee', 476, 294);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/picturesque_allee_100x61.jpg', 'Picruresque alley', 100, 61);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/prorizna_park_enter.jpg', 'Prorizna park enter', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/prorizna_park_enter_100x75.jpg', 'Prorizna park enter', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/ukrainian_dress.jpg', 'Ukrainian dress', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/ukrainian_dress_100x75.jpg', 'Ukrainian dress', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/view_from_picturesqueallee.jpg', 'View from picturesque alley', 476, 357);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/view_from_picturesqueallee_100x75.jpg', 'View from picturesque alley', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/yaroslavivval_banks.jpg', 'Yaroslavivval bank', 476, 635);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/yaroslavivval_banks_74x100.jpg', 'Yaroslavivval bank', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/yaroslavivval_street.jpg', 'Yaroslavivval street', 476, 635);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Cities/yaroslavivval_street_74x100.jpg', 'Yaroslavivval street', 74, 100);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Grand_canyon/GrandCanyon.jpg', 'Grand canyon', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Grand_canyon/GrandCanyon_100x75.jpg', 'Grand canyon', 100, 75);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/golf.jpg', 'Golf', 448, 281);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/golf_100x62.jpg', 'Golf', 100, 62);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/Sunsetnieuw.jpg', 'Sunset', 300, 225);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/Sunsetnieuw_99x99.jpg', 'Sunset', 99, 99);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/vulkaanuitbarsting.jpg', 'Volcano', 448, 299);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Nature/vulkaanuitbarsting_100x66.jpg', 'Volcano', 100, 66);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Waterfalls/VictoriaFalls.jpg', 'Victoria Waterfall', 448, 336);
    insert into image (src, alt, max_width, max_height) VALUES ('media/photo_album/Waterfalls/VictoriaFalls_100x75.jpg', 'Victoria Waterfall', 100, 75);

    /* Insert values into the article table */
    select into var_articleIdSeq last_value from article_id_seq;
    if var_articleIdSeq > 1 then
       var_articleIdSeq := var_articleIdSeq + 1;
    end if;

    /* Descriptions of the photo albums */
    insert into article (lang_id, head, text) VALUES (1, 'Atoll reefs', 'Atoll reefs');
    insert into article (lang_id, head, text) VALUES (1, 'Cars', 'Cars');
    insert into article (lang_id, head, text) VALUES (1, 'Cities', 'Cities');
    insert into article (lang_id, head, text) VALUES (1, 'New York', 'New York');
    insert into article (lang_id, head, text) VALUES (1, 'Rio de Janeiro', 'Rio de Janeiro');
    insert into article (lang_id, head, text) VALUES (1, 'Grand Canyon', 'Grand Canyon');
    insert into article (lang_id, head, text) VALUES (1, 'Nature', 'Nature');
    insert into article (lang_id, head, text) VALUES (1, 'Waterfalls', 'Waterfalls');

    /* Descriptions of the photos */
    insert into article (lang_id, head, text) VALUES (1, 'Great Barrier Reef', 'Great Barrier Reef');
    insert into article (lang_id, head, text) VALUES (1, 'Audi A6', 'Audi A6');
    insert into article (lang_id, head, text) VALUES (1, 'Audi TT', 'Audi TT');
    insert into article (lang_id, head, text) VALUES (1, 'Crossfire', 'Crossfire');
    insert into article (lang_id, head, text) VALUES (1, 'Salsa', 'Salsa');
    insert into article (lang_id, head, text) VALUES (1, 'New York', 'New York');
    insert into article (lang_id, head, text) VALUES (1, 'Rio de Janeiro', 'Rio de Janeiro');
    insert into article (lang_id, head, text) VALUES (1, 'Cafe chantant goldengates', 'Cafe chantant goldengates');
    insert into article (lang_id, head, text) VALUES (1, 'Dnieper river north', 'Dnieper river north');
    insert into article (lang_id, head, text) VALUES (1, 'Historical museum - Andreevskaya church', 'Historical museum - Andreevskaya church');
    insert into article (lang_id, head, text) VALUES (1, 'House with devils', 'House with devils');
    insert into article (lang_id, head, text) VALUES (1, 'Kreshatik', 'Kreshatik');
    insert into article (lang_id, head, text) VALUES (1, 'Kreshatik', 'Kreshatik');
    insert into article (lang_id, head, text) VALUES (1, 'Kreshatik', 'Kreshatik');
    insert into article (lang_id, head, text) VALUES (1, 'Kreshatik - Lenina', 'Kreshatik - Lenina');
    insert into article (lang_id, head, text) VALUES (1, 'Lenina', 'Lenina');
    insert into article (lang_id, head, text) VALUES (1, 'National bank', 'National bank');
    insert into article (lang_id, head, text) VALUES (1, 'Pagan temple perun idol', 'Pagan temple perun idol');
    insert into article (lang_id, head, text) VALUES (1, 'Park Vladimirskaya Hill', 'Park Vladimirskaya Hill');
    insert into article (lang_id, head, text) VALUES (1, 'Picruresque allee', 'Picruresque allee');
    insert into article (lang_id, head, text) VALUES (1, 'Prorizna park enter', 'Prorizna park enter');
    insert into article (lang_id, head, text) VALUES (1, 'Ukrainian dress', 'Ukrainian dress');
    insert into article (lang_id, head, text) VALUES (1, 'View from picturesque alley', 'View from picturesque alley');
    insert into article (lang_id, head, text) VALUES (1, 'Yaroslavivval bank', 'Yaroslavivval bank');
    insert into article (lang_id, head, text) VALUES (1, 'Yaroslavivval street', 'Yaroslavivval street');
    insert into article (lang_id, head, text) VALUES (1, 'Grand canyon', 'Grand canyon');
    insert into article (lang_id, head, text) VALUES (1, 'Golf', 'Golf');
    insert into article (lang_id, head, text) VALUES (1, 'Sunset', 'Sunset');
    insert into article (lang_id, head, text) VALUES (1, 'Volcano', 'Volcano');
    insert into article (lang_id, head, text) VALUES (1, 'Victoria Waterfall', 'Victoria Waterfall');

    /* insert into the photo album table */
    select into var_photoAlbumIdSeq last_value from photo_album_id_seq;
    if var_photoAlbumIdSeq > 1 then
       var_photoAlbumIdSeq := var_photoAlbumIdSeq + 1;
    end if;

    /* Photo albums */
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Atoll Reefs', 1, NULL, var_ArticleIdSeq, var_mcFolderIdSeq+1, NULL, var_imageIdSeq);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Cars', 1, NULL, var_ArticleIdSeq+1, var_mcFolderIdSeq+2, NULL, var_imageIdSeq+1);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Cities', 1, NULL, var_ArticleIdSeq+2, var_mcFolderIdSeq+3, NULL, var_imageIdSeq+2);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('New York', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+3, var_mcFolderIdSeq+4, NULL, var_imageIdSeq+3);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Rio de Janeiro', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+4, var_mcFolderIdSeq+5, NULL, var_imageIdSeq+4);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Grand Canyon', 1, NULL, var_ArticleIdSeq+5, var_mcFolderIdSeq+6, NULL, var_imageIdSeq+5);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Nature', 1, NULL, var_ArticleIdSeq+6, var_mcFolderIdSeq+7, NULL, var_imageIdSeq+6);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Waterfalls', 1, NULL, var_ArticleIdSeq+7, var_mcFolderIdSeq+8, NULL, var_imageIdSeq+7);
    /* Images */
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Great Barrier Reef', 1, var_PhotoAlbumIdSeq, var_ArticleIdSeq+8, NULL, var_imageIdSeq+8, var_imageIdSeq+9);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Audi A6', 1, var_PhotoAlbumIdSeq+1, var_ArticleIdSeq+9, NULL, var_imageIdSeq+10, var_imageIdSeq+11);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Audi TT', 1, var_PhotoAlbumIdSeq+1, var_ArticleIdSeq+10, NULL, var_imageIdSeq+12, var_imageIdSeq+13);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Crossfire', 1, var_PhotoAlbumIdSeq+1, var_ArticleIdSeq+11, NULL, var_imageIdSeq+14, var_imageIdSeq+15);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Salsa', 1, var_PhotoAlbumIdSeq+1, var_ArticleIdSeq+12, NULL, var_imageIdSeq+16, var_imageIdSeq+17);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('New York', 1, var_PhotoAlbumIdSeq+3, var_ArticleIdSeq+13, NULL, var_imageIdSeq+18, var_imageIdSeq+19);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Rio de Janeiro', 1, var_PhotoAlbumIdSeq+4, var_ArticleIdSeq+14, NULL, var_imageIdSeq+20, var_imageIdSeq+21);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Cafe chantant goldengates', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+15, NULL, var_imageIdSeq+22, var_imageIdSeq+23);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Dnieper river north', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+16, NULL, var_imageIdSeq+24, var_imageIdSeq+25);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Historical museum - Andreevskaya church', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+17, NULL, var_imageIdSeq+26, var_imageIdSeq+27);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('House with devils', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+18, NULL, var_imageIdSeq+28, var_imageIdSeq+29);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Kreshatik', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+19, NULL, var_imageIdSeq+30, var_imageIdSeq+31);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Kreshatik', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+20, NULL, var_imageIdSeq+32, var_imageIdSeq+33);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Kreshatik', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+21, NULL, var_imageIdSeq+34, var_imageIdSeq+35);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Kreshatik - Lenina', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+22, NULL, var_imageIdSeq+36, var_imageIdSeq+37);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Lenina', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+23, NULL, var_imageIdSeq+38, var_imageIdSeq+39);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('National bank', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+24, NULL, var_imageIdSeq+40, var_imageIdSeq+41);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Pagan temple perun idol', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+25, NULL, var_imageIdSeq+42, var_imageIdSeq+43);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Park Vladimirskaya Hill', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+26, NULL, var_imageIdSeq+44, var_imageIdSeq+45);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Picruresque allee', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+27, NULL, var_imageIdSeq+46, var_imageIdSeq+47);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Prorizna park enter', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+28, NULL, var_imageIdSeq+48, var_imageIdSeq+49);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Ukrainian dress', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+29, NULL, var_imageIdSeq+50, var_imageIdSeq+51);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('View from picturesque alley', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+30, NULL, var_imageIdSeq+52, var_imageIdSeq+53);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Yaroslavivval bank', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+31, NULL, var_imageIdSeq+54, var_imageIdSeq+55);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Yaroslavivval street', 1, var_PhotoAlbumIdSeq+2, var_ArticleIdSeq+32, NULL, var_imageIdSeq+56, var_imageIdSeq+57);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Grand canyon', 1, var_PhotoAlbumIdSeq+5, var_ArticleIdSeq+33, NULL, var_imageIdSeq+58, var_imageIdSeq+59);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Golf', 1, var_PhotoAlbumIdSeq+6, var_ArticleIdSeq+34, NULL, var_imageIdSeq+60, var_imageIdSeq+61);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Sunset', 1, var_PhotoAlbumIdSeq+6, var_ArticleIdSeq+35, NULL, var_imageIdSeq+62, var_imageIdSeq+63);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Volcano', 1, var_PhotoAlbumIdSeq+6, var_ArticleIdSeq+36, NULL, var_imageIdSeq+64, var_imageIdSeq+65);
    insert into photo_album (name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) VALUES ('Victoria Waterfall', 1, var_PhotoAlbumIdSeq+7, var_ArticleIdSeq+37, NULL, var_imageIdSeq+66, var_imageIdSeq+67);

    raise notice 'done';
    return 0;
end;
$$;

alter function photo_album_test() owner to antonb2;

