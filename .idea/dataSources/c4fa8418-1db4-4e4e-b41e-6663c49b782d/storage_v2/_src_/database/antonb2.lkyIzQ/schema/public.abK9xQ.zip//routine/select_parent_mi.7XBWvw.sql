create function select_parent_mi() returns integer
  language plpgsql
as
$$
declare
    parentId int4;
begin
    SELECT INTO parentId m.parent_menu_item_id from menu_item AS mi
 		LEFT JOIN menu as m ON (m.id = mi.menu_id)
 		WHERE m.site_id=1 AND m.level>1
 		ORDER BY mi.id DESC LIMIT 1;
    return parentId;
end;
$$;

alter function select_parent_mi() owner to antonb2;

