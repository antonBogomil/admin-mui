create function delete_colons_in_friendly_url_table() returns boolean
  language plpgsql
as
$$
BEGIN
  UPDATE friendly_url SET link = REPLACE(link, substring(link from ':'), '_') WHERE substring(link from ':') is not null; 
  UPDATE friendly_url SET alternative_link = REPLACE(alternative_link, substring(alternative_link from ':'), '_') WHERE substring(alternative_link from ':') is not null;
  RETURN TRUE;
END;
$$;

alter function delete_colons_in_friendly_url_table() owner to antonb2;

