create function function1() returns boolean
  language plpgsql
as
$$
  /* New function body */
Declare i integer;
Begin

for i in 1..(select max(page_id) from page_component)
loop

           insert into page_component(page_id,class_name) values(i,''article-component'');
            insert into page_component(page_id,class_name) values(i,''article-component'');
             insert into page_component(page_id,class_name) values(i,''article-component'');
end loop;
return true;
end
$$;

alter function function1() owner to antonb2;

