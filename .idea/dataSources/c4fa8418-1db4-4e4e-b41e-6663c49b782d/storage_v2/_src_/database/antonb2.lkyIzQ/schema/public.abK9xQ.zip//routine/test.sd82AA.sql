create function test() returns boolean
  strict
  language plpgsql
as
$$
declare
 rec record;
begin
for rec in select * from pm_product where category_id=23 loop
    select * from pm_attribute_value where type_id=21 and product_id=rec.id;
end loop;
return null;
end
$$;

alter function test() owner to antonb2;

