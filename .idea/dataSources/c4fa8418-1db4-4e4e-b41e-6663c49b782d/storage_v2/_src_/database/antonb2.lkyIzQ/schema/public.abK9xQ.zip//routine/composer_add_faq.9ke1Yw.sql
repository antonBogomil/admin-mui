create function composer_add_faq(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    faqName alias for $1;
    pageName alias for $2;
    langId integer := -1;
    templateId integer := -1;
    listId integer := -1;
    pageElementId integer := -1;

    -- constatnts
  LIST_MODULE_ID integer := 3;
    LIST_COMPONENT_NAME varchar := 'list-component';
    LIST_PAGE_CLASS varchar := 'faq';


  LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';

  LIST_ITEM_PAGE_CLASS varchar := 'search_news';

BEGIN
    SELECT lang_id INTO langId FROM page WHERE filename=pageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;

  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = faqName) AND (module_id = MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, faqName)
    ;
  END IF;

  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id)
    VALUES (listId, faqName, langId, 1, '', 0, 0, LIST_MODULE_ID, faqName, templateId)
  ;

  -- add list component
  SELECT add_standard_component(pageName, LIST_COMPONENT_NAME, LIST_PAGE_CLASS) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;
  -- Page_element_params
  INSERT INTO page_element_params (element_id, name, value)
    VALUES (pageElementId, 'listId', listId);

  RETURN 1;
END;
$$;

alter function composer_add_faq(varchar, varchar) owner to antonb2;

