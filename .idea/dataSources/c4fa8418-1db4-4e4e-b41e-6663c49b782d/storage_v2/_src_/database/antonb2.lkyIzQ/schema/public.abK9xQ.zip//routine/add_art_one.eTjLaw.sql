create function add_art_one("langId" integer) returns boolean
  language plpgsql
as
$$
declare
  langId alias for $1;
  rec record;
  articleId int4;
begin

	insert into article(lang_id,head,text) values(langId,'banner','<p>
    <a title="Start Now!" href="http://builder.sitementrix.com/" target="_blank">
        <img src="../media/buttons_set/start_now.png" onclick="null" alt="" width="154" height="91" />
    </a>
</p>
<br />
<p>    
    <a title="Buy voucher!" href="http://portal.sitementrix.com/invoice.html?act=add&product_type=SITEMENTRIX_GIFT_VOUCHER" target="_blank">
        <img src="../media/buttons_set/buy_gift.png" onclick="null" alt=" " width="154" height="91" />
    </a>
</p>');
  for rec in select DISTINCT ON (id) id from page where page.lang_id=langId loop  	
    perform tpl_generate_article_through_by_id(rec.id,
    	(select article.id from article where head = 'banner' and lang_id=langId limit 1)
    );    
  end loop;
  return true;
end;
$$;

alter function add_art_one(integer) owner to antonb2;

