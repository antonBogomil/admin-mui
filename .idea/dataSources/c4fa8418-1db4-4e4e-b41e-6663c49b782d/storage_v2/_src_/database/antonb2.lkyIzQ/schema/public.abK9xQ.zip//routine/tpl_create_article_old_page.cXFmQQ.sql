create function tpl_create_article_old_page(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, text) values
        (articleId, langId, 'Page is under construction');
    return articleId;
end;
$$;

alter function tpl_create_article_old_page(integer) owner to antonb2;

