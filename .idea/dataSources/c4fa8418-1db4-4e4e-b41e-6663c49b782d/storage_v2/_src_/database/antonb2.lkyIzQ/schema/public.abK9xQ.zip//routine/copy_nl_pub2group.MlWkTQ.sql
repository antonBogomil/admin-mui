create function copy_nl_pub2group() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
   	for rec in select * from nl_publication1 loop    	
		INSERT into nl_publication2group(publication_id, group_id) 	
			values (rec.id, rec.category_id);		
	end loop;

	return n;
END;
$$;

alter function copy_nl_pub2group() owner to antonb2;

