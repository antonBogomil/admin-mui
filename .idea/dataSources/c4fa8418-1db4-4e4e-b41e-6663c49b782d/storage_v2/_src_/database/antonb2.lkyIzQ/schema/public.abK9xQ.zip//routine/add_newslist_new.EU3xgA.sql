create function add_newslist_new(character varying, character varying, character varying, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  newslinePageName alias for $1;
  listIds alias for $2;
  itemsPerPage alias for $3;
  parameters alias for $4;
  includeNull alias for $5;
  includeNotNull alias for $6;

  -- constatnts
  NEWSLINE_COMPONENT_NAME varchar := 'news-line-component';
  NEWSLINE_PAGE_CLASS varchar := 'news';

  pageElementId integer := -1;
BEGIN
  -- add list component
  SELECT add_standard_component(newslinePageName, NEWSLINE_COMPONENT_NAME, NEWSLINE_PAGE_CLASS) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;
  
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'lists', listIds);
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'itemsPerPage', itemsPerPage);
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'parameters', parameters);
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'includeNull', includeNull);
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'includeNotNull', includeNotNull);

  RETURN pageElementId;
END;
$$;

alter function add_newslist_new(varchar, varchar, varchar, varchar, varchar, varchar) owner to antonb2;

