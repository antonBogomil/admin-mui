create function copy_nl_mail_template() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
   	for rec in select * from nl_mail_template1 where id <> 1 loop
    	INSERT into nl_mail_template(id, i18n, site_id, confirmation_text)
			values (rec.id, true, 1, true);
		INSERT into nl_mail_template_i18n_fields(title, text, mail_template_id, lang_id)
			values (rec.rs_name, (select text from nl_mail_template_i18n_fields where id = 1), (select max(id) from nl_mail_template), 1);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_nl_mail_template() owner to antonb2;

