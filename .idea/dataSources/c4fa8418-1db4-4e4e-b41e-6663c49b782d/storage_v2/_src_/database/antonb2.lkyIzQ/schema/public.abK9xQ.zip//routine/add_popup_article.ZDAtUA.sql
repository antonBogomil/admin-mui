create function add_popup_article() returns boolean
  language plpgsql
as
$$
declare
		  rec record;
		begin
		  for rec in select page.id from page loop
			insert into page_component(page_id, class_name) 
			VALUES (rec.id ,'article-component');

			insert into page_component_params(element_id, name, value) 
			values 
			((select currval('page_component_id_seq')),'id', (select article.id from article where head = 'popup' limit 1));     
		  end loop;
		  return true;
		end;

$$;

alter function add_popup_article() owner to antonb2;

