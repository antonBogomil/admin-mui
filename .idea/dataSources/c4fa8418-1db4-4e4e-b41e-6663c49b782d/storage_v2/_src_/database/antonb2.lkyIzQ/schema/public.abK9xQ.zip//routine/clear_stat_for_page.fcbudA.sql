create function clear_stat_for_page() returns trigger
  language plpgsql
as
$$
BEGIN
  delete from stat_statistics where page_name = OLD.filename;
  RETURN NULL;
END;
$$;

alter function clear_stat_for_page() owner to antonb2;

