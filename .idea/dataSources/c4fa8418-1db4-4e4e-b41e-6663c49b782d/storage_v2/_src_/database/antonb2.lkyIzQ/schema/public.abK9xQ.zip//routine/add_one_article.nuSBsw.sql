create function add_one_article() returns boolean
  strict
  language plpgsql
as
$$
declare
 rec record;
 teaserId INTEGER;
 articleId INTEGER; 
begin

/*
for rec in select * from list_item_old loop
	select nextval('article_id_seq') into teaserId;
    insert into article(id,lang_id,head,text,class) 
    	values(teaserId, 
        	(select lang_id from article_old where article_old.id=rec.teaser_id),
            (select head from article_old where article_old.id=rec.teaser_id),
            (select text from article_old where article_old.id=rec.teaser_id),
            (select class from article_old where article_old.id=rec.teaser_id)	);

	select nextval('article_id_seq') into articleId;
    insert into article(id,lang_id,head,text,class) 
    	values(articleId, 
        	(select lang_id from article_old where article_old.id=rec.article_id),
            (select head from article_old where article_old.id=rec.article_id),
            (select text from article_old where article_old.id=rec.article_id),
            (select class from article_old where article_old.id=rec.article_id)	);
            
    insert into list_item(id, list_id, title, teaser_id, order_number, visible, image_link, view_date, publish_date, expired_date, created_by, created_date, last_modified_by, last_modified_date, article_id, site_id) 
    	values (
        rec.id, 
        rec.list_id, 
        rec.title, 
        teaserId, 
        rec.order_number, 
        rec.visible, 
        rec.image_link, 
        rec.view_date, 
        rec.publish_date, 
        rec.expired_date, 
        rec.created_by, 
        rec.created_date, 
        rec.last_modified_by, 
        rec.last_modified_date, articleId, 1);        
	
end loop;

*/

for rec in select * from pm_category_articles_old loop
	select nextval('article_id_seq') into articleId;
    insert into article(id,lang_id,head,text,class) 
    	values(articleId, 
        	(select lang_id from article_old where article_old.id=rec.article_id),
            (select head from article_old where article_old.id=rec.article_id),
            (select text from article_old where article_old.id=rec.article_id),
            (select class from article_old where article_old.id=rec.article_id)	);
            
    insert into pm_category_articles(category_id, article_id) values (rec.category_id, articleId);        
	
end loop;

return null;
end
$$;

alter function add_one_article() owner to antonb2;

