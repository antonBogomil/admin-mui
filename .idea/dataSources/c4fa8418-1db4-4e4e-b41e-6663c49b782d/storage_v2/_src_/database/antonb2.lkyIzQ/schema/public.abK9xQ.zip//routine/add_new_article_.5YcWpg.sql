create function add_new_article_() returns boolean
  language plpgsql
as
$$
declare
  rec record;
begin

    for rec in select * from page loop

INSERT INTO article (lang_id, head, text)
       VALUES (1, 'Enter your text here', '<p><img src="http://dlvfc.negeso.com:80/media/img_top_2.jpg" onclick="null" alt="" width="179" height="112" /></p>');
INSERT INTO page_component (page_id, class_name)
       VALUES (rec.id, 'article-component');
INSERT INTO page_component_params (element_id,name,value)
       VALUES ((SELECT MAX(id) FROM page_component),'id',(SELECT MAX(id) FROM article));

INSERT INTO page_component (page_id, class_name)
       VALUES (rec.id,'article-component');
INSERT INTO page_component_params (element_id,name,value)
       VALUES ((SELECT MAX(id) FROM page_component),'id',13);


INSERT INTO article (lang_id, head, text)
       VALUES (1, 'Enter your text here', '<img src="http://dlvfc.negeso.com:80/media/top_right.gif" onclick="null" alt="" width="188" height="112" />');
INSERT INTO page_component (page_id, class_name)
       VALUES (rec.id, 'article-component');
INSERT INTO page_component_params (element_id,name,value)
       VALUES ((SELECT MAX(id) FROM page_component),'id',(SELECT MAX(id) FROM article));


INSERT INTO article (lang_id, head, text)
       VALUES (1, 'Enter your text here', 'Page is under construction');
INSERT INTO page_component (page_id, class_name)
       VALUES (rec.id, 'article-component');
INSERT INTO page_component_params (element_id,name,value)
       VALUES ((SELECT MAX(id) FROM page_component),'id',(SELECT MAX(id) FROM article));

INSERT INTO article (lang_id, head, text)
       VALUES (1, 'Enter your text here', 'Page is under construction');
INSERT INTO page_component (page_id, class_name)
       VALUES (rec.id, 'article-component');
INSERT INTO page_component_params (element_id,name,value)
       VALUES ((SELECT MAX(id) FROM page_component),'id',(SELECT MAX(id) FROM article));
    end loop;

  return true;
end;
$$;

alter function add_new_article_() owner to antonb2;

