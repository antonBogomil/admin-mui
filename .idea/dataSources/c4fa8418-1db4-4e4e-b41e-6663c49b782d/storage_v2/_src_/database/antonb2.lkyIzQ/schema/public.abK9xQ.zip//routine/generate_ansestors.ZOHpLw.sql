create function generate_ansestors(integer, character varying) returns character varying
  language plpgsql
as
$$
  /* New function body */
DECLARE
       parentid alias for $1;
       ansestors alias for $2;
       str VARCHAR;
BEGIN
     str:= (SELECT ' ' || parentid || ',' || ansestors);
     IF EXISTS (SELECT parent_id FROM pm_category
                      WHERE id = parentid AND parent_id IS NOT NULL) THEN
     return (select generate_ansestors((SELECT parent_id FROM pm_category
                      WHERE id = parentid), str));
     ELSE
         return str;
     END IF;
END;
$$;

alter function generate_ansestors(integer, varchar) owner to antonb2;

