create function add_picture_frame_() returns boolean
  language plpgsql
as
$$
declare
  rec record;
begin

    for rec in select * from page WHERE attribute_set_id IS NULL and class='simple'  loop

	    INSERT INTO images_set
               VALUES(nextval('images_set_image_set_id_seq'), 'dummy', Null, Null, 224, Null, Null, Null, 4);

        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), '/site/images/test_img4.gif', Null, Null, Null, Null, Null, 207,224,4);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), '/media/picture_frame/test_img.gif', Null, Null, Null, Null, Null, 178,224,1);
               
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), '/media/picture_frame/test_img3.gif', Null, Null, Null, Null, Null, 178,224,3);
               
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), '/media/picture_frame/test_img2.gif', Null, Null, Null, Null, Null, 178,224,2);
               
        UPDATE page SET attribute_set_id=(SELECT MAX(image_set_id) FROM images_set LIMIT 1) WHERE id=rec.id;

        INSERT INTO wcms_attribute_set VALUES (nextval('wcms_attribute_set_wcms_attribute_set_id_seq'), Null);
        
        INSERT INTO wcms_attribute VALUES (nextval('wcms_attribute_wcms_attr_id_seq'), 1, '',(SELECT MAX(image_set_id) FROM images_set LIMIT 1), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), Null, 'fixed size');
        
    end loop;

  return true;
end;
$$;

alter function add_picture_frame_() owner to antonb2;

