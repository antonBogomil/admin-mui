create function add_newlist_2all_pages() returns integer
  language plpgsql
as
$$
declare
    tmpPagesId record;
    counter int4 = 0;

begin
     for tmpPagesId in select id from page where (page.lang_id=1) and id not in ( 
       select page_id from page_component where class_name='list-item-component')
       order by id loop       
       perform tpl_generate_list_item_by_id(tmpPagesId.id, '2');
       counter = counter + 1;
     end loop;
     return counter;
end;
$$;

alter function add_newlist_2all_pages() owner to antonb2;

