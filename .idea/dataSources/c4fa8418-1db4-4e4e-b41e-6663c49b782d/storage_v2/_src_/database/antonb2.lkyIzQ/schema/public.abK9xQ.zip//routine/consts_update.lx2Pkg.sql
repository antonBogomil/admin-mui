create function consts_update() returns integer
  language plpgsql
as
$$
DECLARE
 rec record;
 n int4;
 tmp_id int4;
 tmp_name varchar;
BEGIN
	n:=0;
	tmp_name:='';
	FOR rec IN select * from tmp_const LOOP
		update dic_custom_translation set translation = rec.translation
        where const_id = (select id from dic_custom_const where key = rec.key) and lang_id = rec.lang_id;
    END LOOP;
    return n;
END;
$$;

alter function consts_update() owner to antonb2;

