create function "testApfArticle"("headArticle" character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  headArticle alias for $1;
  articleId int4;
  rec record; 
BEGIN 
    FOR rec IN select * from page LOOP     
        select tpl_create_article_(rec.id, headArticle) into articleId;
        perform tpl_generate_article_by_id(rec.id, articleId);
    END LOOP;
    return true;
END;
$$;

alter function "testApfArticle"(varchar) owner to antonb2;

