create function add_art_topblock() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  langId int4;  
begin
  for rec in select * from page where lang_id = 1 loop
    perform tpl_generate_article_through_by_id(rec.id,
    	(SELECT id from article WHERE head='toplinks' AND lang_id=1 LIMIT 1));
  end loop;
  return true;
end;
$$;

alter function add_art_topblock() owner to antonb2;

