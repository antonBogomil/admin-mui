create function "getNextCategoryOrder"() returns integer
  language plpgsql
as
$$
DECLARE
  nextOrderVal integer := 0;
BEGIN

SELECT MAX(category."order_in_list") FROM category INTO nextOrderVal;

IF nextOrderVal is null
   THEN RETURN 0;
END IF;

RETURN nextOrderVal+1;

END;
$$;

alter function "getNextCategoryOrder"() owner to antonb2;

