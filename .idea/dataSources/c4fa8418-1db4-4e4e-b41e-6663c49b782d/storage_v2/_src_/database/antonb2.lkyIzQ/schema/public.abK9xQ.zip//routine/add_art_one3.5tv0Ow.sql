create function add_art_one3() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  recPm record;
  keyPm VARCHAR;
  seoTitleId INTEGER;
  seoDescriptionId INTEGER;
  seoKeywordsId INTEGER;
  seoRichTextId  INTEGER;
  articleId INTEGER;
begin
	for rec in select  * from pm_product_type loop
        select nextval('pm_attribute_type_id_seq') into seoTitleId;
    	INSERT INTO "public"."pm_attribute_type" ("id", "product_type_id", "name", "type_name", "rs_name", "order_number", "site_id", "is_customized")
			VALUES (seoTitleId, rec.id, 'seo_title', 'string', 'SEO Title', 
            (select max(order_number +1) from pm_attribute_type where pm_attribute_type.product_type_id=rec.id),
             1, True);
		select nextval('pm_attribute_type_id_seq') into seoDescriptionId;
		INSERT INTO "public"."pm_attribute_type" ("id", "product_type_id", "name", "type_name", "rs_name", "order_number", "site_id", "is_customized")
			VALUES (seoDescriptionId, rec.id, 'seo_description', 'text', 'SEO Description', 
            (select max(order_number +1) from pm_attribute_type where pm_attribute_type.product_type_id=rec.id),
             1, True);    
		select nextval('pm_attribute_type_id_seq') into seoKeywordsId;
	    INSERT INTO "public"."pm_attribute_type" ("id", "product_type_id", "name", "type_name", "rs_name", "order_number", "site_id", "is_customized")
			VALUES (seoKeywordsId, rec.id, 'seo_keywords', 'text', 'SEO Keywords', 
            (select max(order_number +1) from pm_attribute_type where pm_attribute_type.product_type_id=rec.id),
             1, True);
		select nextval('pm_attribute_type_id_seq') into seoRichTextId;
		INSERT INTO "public"."pm_attribute_type" ("id", "product_type_id", "name", "type_name", "rs_name", "order_number", "site_id", "is_customized")
			VALUES (seoRichTextId, rec.id, 'seo_rich_text', 'article', 'SEO Rich Text', 
            (select max(order_number +1) from pm_attribute_type where pm_attribute_type.product_type_id=rec.id),
             1, True);
    
    	for recPm in select  * from pm_product where pm_product.type_id=rec.id loop        
	        INSERT INTO "public"."pm_attribute_value" ("product_id", "type_id", "str_value", "int_value", "advstr_value", "lang_id")
				VALUES (recPm.id, seoTitleId, '', NULL, NULL, 1);
            INSERT INTO "public"."pm_attribute_value" ("product_id", "type_id", "str_value", "int_value", "advstr_value", "lang_id")
				VALUES (recPm.id, seoDescriptionId, '', NULL, NULL, 1);
            INSERT INTO "public"."pm_attribute_value" ("product_id", "type_id", "str_value", "int_value", "advstr_value", "lang_id")
				VALUES (recPm.id, seoKeywordsId, '', NULL, NULL, 1);
			select tpl_create_article_with_text(1,'') into articleId;
            INSERT INTO "public"."pm_attribute_value" ("product_id", "type_id", "str_value", "int_value", "advstr_value", "lang_id")
				VALUES (recPm.id, seoRichTextId, NULL, articleId, NULL, 1);

		end loop;                                
  	end loop;
	return true;
end;
$$;

alter function add_art_one3() owner to antonb2;

