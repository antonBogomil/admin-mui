create function copy_nl_create_group() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
	for rec in select * from nl_category1 where id <> 1 loop
    	INSERT into nl_group(id, internal, site_id, order_number) 
			values (rec.id, false, 1, rec.order_number);
		INSERT into nl_group_i18n_fields(title, group_id, lang_id) 
			values (rec.rs_title, rec.id,  1);		
			
		n:=n+1;
	end loop;
	
   	
	for rec in select * from nl_subscription1 loop
    	INSERT into nl_subscriber2group(subscriber_id, group_id) values (rec.subscriber_id, rec.category_id);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_nl_create_group() owner to antonb2;

