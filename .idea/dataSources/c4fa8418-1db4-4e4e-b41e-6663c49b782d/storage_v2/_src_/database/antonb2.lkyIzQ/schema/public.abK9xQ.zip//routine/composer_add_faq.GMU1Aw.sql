create function composer_add_faq(character varying, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    faqName alias for $1;
    typeName alias for $2;
    pageName alias for $3;
    pageContents alias for $4;

    langId integer := -1;
    templateId integer := -1;
    listId integer := -1;
    pageElementId integer := -1;

    -- constatnts
  LIST_MODULE_ID integer := 3;
    LIST_COMPONENT_NAME varchar := 'list-component';
    LIST_PAGE_CLASS varchar := 'faq';


  LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';

  LIST_ITEM_PAGE_CLASS varchar := 'search_news';
  
  pContents varchar := '';
    pageId integer := -1;
    articleId integer := -1;
    listItemId integer := -1;
  

BEGIN
    SELECT lang_id INTO langId FROM page WHERE filename=pageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;

  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = typeName) AND (module_id = MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, typeName)
    ;
  END IF;

  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id)
    VALUES (listId, faqName, langId, 1, '', 0, 0, LIST_MODULE_ID, faqName, templateId)
  ;
  
  pContents := replace(pageContents, '$id', listId);
  
  SELECT id INTO pageId FROM page WHERE filename=pageName;
  IF pageId IS NULL THEN
    RETURN -1;
  END IF;

  UPDATE page SET class=typeName, protected='nodelete', contents=pContents WHERE id=pageId;

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'This is the FAQ sample text', NULL);
  
  -- list_item
  SELECT nextval('list_item_id_seq') INTO listItemId;
    INSERT INTO list_item (id, list_id, title, teaser_id, order_number, visible, publish_date)
    VALUES (listItemId, listId, faqName, articleId, 1, 1, now())
  ;

  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id)
    VALUES (listId, faqName, langId, 1, '', 0, 0, LIST_MODULE_ID, NULL, templateId, listItemId)
  ;



  RETURN 1;
END;
$$;

alter function composer_add_faq(varchar, varchar, varchar, varchar) owner to antonb2;

