create function composer_add_webpoll(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  pollTitle alias for $1;
  pollPageName alias for $2;
  pollResultPageName alias for $3;

  -- constatnts
  POLL_TEMPLATE_NAME varchar := 'webpoll';
  POLL_MODULE_ID integer := 16;
  POLL_COMPONENT_NAME varchar := 'poll-component';
  POLL_RESULTS_COMPONENT_NAME varchar := 'poll-result-component';
  POLL_PAGE_CLASS varchar := 'frontpage';

  langId integer := -1;
  listId integer := -1;
  pageElementId integer := -1;
  templateId integer := -1;
  siteId integer := 1;

BEGIN
  SELECT lang_id INTO langId FROM page WHERE filename=pollPageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;
  
  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = POLL_TEMPLATE_NAME) AND (module_id = POLL_MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, POLL_MODULE_ID, POLL_TEMPLATE_NAME)
    ;
  END IF;
  
  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, site_id)
    VALUES (listId, pollTitle, langId, 1, '', 100, 100, POLL_MODULE_ID, pollTitle, templateId, siteId)
  ;
  
  -- add list component
  SELECT add_standard_component(pollPageName, POLL_COMPONENT_NAME, POLL_PAGE_CLASS) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;

  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'listId', listId);

  IF pollResultPageName IS NOT NULL THEN
    -- add list-item component
    SELECT add_standard_component(pollResultPageName, POLL_RESULTS_COMPONENT_NAME, POLL_PAGE_CLASS) INTO pageElementId;
    IF pageElementId = -1 THEN
        RETURN -2;
      END IF;
    -- page_component_params
    INSERT INTO page_component_params (element_id, name, value)
      VALUES (pageElementId, 'listId', listId);

  END IF;

  RETURN listId;
END;
$$;

alter function composer_add_webpoll(varchar, varchar, varchar) owner to antonb2;

