create function "add-dict"(character varying, character varying) returns boolean
  language plpgsql
as
$$
DECLARE
 constName alias for $1;
 constValue alias for $2;
 rec varchar;
BEGIN	
    for rec in (select code from core_reference) loop
    	insert into dictionary(dictionary_file_id,entry_id, lang_code, entry) 
			values(1,constName, rec, constValue);		
    end loop;
    return true;
END;
$$;

alter function "add-dict"(varchar, varchar) owner to antonb2;

