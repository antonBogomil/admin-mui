create function add_help_module() returns integer
  language plpgsql
as
$$
DECLARE
	rec record;
    n INTEGER := 0;
    currSiteId INTEGER := 0;    
BEGIN
    
	FOR rec IN SELECT * FROM site_url ORDER BY site_id LOOP    	
        SELECT site_id INTO currSiteId FROM module WHERE name = 'help' AND site_id = rec.site_id;
        
        IF (currSiteId is NULL) THEN
			insert into module(name, golive, url, order_number, title, site_id ) 
				values('help', '02.04.2011 0:00:00', '/admin/help/', 38,  'Help module', rec.site_id);                
            insert into core_property(module_id, name, value, description, site_id) 
       			values((select max(id) from module), 'HELP_SITE_URL', 'http://help.phidias.nl/', 'Help site URL', rec.site_id);
			insert into core_property(module_id, name, value, description, site_id ) 
				values((select max(id) from module), 'HELP_DEFAULT_PAGE', '/admin/help/SM-help_%s.html', 'Help default page', rec.site_id);

            n:=n+1;        	
        END IF;
    END LOOP;
    
    RETURN n;
END;
$$;

alter function add_help_module() owner to antonb2;

