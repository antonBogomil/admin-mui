create function tpl_create_forth_article(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, langId, '', '<table width=834 height=461 border=0 cellpadding=0 cellspacing=0><tr><td width=404 height=461 valign=top>The first column</td><td width=22 height=461 valign=top><img src=/site/images/spacer.gif width=22 height=1 /></td><td width=408 height=461 valign=top>The second column</td></tr></table>
    ');
    return articleId;
end;
$$;

alter function tpl_create_forth_article(integer) owner to antonb2;

