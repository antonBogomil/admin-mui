create function delete_order_function() returns trigger
  language plpgsql
as
$$
BEGIN
  DELETE FROM pm_order WHERE id in (
     SELECT order_id FROM pm_product2order
     WHERE pm_product2order.product_id = old.id
  );

  RETURN OLD;
END;
$$;

alter function delete_order_function() owner to antonb2;

