create function add_pm_2all_pages() returns integer
  language plpgsql
as
$$
declare
    tmpPagesId record;
    counter int4 = 0;

begin
     for tmpPagesId in select id from page where id not in (
       	select page_id from page_component where class_name='product-module-main'
       	order by id) AND filename like '%pm_%' order by id loop
       	
       	perform tpl_add_pm(tmpPagesId.id);
        counter = counter + 1;

     end loop;
     return counter;
end;
$$;

alter function add_pm_2all_pages() owner to antonb2;

