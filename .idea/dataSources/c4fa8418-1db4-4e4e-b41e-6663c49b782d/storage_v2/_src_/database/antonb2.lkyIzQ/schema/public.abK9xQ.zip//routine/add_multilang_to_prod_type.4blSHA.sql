create function add_multilang_to_prod_type("prodType" integer) returns boolean
  language plpgsql
as
$$
DECLARE
 rec record;  
 articleId int4;
 temp int4;
 prodType alias for $1;
BEGIN
	for rec in select * from pm_attribute_value where pm_attribute_value.type_id in (
				select id from pm_attribute_type 
					where pm_attribute_type.product_type_id=prodType and 
                          pm_attribute_type.name<>'artikelnummer' and 
                          pm_attribute_type.type_name = 'string' and 
                          pm_attribute_type.is_i18n <> true ) loop
                          
	insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
 		values(rec.product_id,rec.type_id,rec.str_value,2);

	insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
 		values(rec.product_id,rec.type_id,rec.str_value,3);
        
    insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
    	values(rec.product_id,rec.type_id,rec.str_value,4);
        
	end loop;
    
    update pm_attribute_type set is_i18n=true 
 		where product_type_id=prodType and name<>'artikelnummer' and type_name = 'string';
        
	return true;
END;
$$;

alter function add_multilang_to_prod_type(integer) owner to antonb2;

