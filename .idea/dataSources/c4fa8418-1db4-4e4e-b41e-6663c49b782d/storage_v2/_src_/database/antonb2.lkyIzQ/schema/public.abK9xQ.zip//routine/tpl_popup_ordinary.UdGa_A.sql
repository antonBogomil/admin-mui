create function tpl_popup_ordinary(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    articleId int4;
begin
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    return 1;
end;
$$;

alter function tpl_popup_ordinary(integer) owner to antonb2;

