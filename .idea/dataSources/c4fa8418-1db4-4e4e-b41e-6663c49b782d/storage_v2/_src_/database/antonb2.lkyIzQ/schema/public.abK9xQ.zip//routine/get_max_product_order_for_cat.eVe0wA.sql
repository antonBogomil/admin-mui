create function get_max_product_order_for_cat(character varying, integer) returns integer
  language plpgsql
as
$$
  /* New function body */
declare
       o_number INTEGER;
begin
     o_number := (select max(order_number) from pm_product where category_id =
       (select id from pm_category where rs_title=$1 and product_type_id=$2));
     if o_number is null then
        return 0;
     else
         return o_number + 1;
     end if;
end;
$$;

alter function get_max_product_order_for_cat(varchar, integer) owner to antonb2;

