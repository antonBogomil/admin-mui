create function add_menurte() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  pageId int4;
begin

  for rec in select * from page where lang_id=1 and id>1 loop
    pageId := rec.id;
    perform tpl_generate_article_by_id(pageId, 1031);
    perform tpl_generate_article_by_id(pageId, 1032);
    perform tpl_generate_article_by_id(pageId, 1033);
      --INSERT INTO page_component (page_id, class_name) VALUE (rec.id, "article-component");
      --INSERT INTO page_component_params (element_id, name, value)
      -- VALUE ((SELECT max(id) FROM page_component), "id", );	
  end loop;

  return true;
end;
$$;

alter function add_menurte() owner to antonb2;

