create function tpl_generate_right_article(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    elementId int4;
begin
select lang_id into langId from page where id = pageId;

    select nextval('page_element_id_seq') into elementId;

insert into page_element 
(id,page_id,table_name,domain_table_record_id,class_name,container_id) values 
(elementId,pageId,'0','0','article-component', NULL);

IF langId = '1' THEN
    insert into page_element_params
        (element_id, name, value) values
        (elementId, 'id', 115);
END IF;

IF langId = '2' THEN
    insert into page_element_params
        (element_id, name, value) values
        (elementId, 'id', 61);
END IF;

IF langId = '3' THEN
    insert into page_element_params
        (element_id, name, value) values
        (elementId, 'id', 106);
END IF;

IF langId = '4' THEN
    insert into page_element_params
        (element_id, name, value) values
        (elementId, 'id', 126);
END IF;

IF langId = '5' THEN
    insert into page_element_params
        (element_id, name, value) values
        (elementId, 'id', 136);
END IF;
        
    return elementId;
end;
$$;

alter function tpl_generate_right_article(integer) owner to antonb2;

