create function set_activation_date_if_needed() returns trigger
  language plpgsql
as
$$
BEGIN
  IF OLD.activation_key IS NOT NULL AND NEW.activation_key IS NULL THEN
    NEW.date_activated := NOW();
  END IF;
  RETURN NEW;
END;
$$;

alter function set_activation_date_if_needed() owner to antonb2;

