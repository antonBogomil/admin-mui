create function add_art_slogan() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  langId int4;  
begin
  for rec in select * from page where lang_id = 8 AND id = 320 loop
    perform tpl_generate_article_through_by_id(rec.id,
    	(SELECT id from article WHERE head='slogan' AND lang_id=8 LIMIT 1));
  end loop;
  return true;
end;
$$;

alter function add_art_slogan() owner to antonb2;

