create function fix_export() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
  for rec in SELECT * FROM nl_subscriber where NOT EXISTS (select nl_subscription.subscriber_id from nl_subscription where nl_subscriber.id=nl_subscription.subscriber_id) loop
    insert into nl_subscription(subscriber_id,lang_id,category_id,is_html) values(rec.id,1,3,1);
  end loop;
  return true;
END;
$$;

alter function fix_export() owner to antonb2;

