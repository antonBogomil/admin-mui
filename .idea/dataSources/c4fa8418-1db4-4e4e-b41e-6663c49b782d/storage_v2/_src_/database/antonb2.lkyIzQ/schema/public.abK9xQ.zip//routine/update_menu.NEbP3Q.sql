create function update_menu() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  
begin	


 for rec in select * from menu_old loop
 
 
	insert into menu(id, parent_id, page_id, lang_id, title, link, order_number, publish_date, expired_date, keep_menu, site_id) 
		VALUES ( rec.id, rec.parent_id, (select page.id from page LEFT JOIN page_old ON page_old.filename = page.filename where  page_old.id=rec.page_id), rec.lang_id, rec.title, rec.link, rec.order_number, rec.publish_date, rec.expired_date, rec.keep_menu, rec.site_id);
    

  end loop;
  return true;
  
  end;
$$;

alter function update_menu() owner to antonb2;

