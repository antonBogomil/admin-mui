create function tmp_update() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;    
   	--delete from forms;
   	--delete from article;
    
    for rec in select * from nl_group1 loop
    	update nl_group1 set order_number=rec.order_number, google_map_link=rec.google_map_link, file_1=rec.file_1, file_2=rec.file_2, publish_1=rec.publish_1, publish_2=rec.publish_2, expired_1=rec.expired_1, expired_2=rec.expired_2 where id=rec.id;
    	n:=n+1;
    end loop;
    return n;
END;
$$;

alter function tmp_update() owner to antonb2;

