create function fill_images(character varying) returns integer
  language plpgsql
as
$$
declare
   var_template_name ALIAS FOR $1;

   var_templ record;
   var_set record;
   var_attribute record;
   var_iset record;
   var_img record;
   tmp_rec record;
   var_attr_set_id_templ integer;
   var_i integer;
   row record;
   var_new_image_set_id integer;
   var_new_attr_set_id integer;

begin


SELECT * INTO var_templ FROM wcms_attr_template
       WHERE name = var_template_name;

SELECT * INTO var_set FROM wcms_attribute_set
       WHERE wcms_templ_id = var_templ.wcms_templ_id;

IF var_set.wcms_templ_id IS null
THEN
    raise notice 'Template not found';
    return 0;
END IF;
raise notice ' var_attr_set_id_templ = %', var_set.wcms_templ_id;

SELECT * INTO var_attribute FROM wcms_attribute
WHERE wcms_attribute_set_id = var_set.wcms_attribute_set_id
AND class='main image';

SELECT * INTO var_iset FROM images_set
WHERE image_set_id = var_attribute.image_set_id;

SELECT * INTO var_img FROM image
WHERE image_set_id = var_iset.image_set_id;

for row IN select * from page
loop

    raise notice 'page_id = %', row.id;
    SELECT create_attribute_from_template(var_template_name)
    INTO var_new_attr_set_id;
    
    update page set attribute_set_id = var_new_attr_set_id
    where page.id = row.id;


/*    select nextval('wcms_attribute_set_wcms_attribute_set_id_seq')
    into var_new_attr_set_id;
    
    INSERT INTO wcms_attribute_set (wcms_attribute_set_id)
    VALUES (var_new_attr_set_id);

    update page set attribute_set_id = var_new_attr_set_id
    where page.id = row.id;


    --INSERT image set
    INSERT INTO images_set (name, required_width, required_height,
           max_width, max_height, number_of_images )
           SELECT name, required_width, required_height,
                  max_width, max_height, number_of_images
           FROM images_set WHERE image_set_id = var_iset.image_set_id;
    SELECT currval('images_set_image_set_id_seq') INTO var_new_image_set_id;

    --attribute image
    INSERT INTO wcms_attribute (wcms_attr_type_id, name, image_set_id, wcms_attribute_set_id, class)
    VALUES (var_attribute.wcms_attr_type_id, var_attribute.name,
           var_new_image_set_id, var_new_attr_set_id, var_attribute.class);

    --image
    INSERT INTO image (image_set_id, src, alt, max_width, max_height,
           required_width, required_height, _order)
    VALUES (var_new_image_set_id, var_img.src, var_img.alt,
           var_img.max_width, var_img.max_height,
           var_img.required_width, var_img.required_height, 1);
*/

end loop;

return 1;
end;
$$;

alter function fill_images(varchar) owner to antonb2;

