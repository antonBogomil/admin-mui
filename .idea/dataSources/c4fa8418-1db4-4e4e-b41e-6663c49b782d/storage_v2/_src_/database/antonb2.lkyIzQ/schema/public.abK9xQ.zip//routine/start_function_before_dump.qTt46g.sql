create function start_function_before_dump() returns boolean
  language plpgsql
as
$$
BEGIN
  ALTER TABLE article ADD COLUMN module_id INTEGER;
  ALTER TABLE guestbook ADD COLUMN contact_person VARCHAR(1000);
  ALTER TABLE guestbook ADD COLUMN business_place VARCHAR(1000);
  ALTER TABLE guestbook ADD COLUMN question_type VARCHAR(50);
  ALTER TABLE guestbook ADD COLUMN owner VARCHAR(255);
  ALTER TABLE guestbook ADD COLUMN attachment VARCHAR(50);
  ALTER TABLE guestbook ADD COLUMN leegloop VARCHAR;
  ALTER TABLE guestbook ADD COLUMN organisation VARCHAR(1000);
  ALTER TABLE job_departments ADD COLUMN provincie BOOLEAN;
  ALTER TABLE job_departments ADD COLUMN vestiging BOOLEAN;
  ALTER TABLE job_departments ADD COLUMN type INTEGER;
  ALTER TABLE job_vacancies ADD COLUMN job_code TEXT;
  ALTER TABLE job_vacancies ADD COLUMN location TEXT;
  ALTER TABLE job_vacancies ADD COLUMN contract_type TEXT;
  ALTER TABLE job_vacancies ADD COLUMN summary INTEGER;
  ALTER TABLE job_vacancies ADD COLUMN region_name TEXT;
  ALTER TABLE job_vacancies ADD COLUMN dictionary_id INTEGER;
  ALTER TABLE job_vacancies ADD COLUMN time_regulation TEXT;
  ALTER TABLE job_vacancies ADD COLUMN office_location TEXT;
  ALTER TABLE job_vacancies ADD COLUMN company_profile TEXT;
  ALTER TABLE job_vacancies ADD COLUMN company_description TEXT;
  ALTER TABLE job_vacancies ADD COLUMN vacancy_profile TEXT;
  ALTER TABLE job_vacancies ADD COLUMN education_level TEXT;
  ALTER TABLE job_vacancies ADD COLUMN vacancy_category TEXT;
  ALTER TABLE job_vacancies ADD COLUMN email TEXT;
  ALTER TABLE job_vacancies ADD COLUMN import_id INTEGER;
  ALTER TABLE job_vacancies ADD COLUMN is_exported BOOLEAN DEFAULT true;
  ALTER TABLE job_vacancies ADD COLUMN is_published BOOLEAN DEFAULT true;
  ALTER TABLE job_vacancies ADD COLUMN is_published_by_admin BOOLEAN DEFAULT false;
  ALTER TABLE job_vacancies ADD COLUMN owner VARCHAR(255);
  ALTER TABLE list_item ADD COLUMN is_exported BOOLEAN DEFAULT true;
  ALTER TABLE list_item ADD COLUMN import_id INTEGER;
  ALTER TABLE mc_folder ADD COLUMN title VARCHAR(1024);
  ALTER TABLE mc_folder ADD COLUMN parent_id INTEGER;
  ALTER TABLE page_component ADD COLUMN table_name VARCHAR(30) NOT NULL DEFAULT 0;
  ALTER TABLE page_component ADD COLUMN domain_table_record_id INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE page_component ADD COLUMN container_id INTEGER;
  ALTER TABLE pm_attribute_value ADD COLUMN date_value TIMESTAMP WITHOUT TIME ZONE;
  ALTER TABLE pm_attribute_value ADD COLUMN float_value DOUBLE PRECISION;
  ALTER TABLE pm_attribute_value ADD COLUMN region_id INTEGER;
  ALTER TABLE xslt_template ADD COLUMN repository_template_id INTEGER;
  ALTER TABLE xslt_template ADD COLUMN xml_template_id INTEGER; 
  ALTER TABLE pm_customer ADD COLUMN region_id INTEGER; 
  RETURN TRUE; 
END;
$$;

alter function start_function_before_dump() owner to antonb2;

