create function add_one_article_to_all_pages() returns boolean
  strict
  language plpgsql
as
$$
declare
 rec record;
begin
for rec in select * from page loop
	insert into article (lang_id, head, text, class, container_id) values (1, 'right', 'This is the <b>quickLinks</b>', NULL, NULL);
    insert into page_component(page_id,class_name) values (rec.id, 'article-component');
	insert into page_component_params(element_id, name, value) values((select max(id) from page_component),'id', (select max(id) from article));
end loop;
return null;
end
$$;

alter function add_one_article_to_all_pages() owner to antonb2;

