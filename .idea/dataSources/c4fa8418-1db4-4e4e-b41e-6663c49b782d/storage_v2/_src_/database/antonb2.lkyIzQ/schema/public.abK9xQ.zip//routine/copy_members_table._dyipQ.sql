create function copy_members_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
    
	delete from members;	
	
   	for rec in select * from members1 loop
    	INSERT into members(id, group_id, user_id)
			values (rec.id, rec.group_id, rec.user_id);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_members_table() owner to antonb2;

