create function function7fghhgjfgjfghj() returns boolean
  language plpgsql
as
$$
BEGIN
UPDATE job_vacancies2 SET department_id = 1 WHERE id = Null;
  RETURN TRUE;
END;
$$;

alter function function7fghhgjfgjfghj() owner to antonb2;

