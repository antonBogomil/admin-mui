create function set_custom_const(module_name character varying, const_key character varying, default_value character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  module_name alias for $1;
  const_key alias for $2;
  default_value alias for $3;
  const_key_id INTEGER;
BEGIN
	insert into dic_custom_const(module_id,key) values((select id from module where name= module_name),const_key);
	select id into const_key_id from dic_custom_const where key=const_key;
	insert into dic_custom_translation(const_id,lang_id,translation)  
	select const_key_id, id,default_value from core_reference;
	RETURN TRUE;
END;
$$;

alter function set_custom_const(varchar, varchar, varchar) owner to antonb2;

