create function insert_category(character varying, character varying, integer, boolean, character varying, character varying) returns boolean
  language plpgsql
as
$$
  /* New function body */
declare
     i integer;
     order_n integer;
     p_id integer;
     j integer;
     art_id integer;
begin
     p_id := (SELECT id from pm_category where rs_title=$2 and product_type_id = $3);
     if (select max(order_number) from pm_category where parent_id = p_id) is null then
        order_n := 0;
     else
         order_n := (select max(order_number) from pm_category where parent_id = p_id);
     end if;

     if (select id from pm_category where rs_title = $1 and product_type_id = $3) IS NULL then
        i := (SELECT nextval('pm_category_id_seq'));
        insert into pm_category (
               id,
               parent_id,
               product_type_id,
               rs_title,
               rs_description,
               order_number,
               is_leaf,
               publish_date,
               site_id,
               downloads)
        values(
               i,
               p_id,
               $3,
               $1,
               (SELECT 'pm_category:' || i),
               order_n,
               $4,
               (select now()),
               1,
               ''
        );
        for j in 1..3 loop
            art_id = (SELECT nextval('article_id_seq'));
            insert into article values (art_id, j, 'CATEGORY_OVERVIEW',
            'The category is under construction.', 'pm', null);
            insert into pm_category_articles values (i, art_id);
        end loop;
        insert into string_resource VALUES ($1,1,$1);
        insert into string_resource VALUES ($1,2,$5);
        insert into string_resource VALUES ($1,3,$6);
     end if;
     return true;
end;
$$;

alter function insert_category(varchar, varchar, integer, boolean, varchar, varchar) owner to antonb2;

