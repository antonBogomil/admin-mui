create function copy_nl_subscriber() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
   	for rec in select * from nl_subscriber1 loop
    	INSERT into nl_subscriber(id, created_date, activated, subscription_lang_id, html, site_id)
			values (rec.id, '9/13/2011 00:00:00', true, 1, true, 1);
		INSERT into nl_subscriber_attribute_value(value, attribute_type_id, subscriber_id)
			values (rec.email, 2, rec.id);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_nl_subscriber() owner to antonb2;

