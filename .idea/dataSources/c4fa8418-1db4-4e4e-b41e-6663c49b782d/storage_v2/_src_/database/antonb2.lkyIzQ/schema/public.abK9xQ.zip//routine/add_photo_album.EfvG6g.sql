create function add_photo_album(integer) returns integer
  language plpgsql
as
$$
DECLARE
  var_lang_id ALIAS FOR $1;
  var_module_id integer;
  var_xslt_templ_id integer;
  var_tree_list_id integer;
  var_article_id integer;
  var_album_id integer;
  var_list_id integer;
  var_category_id integer;

BEGIN

-- SELECT xt.id INTO var_xslt_templ_id FROM xslt_template xt, module m WHERE xt.module_id = m.id AND m.name = 'Photo album';
-- IF NOT FOUND THEN
   SELECT id INTO var_module_id FROM  module WHERE module.name = 'Photo album';
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Module <Photo album> not found';
        return -1;
    END IF;
    INSERT INTO xslt_template (module_id, title, xslt_visitor, xslt_admin, repository_template_id, xml_template_id)
       VALUES (var_module_id, 'photo_album', NULL, NULL, NULL, NULL);
    SELECT currval('xslt_template_id_seq') INTO var_xslt_templ_id ;

--END IF;

-- tree list
INSERT INTO list (name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id) VALUES ('Photo Album', var_lang_id, 1, '',       0,0,                    var_module_id,      '',        var_xslt_templ_id,  NULL);
SELECT currval('list_id_seq') INTO var_tree_list_id;

-- album
INSERT INTO article (lang_id, head, text, class) VALUES (var_lang_id, 'Album1','','cls');
SELECT currval('article_id_seq') INTO var_article_id;

INSERT INTO list_item (list_id, title, teaser_id, order_number, visible, link, image_link, type, view_date, publish_date, expired_date, document_link, created_by, created_date, last_modified_by, last_modified_date)
VALUES (var_tree_list_id, 'Album1 - various photos', var_article_id, 0, 1,NULL,NULL,NULL,'2004-02-09 00:00:00','2004-02-09 00:00:00','2005-02-09 00:00:00',NULL,NULL,NULL,NULL,NULL);
SELECT currval('list_item_id_seq') INTO var_album_id;

INSERT INTO list (name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id)
VALUES ('Various photos',var_lang_id, 1,'',0,0,NULL,'',var_xslt_templ_id, var_album_id);
SELECT currval('list_id_seq') INTO var_list_id;

-- Category
INSERT INTO article (lang_id, head, text, class) VALUES (var_lang_id,'Ukraine','','cls');
SELECT currval('article_id_seq') INTO var_article_id;

INSERT INTO list_item (list_id, title, teaser_id, order_number, visible, link, image_link, type, view_date, publish_date, expired_date, document_link, created_by, created_date, last_modified_by, last_modified_date)
VALUES (var_list_id, 'Ukraine', var_article_id, 0,1,NULL,NULL,NULL,'2004-02-09 00:00:00','2004-02-09 00:00:00','2005-02-09 00:00:00',NULL,NULL,NULL,NULL,NULL);
SELECT currval('list_item_id_seq') INTO var_category_id;

INSERT INTO list (name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id)
VALUES ('Ukraine', var_lang_id, 1, '', 0, 0, NULL, '', var_xslt_templ_id, var_category_id);
SELECT currval('list_id_seq') INTO var_list_id;

-- photo
INSERT INTO article (lang_id, head, text, class) VALUES (var_lang_id, 'cafe chantant goldengates','','cls');
SELECT currval('article_id_seq') INTO var_article_id;

INSERT INTO list_item (list_id, title, teaser_id, order_number, visible, link, image_link, type, view_date, publish_date, expired_date, document_link, created_by, created_date, last_modified_by, last_modified_date)
VALUES (var_list_id,'cafe chantant goldengates',var_article_id, 0,1,NULL,'media/photos/cafe chantant_goldengates.jpg',NULL,'2004-02-09 00:00:00','2004-02-09 00:00:00','2005-02-09 00:00:00',NULL,NULL,NULL,NULL,NULL);

RETURN var_tree_list_id;

END;
$$;

alter function add_photo_album(integer) owner to antonb2;

