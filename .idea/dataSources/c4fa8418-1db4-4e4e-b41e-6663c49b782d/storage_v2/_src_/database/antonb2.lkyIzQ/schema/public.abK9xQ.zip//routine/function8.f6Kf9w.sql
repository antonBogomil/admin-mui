create function function8() returns boolean
  language plpgsql
as
$$
BEGIN
  UPDATE animation_properties SET speed_of_animation = 90000;
  RETURN TRUE;
END;
$$;

alter function function8() owner to antonb2;

