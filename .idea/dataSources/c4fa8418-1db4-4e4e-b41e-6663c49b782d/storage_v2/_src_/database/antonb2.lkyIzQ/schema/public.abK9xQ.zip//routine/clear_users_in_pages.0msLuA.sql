create function clear_users_in_pages() returns trigger
  language plpgsql
as
$$
BEGIN
UPDATE page SET editedby = NULL WHERE editedby = OLD.id;
return OLD;
END;
$$;

alter function clear_users_in_pages() owner to antonb2;

