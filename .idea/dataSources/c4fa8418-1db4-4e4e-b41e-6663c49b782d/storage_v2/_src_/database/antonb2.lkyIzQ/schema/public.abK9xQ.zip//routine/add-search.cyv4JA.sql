create function "add-search"() returns boolean
  language plpgsql
as
$$
declare
    pageId int4;
    seqId int4;
    categoryRd record;
begin
     FOR categoryRd IN (SELECT * FROM page)
          LOOP
          pageId = categoryRd.id;
          select nextval('page_component_id_seq') into seqId;
          insert into page_component
                 (id, page_id, class_name) values
                 (seqId, pageId, 'advanced-search-component');
          END LOOP;
     RETURN 1;
end;
$$;

alter function "add-search"() owner to antonb2;

