create function copy_user_rights() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
   	memId integer;
    rec record;
BEGIN
	n:=0;
    
	delete from page;
	delete from permissions;
	delete from containers;
	delete from user_list;
    delete from members;
	delete from groups;
	delete from roles;
	
   	for rec in select * from roles1 loop
    	INSERT into roles(id, name, is_visitor)
			values (rec.id, rec.name, false);
		n:=n+1;
	end loop;
	update roles set is_visitor = true where name = 'visitor';
	
	for rec in select * from groups1 loop
    	INSERT into groups(id, name, role_id, site_id)
			values (rec.id, rec.name, rec.role_id, 1);
		n:=n+1;
	end loop;
    
    for rec in select * from user_list1 loop
    	INSERT into user_list(id, username, login, password, type, extra, site_id, publish_date, expired_date, single_user, guid, last_action_date)
			values (rec.id, rec.username, rec.login, rec.password, rec.type, rec.extra, 1, null, null, null, null, null);
		n:=n+1;
	end loop;
    
	for rec in select * from containers1 loop
    	INSERT into containers(id, name, site_id, is_default)
			values (rec.id, rec.name, 1, false);
		n:=n+1;
	end loop;
	INSERT into containers(id, name, site_id, is_default) values (3, 'Default', 1, true);	
	
	for rec in select * from permissions1 loop
    	INSERT into permissions(id, group_id, container_id)
			values (rec.id, rec.group_id, rec.container_id);
		n:=n+1;
	end loop;
	
	for rec in select * from members1 loop
	    select id into memId from user_list where id = rec.id;
        if (memId <> null) then
	    	INSERT into members(id, group_id, user_id)
				values (rec.id, rec.group_id, rec.user_id);
       		n:=n+1;
        end if;
	end loop;

    return n;
END;
$$;

alter function copy_user_rights() owner to antonb2;

