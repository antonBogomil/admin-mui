create function set_expired_modules(integer) returns text
  language plpgsql
as
$$
DECLARE
  siteID alias for $1;

  moduleName record;
  tmpName text;

BEGIN
     for moduleName in select * from module where site_id=1 and expired IS NOT NULL order by id
         loop
             update module set expired=(select golive from module
             where name = moduleName.name and site_id=1)
             where site_id=siteID and name = moduleName.name;
             tmpName := moduleName.name;
         end loop;
return tmpName;
END;
$$;

alter function set_expired_modules(integer) owner to antonb2;

