create function add_art_one() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  textP VARCHAR;
  articleId INTEGER;
begin
	ALTER TABLE "public"."nl_publication_i18n_fields"  ADD COLUMN "article_id" INTEGER;
    ALTER TABLE "public"."nl_publication_i18n_fields"
      ADD CONSTRAINT "fk_nl_publication_i18n_fields_article_id" FOREIGN KEY ("article_id")
        REFERENCES "public"."article"("id")
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
        NOT DEFERRABLE;  

	for rec in select * from nl_publication_i18n_fields loop
	    select nextval('article_id_seq') into articleId;
	    insert into article(id, lang_id, head, text) 
        	values(articleId, rec.lang_id, 'newsletter', 
            	(select text from nl_publication_i18n_fields where nl_publication_i18n_fields.id=rec.id));
        
        update nl_publication_i18n_fields set article_id=articleId where nl_publication_i18n_fields.id=rec.id;        
    	
	end loop;
           
	ALTER TABLE nl_publication_i18n_fields DROP COLUMN text;
	return true;
end;
$$;

alter function add_art_one() owner to antonb2;

