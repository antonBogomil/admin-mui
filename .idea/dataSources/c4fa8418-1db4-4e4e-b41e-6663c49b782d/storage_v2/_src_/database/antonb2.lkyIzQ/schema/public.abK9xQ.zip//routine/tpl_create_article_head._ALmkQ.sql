create function tpl_create_article_head(bigint, character varying) returns integer
  language plpgsql
as
$$
declare
    langId alias for $1;
    textArt alias for $2;
    articleId int4;
begin
	select nextval('article_id_seq') into articleId;
    IF textArt is NULL THEN 
	    insert into article
    	    (id, head, lang_id, text, class) values
	        (articleId, 'Product description article', langId, '', 'product_article');
    ELSE
	    insert into article
    	    (id, head, lang_id, text, class) values
        	(articleId, 'Product description article', langId, textArt, 'product_article');
    END IF;    
    return articleId;
end;
$$;

alter function tpl_create_article_head(bigint, varchar) owner to antonb2;

