create function function5() returns bigint
  language plpgsql
as
$$
  /* New function body */
declare
  rec record;
begin

   for rec in select * from dictionary WHERE lang_code='de' and entry='' loop
   
       UPDATE dictionary
       SET entry = (SELECT entry FROM dictionary WHERE lang_code='en' and entry_id=rec.entry_id LIMIT 1)
       WHERE id=rec.id;
   /*
       IF (SELECT lang_id FROM article WHERE id=rec.article_id LIMIT 1) = 1 THEN
       
          INSERT INTO article (lang_id, head, text, class, container_id)
                 VALUES
                 (
                        3,
                        (SELECT head FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT text FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT class FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT container_id FROM article WHERE id=rec.article_id LIMIT 1));
          
          INSERT INTO pm_category_articles (category_id, article_id)
                 VALUES
                 (rec.category_id, (SELECT MAX(id) FROM article LIMIT 1));
                 
                 
          INSERT INTO article (lang_id, head, text, class, container_id)
                 VALUES
                 (
                        4,
                        (SELECT head FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT text FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT class FROM article WHERE id=rec.article_id LIMIT 1),
                        (SELECT container_id FROM article WHERE id=rec.article_id LIMIT 1));

          INSERT INTO pm_category_articles (category_id, article_id)
                 VALUES
                 (rec.category_id, (SELECT MAX(id) FROM article LIMIT 1));
          
       END IF;
       --INSERT INTO string_resource (id, lang_id, text) VALUES (rec.id, 3,rec.text);
       --INSERT INTO string_resource (id, lang_id, text)VALUES (rec.id, 4,rec.text);
       */
    end loop;

  return 1;
end;
$$;

alter function function5() owner to antonb2;

