create function start_function_after_dump() returns boolean
  language plpgsql
as
$$
BEGIN
  UPDATE page SET sitemap_freq = 'DAILY';
  UPDATE page SET sitemap_prior = 0.5;
  UPDATE page SET container_id = 1;
  UPDATE page SET class = 'newsline' WHERE id=12;
  UPDATE guestbook SET author_email = 'noreply@negeso.com';
  INSERT INTO job_vac2lang_presence (SELECT id, 1, TRUE FROM job_vacancies);
  UPDATE job_vac2lang_presence SET is_present = false;
  RETURN TRUE;
END;
$$;

alter function start_function_after_dump() owner to antonb2;

