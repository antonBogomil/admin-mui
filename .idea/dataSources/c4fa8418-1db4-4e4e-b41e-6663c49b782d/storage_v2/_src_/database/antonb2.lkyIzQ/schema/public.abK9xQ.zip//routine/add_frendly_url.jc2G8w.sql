create function add_frendly_url() returns boolean
  language plpgsql
as
$$
declare
  recCat record;
  recCatRS record;
  recProd record;
  langCode VARCHAR;
  catURL VARCHAR;
  titleProd VARCHAR;
begin       
	DELETE FROM friendly_url WHERE friendly_url.entity_type_id = 0;
  	for recCat in select * from pm_category loop       
    
	  	for recCatRS in select * from string_resource where string_resource.id=recCat.rs_title loop        
        	select "language".code from "language" where id=recCatRS.lang_id into langCode;
            IF (recCatRS.text is NOT NULL) then
            	insert into friendly_url(entity_id, lang_id, entity_type_id, link, alternative_link) 
                  values(recCat.id, recCatRS.lang_id, 0, 
                  replace(replace(lower(recCatRS.text),' ','_'),'<br/>','_')||'_'||langCode, 
                  replace(replace(lower(recCatRS.text),' ','_'),'<br/>','_'));
            END IF;
	    end loop;
    end loop;
    return true;

end;
$$;

alter function add_frendly_url() owner to antonb2;

