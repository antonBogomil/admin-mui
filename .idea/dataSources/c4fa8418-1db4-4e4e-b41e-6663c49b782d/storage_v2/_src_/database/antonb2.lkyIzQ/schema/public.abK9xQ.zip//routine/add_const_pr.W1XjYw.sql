create function add_const_pr() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
  for rec in select * from pr_negeso_site_module_definition where label is not null loop
  	IF (select count(id) from dic_custom_const where KEY=rec.label) = 0 THEN 
	  	PERFORM public."add-const"((select id from module where name='portal'),rec.label,rec.description);
    END IF;
  end loop;
  for rec in select * from pr_negeso_core_definition where label is not null loop
  	IF (select count(id) from dic_custom_const where KEY=rec.label) = 0 THEN 
	  	PERFORM public."add-const"((select id from module where name='portal'),rec.label,rec.description);
    END IF;
  end loop;
  for rec in select * from pr_negeso_site_phase_definition where label is not null loop
  	IF (select count(id) from dic_custom_const where KEY=rec.label) = 0 THEN 
	  	PERFORM public."add-const"((select id from module where name='portal'),rec.label,rec.description);
    END IF;
  end loop;
  return true;
end;
$$;

alter function add_const_pr() owner to antonb2;

