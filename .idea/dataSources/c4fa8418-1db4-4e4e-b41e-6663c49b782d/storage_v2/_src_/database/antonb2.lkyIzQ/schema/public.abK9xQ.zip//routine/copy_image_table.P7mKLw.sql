create function copy_image_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;

	for rec in select * from image1 loop
    	INSERT into image(image_id, image_set_id, src, alt, max_width, max_height, 
        				  min_width, min_height, required_height, required_width, 
                          _order)
			values (rec.image_id, rec.image_set_id, rec.src, rec.alt, 
            		rec.max_width, rec.max_height, rec.min_width, rec.min_height, 
                    rec.required_height, rec.required_width, rec._order);
		n:=n+1;
    end loop;    

    return n;
END;
$$;

alter function copy_image_table() owner to antonb2;

