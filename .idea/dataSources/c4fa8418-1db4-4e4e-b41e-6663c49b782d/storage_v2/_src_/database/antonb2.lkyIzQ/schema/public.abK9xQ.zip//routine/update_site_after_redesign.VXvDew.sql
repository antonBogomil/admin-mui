create function update_site_after_redesign() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  pageId int4;
begin
  UPDATE images_set SET number_of_images=1 WHERE name='front';
  UPDATE images_set SET number_of_images=2 WHERE name='simple';
  UPDATE images_set SET number_of_images=2 WHERE name='poll_article';

  for rec in select * from images_set WHERE name='front' loop
    DELETE FROM image WHERE image_set_id=rec.image_set_id and _order>1;
    UPDATE image SET required_height=246 , required_width=371 , src='/site/media/picture_frame/front.jpg'
      WHERE image_set_id=rec.image_set_id;
  end loop;


  for rec in select * from images_set WHERE name='simple' loop
    DELETE FROM image WHERE image_set_id=rec.image_set_id and _order=3;
  end loop;

  for rec in select * from images_set WHERE name='poll_article' loop
    DELETE FROM image WHERE image_set_id=rec.image_set_id and _order=3;
  end loop;

  SELECT id FROM page WHERE class='frontpage' AND lang_id=1 LIMIT 1 INTO pageId;
  select tpl_create_article(pageId) into articleId;
  perform tpl_generate_article_by_id(pageId, articleId);
  UPDATE article SET head='mijn_aval_nl' WHERE id=articleId;

  select tpl_create_article(pageId) into articleId;
  perform tpl_generate_article_by_id(pageId, articleId);
  UPDATE article SET head='zakelijk_nl' WHERE id=articleId;

  select tpl_create_article(pageId) into articleId;
  perform tpl_generate_article_by_id(pageId, articleId);
  UPDATE article SET head='particulier_nl' WHERE id=articleId;

  for rec in select * from page where lang_id=1 and class!='frontpage' loop
    pageId := rec.id;
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='mijn_aval_nl' LIMIT 1));
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='zakelijk_nl' LIMIT 1));
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='particulier_nl' LIMIT 1));
  end loop;


  return true;
end;
$$;

alter function update_site_after_redesign() owner to antonb2;

