create function composer_add_faq(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    faqName alias for $1;
    typeName alias for $2;
    pageName alias for $3;

    langId integer := -1;
    templateId integer := -1;
    faqComponentListId integer := -1;
    firstCategoryListId integer := -1;
    pageElementId integer := -1;

    -- constatnts
    LIST_MODULE_ID integer := 3;
    LIST_COMPONENT_NAME varchar := 'list-component';
    LIST_PAGE_CLASS varchar := 'faq';


  LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';

  LIST_ITEM_PAGE_CLASS varchar := 'search_news';
  
    pageId integer := -1;
    articleId integer := -1;
    listItemId integer := -1;
    siteId integer := 1;
    categoryName varchar := 'Category 1';
    questionsList varchar := 'Question list for category 1';
  

BEGIN
    SELECT lang_id INTO langId FROM page WHERE filename=pageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;

  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = typeName) AND (module_id = MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, typeName)
    ;
  END IF;

  -- list
  SELECT nextval('list_id_seq') INTO faqComponentListId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, site_id)
    VALUES (faqComponentListId, faqName, langId, 1, '', 0, 0, LIST_MODULE_ID, faqName, templateId, siteId)
  ;
  
  SELECT id INTO pageId FROM page WHERE filename=pageName;
  IF pageId IS NULL THEN
    RETURN -1;
  END IF;

  UPDATE page SET class=typeName, protected='nodelete' WHERE id=pageId;

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'This is the FAQ sample text', NULL);
  
  -- list_item
  SELECT nextval('list_item_id_seq') INTO listItemId;
    INSERT INTO list_item (id, list_id, title, teaser_id, order_number, visible, publish_date, site_id)
    VALUES (listItemId, faqComponentListId, categoryName, articleId, 1, true, now(), siteId)
  ;

  -- list
  SELECT nextval('list_id_seq') INTO firstCategoryListId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id, site_id)
    VALUES (firstCategoryListId, questionsList, langId, 1, '', 0, 0, LIST_MODULE_ID, NULL, templateId, listItemId, siteId)
  ;

  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'faq-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'listId', faqComponentListId);

  RETURN 1;
END;
$$;

alter function composer_add_faq(varchar, varchar, varchar) owner to antonb2;

