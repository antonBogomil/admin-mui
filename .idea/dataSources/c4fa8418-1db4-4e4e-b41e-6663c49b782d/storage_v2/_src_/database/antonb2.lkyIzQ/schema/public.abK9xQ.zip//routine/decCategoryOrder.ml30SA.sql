create function "decCategoryOrder"(character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  categoryName alias for $1;
  currentOrder int := -1;
  maxOrder int := -1;
BEGIN

SELECT category.order_in_list FROM category WHERE category."name" = categoryName INTO currentOrder;

IF currentOrder is null
-- name parameter is wrong
   THEN RETURN false;
END IF;

IF currentOrder = 0
-- it is already min
   THEN RETURN false;
END IF;

UPDATE category SET order_in_list = currentOrder WHERE category."order_in_list" = currentOrder-1;
UPDATE category SET order_in_list = currentOrder-1 WHERE category."name" = categoryName;

RETURN TRUE;

END;
$$;

alter function "decCategoryOrder"(varchar) owner to antonb2;

