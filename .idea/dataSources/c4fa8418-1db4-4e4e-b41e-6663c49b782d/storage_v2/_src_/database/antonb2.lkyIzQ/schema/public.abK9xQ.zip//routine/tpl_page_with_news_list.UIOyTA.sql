create function tpl_page_with_news_list(integer, character varying) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    listName alias for $2;
    articleId int4;
    listId int4;
begin
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    select tpl_create_list(pageId, listName, 'News module', 'newslist') into listId;
    perform tpl_generate_list_by_id(pageId, listId);
    perform tpl_generate_list_item_by_id(pageId);
    return 1;
end;
$$;

alter function tpl_page_with_news_list(integer, varchar) owner to antonb2;

