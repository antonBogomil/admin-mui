create function delet_images_set_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
    
BEGIN

for rec in select * from page where (page.lang_id=8) loop

DELETE FROM image
WHERE  image_set_id = rec.attribute_set_id and src = 'media/banner_module/sm_5_en.jpg';
    end loop;
   return n;
END;
$$;

alter function delet_images_set_table() owner to antonb2;

