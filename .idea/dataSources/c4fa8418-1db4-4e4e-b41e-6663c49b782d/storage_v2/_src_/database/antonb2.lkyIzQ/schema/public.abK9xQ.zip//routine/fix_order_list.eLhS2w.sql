create function fix_order_list() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  i int4;
begin
i:=0;
  for rec in select id from list_item where list_id=63 ORDER by order_number loop
    update list_item set order_number = i where list_item.id=rec.id;
    i:=i+1;
  end loop;
  return true;
end;
$$;

alter function fix_order_list() owner to antonb2;

