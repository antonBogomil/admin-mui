create function days_left(timestamp without time zone, timestamp without time zone) returns integer
  language plpgsql
as
$$
declare
    publish alias for $1;
    expires alias for $2;
    curr constant timestamp := now();
    UNLIMITED constant int4 := 2147483647;
    NOT_PUBLISHED constant int4 := -1;
    EXPIRED constant int4 := -2;
begin
    if publish is not null and curr < publish then
        return NOT_PUBLISHED;
    end if;
    if expires is not null and curr >= expires then
        return EXPIRED;
    end if;
    if expires is null then
        return UNLIMITED;
    end if;
    return extract(day from (expires - curr));
end;
$$;

alter function days_left(timestamp, timestamp) owner to antonb2;

