create function addlocatie() returns boolean
  language plpgsql
as
$$
  /* New function body */
DECLARE
i integer;
j integer;
number integer;
rec1 record;
rec2 record;
begin
     for rec1 in select vacancy_id from job_extra_fields group by vacancy_id
     loop
        insert into job_extra_fields
         (type_id, vacancy_id, sys_name, order_number, is_required)
         values
         (1, rec1.vacancy_id, 'citizenship', 11, false);
     end loop;
RETURN true;
end;
$$;

alter function addlocatie() owner to antonb2;

