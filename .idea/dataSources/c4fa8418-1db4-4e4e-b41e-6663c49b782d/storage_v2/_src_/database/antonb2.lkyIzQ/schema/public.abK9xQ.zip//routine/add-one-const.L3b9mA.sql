create function "add-one-const"() returns boolean
  language plpgsql
as
$$
DECLARE
 rec integer;
BEGIN
	insert into dic_custom_const(module_id,key) values(NULL,'CORE.CHANGE_YOUR_LANGUAGE');
    for rec in (select id from core_reference) loop
    	insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key='CORE.CHANGE_YOUR_LANGUAGE'),rec,'Choose your language');
    end loop;
    return true;
END;
$$;

alter function "add-one-const"() owner to antonb2;

