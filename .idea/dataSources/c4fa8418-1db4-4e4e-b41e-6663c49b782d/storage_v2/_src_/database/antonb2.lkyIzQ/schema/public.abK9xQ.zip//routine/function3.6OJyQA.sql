create function function3(integer) returns integer
  language plpgsql
as
$$
  /* New function body */
declare
       page_id alias for $1;
begin
     return page_id;
end;
$$;

alter function function3(integer) owner to antonb2;

