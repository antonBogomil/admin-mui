create function addjobfield(integer) returns integer
  language plpgsql
as
$$
DECLARE
	vacancyId alias for $1;
BEGIN
  insert into job_extra_fields (type_id, is_required, vacancy_id, is_removed, order_number) values (14, 0, vacancyId, 0, 15);
  insert into job_extra_fields (type_id, is_required, vacancy_id, is_removed, order_number) values (15, 0, vacancyId, 0, 16);
  insert into job_extra_fields (type_id, is_required, vacancy_id, is_removed, order_number) values (16, 1, vacancyId, 0, 17);
  insert into job_extra_fields (type_id, is_required, vacancy_id, is_removed, order_number) values (17, 0, vacancyId, 0, 18);
  insert into job_extra_fields (type_id, is_required, vacancy_id, is_removed, order_number) values (18, 0, vacancyId, 0, 19);
  return 0;
END;
$$;

alter function addjobfield(integer) owner to antonb2;

