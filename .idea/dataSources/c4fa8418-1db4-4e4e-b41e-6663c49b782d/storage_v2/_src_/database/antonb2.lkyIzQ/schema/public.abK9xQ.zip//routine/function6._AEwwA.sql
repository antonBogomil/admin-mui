create function function6(page_id integer, head character varying) returns integer
  language plpgsql
as
$$
declare 
    pageId alias for $1; 
    customHead alias for $2; 
    langId int4; 
    articleId int4; 
begin 
    select lang_id into langId from page where id = pageId; 
    select nextval('article_id_seq') into articleId; 
    insert into article 
        (id, lang_id, text, head) values 
        (articleId, langId, '<p>Page is under construction</p>', customHead); 
    return articleId; 
end;
$$;

alter function function6(integer, varchar) owner to antonb2;

