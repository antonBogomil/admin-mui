create function add_picture_frame() returns boolean
  strict
  language plpgsql
as
$$
declare
  rec record;
begin

    for rec in select * from page WHERE attribute_set_id IS NULL  loop

	    INSERT INTO images_set
               VALUES(nextval('images_set_image_set_id_seq'), 'simple', Null, Null, Null, 1201, Null, Null, NULL);

        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/picture_frame/pic_frame1.jpg', Null, Null, Null, Null, Null, 685,1201,1);
        INSERT INTO image
               VALUES(nextval('image_image_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1), 'media/picture_frame/pic_frame1.jpg', Null, Null, Null, Null, Null, 685,1201,2);
               
        UPDATE page SET attribute_set_id=(SELECT MAX(image_set_id) FROM images_set LIMIT 1) WHERE id=rec.id;

        INSERT INTO wcms_attribute_set VALUES (nextval('wcms_attribute_set_wcms_attribute_set_id_seq'), Null);
        
        INSERT INTO wcms_attribute VALUES (nextval('wcms_attribute_wcms_attr_id_seq'), 1, '',(SELECT MAX(image_set_id) FROM images_set LIMIT 1), (SELECT MAX(wcms_attribute_set_id) FROM wcms_attribute_set LIMIT 1), Null, 'animation');
        INSERT INTO animation_properties values (nextval('animation_properties_id_seq'), (SELECT MAX(image_set_id) FROM images_set LIMIT 1));
    end loop;

  return true;
end;
$$;

alter function add_picture_frame() owner to antonb2;

