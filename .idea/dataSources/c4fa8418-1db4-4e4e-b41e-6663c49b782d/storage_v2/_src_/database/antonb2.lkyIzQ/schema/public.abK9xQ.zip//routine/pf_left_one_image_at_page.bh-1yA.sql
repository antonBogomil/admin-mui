create function pf_left_one_image_at_page() returns boolean
  language plpgsql
as
$$
DECLARE
	rec record;
BEGIN
	for rec in select * from image loop
		delete from image where image_set_id = rec.image_set_id and _order <> 1;
    end loop;
    return true;
END;
$$;

alter function pf_left_one_image_at_page() owner to antonb2;

