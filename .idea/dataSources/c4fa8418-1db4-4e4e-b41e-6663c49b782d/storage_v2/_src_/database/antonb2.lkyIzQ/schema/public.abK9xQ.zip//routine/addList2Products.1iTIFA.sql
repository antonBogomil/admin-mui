create function "addList2Products"() returns numeric
  language plpgsql
as
$$
DECLARE
  relatedListId integer := -1;
  accessoriesId integer := -1;
  rec record;
BEGIN
  SELECT id INTO relatedListId from pm_attribute_type where name = 'related_products';
  SELECT id INTO accessoriesId from pm_attribute_type where name = 'accessories';

for rec IN select * from pm_product loop

INSERT INTO pm_attribute_value (product_id, type_id, str_value, date_value, int_value, float_value, advstr_value, lang_id, money_value)
VALUES (rec.id, relatedListId, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO pm_attribute_value (product_id, type_id, str_value, date_value, int_value, float_value, advstr_value, lang_id, money_value)
VALUES (rec.id, accessoriesId, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

end loop;
return -1;
END;
$$;

alter function "addList2Products"() owner to antonb2;

