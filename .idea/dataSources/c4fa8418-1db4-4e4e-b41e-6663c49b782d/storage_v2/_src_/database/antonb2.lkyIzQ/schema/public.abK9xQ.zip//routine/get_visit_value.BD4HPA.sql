create function get_visit_value(integer, integer, date, date, character varying) returns character varying
  language plpgsql
as
$$
declare
  pid alias for $1;
  qid alias for $2;
  weekStart alias for $3;
  weekEnd alias for $4;
  qtype alias for $5;
  vid int4;
  val int4;
begin
  select id into vid from tracking_visit where person_id = pid and (day between weekStart and weekEnd);
  if vid is null then
    return '';
  end if;
  select into val value from tracking_answer where visit_id = vid and question_id = qid;
  if val is null then
    return '';
  end if;
  if qtype = 'number' then
    return val;
  end if;
  if val > 0 then
    return '+';
  else
    return '-';
  end if;
end;
$$;

alter function get_visit_value(integer, integer, date, date, varchar) owner to antonb2;

