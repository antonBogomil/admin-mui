create function tpl_perform_article1() returns integer
  language plpgsql
as
$$
  /* New function body */
declare
    pageId alias for $1;
    articleId alias for $2;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'article-component');
    insert into page_component_params
        (element_id, name, value) values
        (pageElemId, 'id', '1');
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'article-component');

    return pageElemId;
end;
$$;

alter function tpl_perform_article1() owner to antonb2;

