create function tpl_generate_list_by_id(integer, integer, integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    lists alias for $2;
    itemsPerPage alias for $3;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'news-line-component');
    insert into page_component_params
        (element_id, name, value) values
        (pageElemId, 'lists', lists);
    insert into page_component_params
        (element_id, name, value) values
        (pageElemId, 'itemsPerPage', itemsPerPage);
    return pageElemId;
end;
$$;

alter function tpl_generate_list_by_id(integer, integer, integer) owner to antonb2;

