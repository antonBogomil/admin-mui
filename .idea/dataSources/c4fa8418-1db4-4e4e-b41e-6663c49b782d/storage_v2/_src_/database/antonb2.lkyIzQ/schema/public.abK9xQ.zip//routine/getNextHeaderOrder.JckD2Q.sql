create function "getNextHeaderOrder"(integer) returns integer
  language plpgsql
as
$$
DECLARE
  categoryId alias for $1;
  nextOrderVal integer := 0;
BEGIN

SELECT MAX(header."order_in_list") FROM header WHERE header."category_id" = categoryId INTO nextOrderVal;

IF nextOrderVal is null
   THEN RETURN 0;
END IF;

RETURN nextOrderVal+1;

END;
$$;

alter function "getNextHeaderOrder"(integer) owner to antonb2;

