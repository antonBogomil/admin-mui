create function add_through_article_stub(integer) returns integer
  language plpgsql
as
$$
DECLARE
  pageId alias for $1;
  siteId int4;
  pageElemId int4;
  throughArtId VARCHAR;
BEGIN
 

	SELECT site_id INTO siteId FROM page WHERE id = pageId;
    SELECT  value INTO throughArtId
    	FROM page_component_params 
    	WHERE element_id = (SELECT id FROM page_component 
             						WHERE 	page_id IN(SELECT id FROM page WHERE site_id = siteId) 
              								AND class_name='through-article-component' LIMIT 1)
         LIMIT 1 ;
    
    
    IF (throughArtId IS NOT NULL) THEN
    	select nextval('page_component_id_seq') into pageElemId;
   		insert into page_component(id,page_id, class_name) values(pageElemId,pageId, 'through-article-component');
    	insert into page_component_params(element_id, name, value) values (pageElemId, 'id', throughArtId);
	END IF;
    
    return 1;

END;
$$;

alter function add_through_article_stub(integer) owner to antonb2;

