create function add_entry_to_dict() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  entryId text;
begin
  for rec in select * from dictionary loop
  IF rec.entry = '' THEN
     UPDATE dictionary SET entry = (SELECT entry FROM dictionary WHERE entry_id = rec.entry_id AND lang_code='en' LIMIT 1) WHERE id = rec.id;
  END IF;
  end loop;
  return true;
end;
$$;

alter function add_entry_to_dict() owner to antonb2;

