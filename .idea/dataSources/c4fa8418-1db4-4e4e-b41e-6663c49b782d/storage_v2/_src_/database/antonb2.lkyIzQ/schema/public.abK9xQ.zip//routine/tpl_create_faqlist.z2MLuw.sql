create function tpl_create_faqlist(integer, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    pageId alias for $1;
    faqName alias for $2; 
    moduleName alias for $3;  
    langId int4;
    templateId  int4;
    listId int4;
    siteId int4;

    -- constatnts
    LIST_MODULE_ID int4;
    LIST_COMPONENT_NAME varchar := 'list-component';
    LIST_PAGE_CLASS varchar := 'faq';
     LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';
    LIST_ITEM_PAGE_CLASS varchar := 'search_news';

BEGIN
 select lang_id into langId from page where id = pageId;
   

  -- xslt_template
  select id into LIST_MODULE_ID from module where name = moduleName;
  SELECT id INTO templateId FROM xslt_template WHERE (title = faqName) AND (module_id = LIST_MODULE_ID);
 
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, faqName)
    ;
  END IF;

  -- list
  select site_id into siteId  from page where id=pageId;
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, site_id)
    VALUES (listId, faqName, langId, 1, '', 0, 0, LIST_MODULE_ID, faqName, templateId, siteId)
  ;
 
    return listId;

END;
$$;

alter function tpl_create_faqlist(integer, varchar, varchar) owner to antonb2;

