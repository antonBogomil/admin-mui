create function add_art_one1() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId INTEGER;
  pageId INTEGER;
  menuId INTEGER;
  parentId INTEGER;
  articleText VARCHAR;
begin

	for rec in select * from "language" loop     
	    select id from page where class='frontpage' and page.lang_id=rec.id into pageId;
    	perform tpl_create_article_header(pageId, 'widget2');
    end loop;
  	for rec in select * from page where page.class!='popup' loop     	    
	    perform tpl_generate_article_through_by_id(rec.id,
    		(SELECT id from article WHERE head='widget2' AND lang_id=rec.lang_id LIMIT 1));                        	
    end loop;

	/*delete from page where page.lang_id=4 and page.class='simple';	       
  	for rec in select * from page1 where page1.lang_id=4 and page1.class='simple' loop 
	    select nextval('page_id_seq') into pageId;
	    insert into page(id,lang_id,filename,title,class,category,last_modified,protected,publish_date,expired_date,visible,container_id,attribute_set_id,site_id,meta_description,meta_keywords,property_value,google_script,is_search,property_name,edit_date,edit_user,meta_title,is_sitemap,sitemap_prior,sitemap_freq)
			values(pageId,rec.lang_id,rec.filename,rec.title,rec.class,rec.category,rec.last_modified,rec.protected,rec.publish_date,rec.expired_date,rec.visible,rec.container_id,rec.attribute_set_id,rec.site_id,rec.meta_description,rec.meta_keywords,rec.property_value,rec.google_script,rec.is_search,rec.property_name,rec.edit_date,rec.edit_user,rec.meta_title,rec.is_sitemap,rec.sitemap_prior,rec.sitemap_freq);        
    	perform tpl_generate_menu(pageId);
        
        
        select text from article1 where lang_id=4 and id::text in (
			select value from page_component_params1 where element_id in (
				select id from page_component1 where page_component1.class_name='article-component' and page_id in (
					select id from page1 where page1.id=rec.id
				)
			)
		) into articleText;
        IF articleText is NULL THEN
        	articleText:=' ';
        END IF;
        
		select nextval('article_id_seq') into articleId;
	    insert into article(id, lang_id, text) 
        	values(articleId, 4, articleText);        
    	perform tpl_generate_article_by_id(pageId, articleId);

    	perform tpl_generate_article_through_by_id(pageId,
    		(SELECT id from article WHERE head='footer' AND lang_id=4 LIMIT 1));
	    perform tpl_generate_article_through_by_id(pageId,
    		(SELECT id from article WHERE head='contact' AND lang_id=4 LIMIT 1));
	    perform tpl_generate_article_through_by_id(pageId,
    		(SELECT id from article WHERE head='widget' AND lang_id=4 LIMIT 1));    
        perform tpl_generate_article_through_by_id(pageId,
    		(SELECT id from article WHERE head='social' AND lang_id=4 LIMIT 1));
                   
    end loop;
    
    
   delete from menu where menu.id!=177 and menu.lang_id=4;
    for rec in select * from menu1 where menu1.lang_id=4 order by menu1.id  ASC loop     
	    select nextval('menu_id_seq') into menuId;
		IF rec.page_id is not NULL THEN 
			select id from page where page.filename in (select page1.filename from page1 where page1.id=rec.page_id) into pageId;     
    		insert into menu(id,parent_id,page_id,lang_id,title,link,order_number,keep_menu,site_id,publish_date,expired_date,old_id)
				values(menuId,null,pageId,rec.lang_id,rec.title,rec.link,rec.order_number,rec.keep_menu,rec.site_id,rec.publish_date,rec.expired_date,rec.id);                
		ELSE         
	        insert into menu(id,parent_id,page_id,lang_id,title,link,order_number,keep_menu,site_id,publish_date,expired_date,old_id)
				values(menuId,null,NULL,rec.lang_id,rec.title,rec.link,rec.order_number,rec.keep_menu,rec.site_id,rec.publish_date,rec.expired_date,rec.id);
        END IF;        	            
    end loop;   
    
    for rec in select * from menu where menu.lang_id=4 order by menu.parent_id loop         
	    select menu.id from menu where menu.old_id in (select menu1.parent_id from menu1 where menu1.id = rec.old_id) into parentId;
    	update menu set parent_id=parentId where menu.id=rec.id;
	end loop;   
    
    
    
    for rec in select * from article1 where lang_id=4 and id::text in (
			select value from page_component_params1 where element_id in (
				select id from page_component1 where page_component1.class_name='article-component' and page_id in (
					select id from page1 where page1.id in 
                    (select id from page1 where page1.lang_id=4 and page1.class!='simple')
				)
			)
		) loop
        
        update article set text=rec.text where article.lang_id=4 and article.id=rec.id;
    end loop;
   */
    return true;
    
end;
$$;

alter function add_art_one1() owner to antonb2;

