create function tpl_add_pm(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
begin
	insert into page_component
		(page_id, class_name) values (pageId, 'product-module-main');
	return pageId;
end;
$$;

alter function tpl_add_pm(integer) owner to antonb2;

