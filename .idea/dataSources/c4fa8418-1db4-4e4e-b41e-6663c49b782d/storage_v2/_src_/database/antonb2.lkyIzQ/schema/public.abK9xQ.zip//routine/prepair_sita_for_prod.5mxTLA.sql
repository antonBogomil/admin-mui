create function prepair_sita_for_prod() returns boolean
  language plpgsql
as
$$
BEGIN
  UPDATE page SET sitemap_freq = 'DAILY';
  UPDATE page SET sitemap_prior = 0.5;
  UPDATE wcms_attribute SET class = 'animation';
  RETURN TRUE;
END;
$$;

alter function prepair_sita_for_prod() owner to antonb2;

