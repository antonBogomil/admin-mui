create function pm_add_consts_for_product_types() returns integer
  language plpgsql
as
$$
DECLARE
	n INT4;	
    constStr VARCHAR;
	lower VARCHAR;
	upper VARCHAR;
    rec record;
BEGIN
	n:= 0;
    lower:= 'abcdefghijklmnopqrstuvwxyz ';
    upper:= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ_';
    FOR rec IN select * from pm_attribute_type order by id LOOP
        constStr:= 'PT' || rec.product_type_id || '_' || translate(rec.rs_name,lower,upper);
            
        insert into dic_custom_const(module_id,key) values(2,constStr);
		insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),1,rec.rs_name);
        insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),2,rec.rs_name);
        insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),3,rec.rs_name);
        insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),4,rec.rs_name);
        insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),5,'');
        insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constStr),6,'');

        n:=n+1;
    END LOOP;
    
    return n;
END;
$$;

alter function pm_add_consts_for_product_types() owner to antonb2;

