create function tpl_generate_webshop_customer_component(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    pId int4;
begin
	select nextval('page_component_id_seq') into pId;
    insert into page_component
                 (id, page_id, class_name) values
                 (pId, pageId, 'webshop-customer_component');
    return pId;
end;
$$;

alter function tpl_generate_webshop_customer_component(integer) owner to antonb2;

