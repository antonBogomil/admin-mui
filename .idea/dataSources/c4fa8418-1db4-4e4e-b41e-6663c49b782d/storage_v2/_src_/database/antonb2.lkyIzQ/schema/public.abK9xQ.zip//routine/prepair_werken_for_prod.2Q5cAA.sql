create function prepair_werken_for_prod() returns boolean
  language plpgsql
as
$$
DECLARE
  pageId int4 :=1;
  limitation int4 :=12;
  corePropNextID int4;
BEGIN
  SELECT nextval('core_property_id_seq') INTO corePropNextID;
  INSERT INTO page_component
    (page_id, class_name) values
    (pageId, 'latestVacanciesComponent');
  INSERT INTO core_property
  	(id, module_id , name, value, title, description, required, readonly, visible, reset_cache, site_id) VALUES
    (   corePropNextID,
    	(SELECT id FROM module WHERE module.name = 'job_module' LIMIT 1),
      	'latestVacanciesLimit',
        limitation,
        'Amount of visible latest vacancies',
        'Limit of amount latest vacancies on page',
        TRUE,
        FALSE,
        TRUE,
        TRUE,
        1
    );
  UPDATE page SET sitemap_freq = 'DAILY';
  UPDATE page SET sitemap_prior = 0.5;
  INSERT INTO job_vac2lang_presence SELECT id, 1, TRUE FROM job_vacancies;
  INSERT INTO job_dep2lang_presence SELECT id, 1, TRUE FROM job_departments;
  INSERT INTO animation_properties (image_set_id) select (image_set_id) from images_set;
  UPDATE job_field_types SET TYPE='text' WHERE id=4;
  UPDATE page SET class='mail_to_a_friend' WHERE id=25;
  UPDATE article SET head='ERKENDE' WHERE id=16;
  RETURN TRUE;
END;
$$;

alter function prepair_werken_for_prod() owner to antonb2;

