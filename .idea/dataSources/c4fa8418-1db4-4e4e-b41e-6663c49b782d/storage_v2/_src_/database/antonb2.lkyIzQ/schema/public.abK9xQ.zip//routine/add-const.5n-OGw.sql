create function "add-const"(integer, character varying, character varying) returns boolean
  language plpgsql
as
$$
DECLARE
 moduleId alias for $1;
 constName alias for $2;
 constValue alias for $3;
 rec integer;
BEGIN
	insert into dic_custom_const(module_id,key) values(moduleId,constName);
    for rec in (select id from core_reference) loop
    	insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key=constName),rec,constValue);
    end loop;
    return true;
END;
$$;

alter function "add-const"(integer, varchar, varchar) owner to antonb2;

