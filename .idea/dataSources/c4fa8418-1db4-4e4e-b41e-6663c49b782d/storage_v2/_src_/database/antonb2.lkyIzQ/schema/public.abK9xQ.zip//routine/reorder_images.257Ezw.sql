create function reorder_images(integer, integer) returns boolean
  language plpgsql
as
$$
DECLARE
       arg_img_id ALIAS FOR $1;
       direction ALIAS FOR $2;
       current_image RECORD;
       image2 RECORD;
       tmp integer;
       cur_im_id integer;
BEGIN
     IF arg_img_id <= 0 OR direction = 0 THEN
        RETURN NULL;
     END IF;
      SELECT * INTO current_image FROM image WHERE image_id = arg_img_id;
      IF current_image.image_id IS NULL THEN
         RETURN NULL;
      END IF;
      IF direction > 0 THEN
      --up
            SELECT * INTO image2 FROM image i1
                  WHERE i1.image_set_id = current_image.image_set_id
                  AND i1._order < current_image._order
                  AND NOT EXISTS (
                  SELECT 1 FROM image i2 WHERE i2.image_set_id = i1.image_set_id
                           AND i2._order < current_image._order
                           AND i1._order < i2._order);
      ELSE
      --down
           SELECT * INTO image2 FROM image i1
                  WHERE i1.image_set_id = current_image.image_set_id
                  AND i1._order > current_image._order
                  AND NOT EXISTS (
                  SELECT 1 FROM image i2 WHERE i2.image_set_id = i1.image_set_id
                           AND i2._order > current_image._order
                           AND i1._order > i2._order);

      END IF;

      IF image2.image_id IS NULL THEN
         RETURN NULL;
      END IF;

      tmp = current_image._order;
      cur_im_id =current_image.image_id;

      UPDATE image SET _order = image2._order
             WHERE image_id = current_image.image_id;

      UPDATE image SET _order = tmp
             WHERE image_id = image2.image_id;
      SELECT * INTO current_image FROM image WHERE image_id = arg_img_id;

      RETURN TRUE;
END;
$$;

alter function reorder_images(integer, integer) owner to antonb2;

