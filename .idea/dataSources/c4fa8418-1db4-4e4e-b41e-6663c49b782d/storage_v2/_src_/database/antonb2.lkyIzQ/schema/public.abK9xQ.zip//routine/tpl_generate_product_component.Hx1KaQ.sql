create function tpl_generate_product_component(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'product-module-main');
    return pageElemId;
end;
$$;

alter function tpl_generate_product_component(integer) owner to antonb2;

