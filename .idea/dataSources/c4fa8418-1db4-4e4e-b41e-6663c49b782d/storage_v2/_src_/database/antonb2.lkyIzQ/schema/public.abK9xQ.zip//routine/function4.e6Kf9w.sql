create function function4() returns boolean
  language plpgsql
as
$$
  /* New function body */
DECLARE
i integer;
rec record;
rec2 record;
begin
     for rec in select * from pm_attribute_type where is_i18n=true and product_type_id <>1
     loop
         for rec2 in select * from pm_attribute_value where type_id = rec.id and lang_id = 1
         loop
             for i in 2..4 loop
                 insert into pm_attribute_value (product_id, type_id, str_value, lang_id)
                        values (rec2.product_id, rec2.type_id, rec2.str_value, i);
             end loop;
         end loop;
     end loop;
RETURN true;
end;
$$;

alter function function4() owner to antonb2;

