create function tpl_create_article_with_head("Page ID" integer, "Head of article" character varying) returns integer
  language plpgsql
as
$$
DECLARE
	pageId alias for $1;
    head alias for $2;
    aricleId int4;
BEGIN
  SELECT tpl_create_article_header(pageId, head) INTO aricleId;
  PERFORM tpl_generate_article_through_by_id(pageId, aricleId);
  
  RETURN aricleId;
END;
$$;

alter function tpl_create_article_with_head(integer, varchar) owner to antonb2;

