create function add_newsletter_to_all_pages() returns boolean
  language plpgsql
as
$$
DECLARE
 rec record;
BEGIN
 for rec in select * from page loop
 insert into page_component(page_id,class_name) 
 values(rec.id, 'silver-newsletter-component'); 
 end loop;
return true;
END;
$$;

alter function add_newsletter_to_all_pages() owner to antonb2;

