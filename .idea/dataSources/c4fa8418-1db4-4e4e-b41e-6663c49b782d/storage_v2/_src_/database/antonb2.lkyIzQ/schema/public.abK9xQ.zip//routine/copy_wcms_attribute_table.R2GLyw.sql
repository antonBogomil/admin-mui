create function copy_wcms_attribute_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
   	for rec in select * from wcms_attribute1 loop
    	INSERT into wcms_attribute(wcms_attr_id, wcms_attr_type_id, name, image_set_id, 
        				  wcms_attribute_set_id, str_value, class)
			values (rec.wcms_attr_id, rec.wcms_attr_type_id, rec.name, 
            		rec.image_set_id, rec.wcms_attribute_set_id, rec.str_value, 
                    rec.class);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_wcms_attribute_table() owner to antonb2;

