create function add_article_all_pages() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
  for rec in select DISTINCT ON (id) id from page loop
    select tpl_create_article(rec.id) into articleId;
    perform tpl_generate_article_by_id(rec.id, articleId);
  end loop;
  return true;
end;
$$;

alter function add_article_all_pages() owner to antonb2;

