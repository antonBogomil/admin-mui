create function add_some_rte() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  pageId int4;
begin

  for rec in select * from page where lang_id=1 and (class is null) loop
    pageId := rec.id;
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='mijn_aval_nl' LIMIT 1));
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='zakelijk_nl' LIMIT 1));
    perform tpl_generate_article_by_id(pageId, (SELECT id FROM article WHERE head='particulier_nl' LIMIT 1));
  end loop;

  return true;
end;
$$;

alter function add_some_rte() owner to antonb2;

