create function copy_wcms_attribute_set_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;    
    
   	for rec in select * from wcms_attribute_set1 loop
    	INSERT into wcms_attribute_set(wcms_attribute_set_id, wcms_templ_id)
			values (rec.wcms_attribute_set_id, rec.wcms_templ_id);
		n:=n+1;
    end loop;
	
    return n;
END;
$$;

alter function copy_wcms_attribute_set_table() owner to antonb2;

