create function sync_animation_prop_with_image_set() returns boolean
  language plpgsql
as
$$
DECLARE
    i INTEGER;
BEGIN
    FOR i IN SELECT images_set.image_set_id FROM images_set LEFT OUTER JOIN animation_properties ON (images_set.image_set_id = animation_properties.image_set_id) WHERE id is null
    LOOP
        INSERT INTO animation_properties (image_set_id) VALUES (i);
    END LOOP;
    RETURN TRUE;
END
$$;

alter function sync_animation_prop_with_image_set() owner to antonb2;

