create function add_text_header_const() returns boolean
  language plpgsql
as
$$
DECLARE
 rec integer;
BEGIN
	insert into dic_custom_const(module_id,key) values(NULL,'PARALLAX_TOP_TEXT16');
    for rec in (select id from core_reference) loop
    	insert into dic_custom_translation(const_id,lang_id,translation) 
			values((select id from dic_custom_const where key='PARALLAX_TOP_TEXT16'),rec,'Negeso realizes your web design, website, webshop, portal, CMS, SEO, texts and apps');
    end loop;
    return true;
END;
$$;

alter function add_text_header_const() owner to antonb2;

