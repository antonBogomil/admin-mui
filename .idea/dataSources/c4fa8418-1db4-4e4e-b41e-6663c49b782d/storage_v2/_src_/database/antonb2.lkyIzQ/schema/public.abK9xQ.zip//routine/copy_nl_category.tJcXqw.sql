create function copy_nl_category() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
	
   	for rec in select * from nl_category1 where id <> 1 loop
    	INSERT into nl_subscription_category(id, title, order_number) 	
			values (rec.id, rec.rs_title, rec.order_number);		
		n:=n+1;
	end loop;
	
    return n;
END;
$$;

alter function copy_nl_category() owner to antonb2;

