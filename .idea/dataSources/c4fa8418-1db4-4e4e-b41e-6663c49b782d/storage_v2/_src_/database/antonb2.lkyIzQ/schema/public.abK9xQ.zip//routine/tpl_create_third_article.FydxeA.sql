create function tpl_create_third_article(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, langId, '', '<table width=547 height=421 border=0 cellpadding=0 cellspacing=0><tr><td width=547 height=35 valign=top class=templateLink><p><a href="">www.somelink.com</a>Here will be some text</p></td></tr></table>
    ');
    return articleId;
end;
$$;

alter function tpl_create_third_article(integer) owner to antonb2;

