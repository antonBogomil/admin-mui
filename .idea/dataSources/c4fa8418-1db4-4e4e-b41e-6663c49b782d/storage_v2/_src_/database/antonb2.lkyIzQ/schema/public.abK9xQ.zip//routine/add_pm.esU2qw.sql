create function add_pm() returns boolean
  language plpgsql
as
$$
DECLARE
	rec record;
BEGIN
	for rec In (select * from page) Loop
    	if not EXISTS (select * from page_component where page_id = rec.id and class_name='product-module-main') THEN
        	insert into page_component (page_id, class_name) VALUES 
            	(rec.id, 'product-module-main');
        end if;
        if not EXISTS (select * from page_component where page_id = rec.id and class_name='pm-filter') THEN
        	insert into page_component (page_id, class_name) VALUES 
            	(rec.id, 'pm-filter');
            insert into page_component_params (element_id, name, value) 
            	VALUES((select max(id) from page_component),'filterId', '8');
        end if;
    end loop;
    RETURN true;
END;
$$;

alter function add_pm() owner to antonb2;

