create function tpl_page_ordinary(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    articleId int4;
begin
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    return 1;
end;
$$;

alter function tpl_page_ordinary(integer) owner to antonb2;

