create function add_art() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
  for rec in select id, filename from page where lang_id=1 and filename!='e_order_nl.html' loop
	--update page set filename=(select replace(filename,'_nl.html','.html')) where id=rec.id;    
    --update article set text=(select replace(text,rec.filename,(select filename from page where id=rec.id)));
	update page set filename=(select replace(filename,'_','-')) where id=rec.id;    
    update article set text=(select replace(text,rec.filename,(select filename from page where id=rec.id)));
  end loop;
  update menu_item set link=(select replace(link,'_nl.html','.html')) where menu_item.menu_id in (select id from menu where menu.lang_id=1) and link!='e_order_nl.html';
  update menu_item set link=(select replace(link,'_','-')) where menu_item.menu_id in (select id from menu where menu.lang_id=1) and link!='e_order_nl.html';
  return true;
end;
$$;

alter function add_art() owner to antonb2;

