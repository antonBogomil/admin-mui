create function "user"() returns boolean
  language plpgsql
as
$$
Declare i integer;
existRow integer;
existRow1 integer;
maxGroupId integer;
Begin
maxGroupId = (select max(id) from groups);
for i in 1..(select max(id) from user_list)
loop
    existRow = (select group_id from members where user_id = i limit 1 );
    existRow1 = (select id from user_list where id = i limit 1 );
    if ((existRow is null) and not(existRow1 is null))
       then
           insert into members (group_id,user_id) values(maxGroupId,i);
    end if;
end loop;
return true;
end
$$;

alter function "user"() owner to antonb2;

