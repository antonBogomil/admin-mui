create function tpl_add_product_module(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    pageElemId int4;
begin
    insert into page_element
        (page_id, table_name, domain_table_record_id, class_name) values (pageId, 0, 0, 'product-module-main');
    return pageElemId;
end;
$$;

alter function tpl_add_product_module(integer) owner to antonb2;

