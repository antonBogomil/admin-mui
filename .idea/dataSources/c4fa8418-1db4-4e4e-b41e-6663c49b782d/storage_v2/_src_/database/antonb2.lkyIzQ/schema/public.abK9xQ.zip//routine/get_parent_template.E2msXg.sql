create function get_parent_template(integer) returns inet
  language plpgsql
as
$$
declare
    pageId alias for $1;
    template VARCHAR;
begin
	SELECT page."class" FROM page WHERE page.id IN 
    	(SELECT menu.page_id FROM menu WHERE menu.id IN (SELECT menu.parent_id FROM menu WHERE menu.page_id = pageId)) into template;
    IF template != NULL THEN
  		update page set class = template where id = pageId;
  	END IF;
    return 1;
end;
$$;

alter function get_parent_template(integer) owner to antonb2;

