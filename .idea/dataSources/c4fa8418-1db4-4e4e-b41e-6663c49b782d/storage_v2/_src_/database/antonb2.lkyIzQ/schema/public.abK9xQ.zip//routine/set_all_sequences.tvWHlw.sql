create function set_all_sequences() returns boolean
  language plpgsql
as
$$
DECLARE
       rec record;
BEGIN
     FOR rec IN Select relname from pg_class LOOP
         if (SELECT position('id_seq' IN rec.relname)) > 0  AND
               (SELECT position('pg' IN rec.relname)) < 1
               AND (SELECT position('image' IN rec.relname)) < 1
                then
                if EXISTS (select * from pg_class where relname= (SELECT replace (rec.relname, '_id_seq', ''))) then
                  EXECUTE 'select setval(''' || rec.relname || ''', (SELECT COALESCE (max(id), 0) +1 FROM '
                     || (SELECT replace (rec.relname, '_id_seq', ''))
                     || '), false)';
             end if;
         end IF;
     END LOOP;
     return true;
end
$$;

alter function set_all_sequences() owner to antonb2;

