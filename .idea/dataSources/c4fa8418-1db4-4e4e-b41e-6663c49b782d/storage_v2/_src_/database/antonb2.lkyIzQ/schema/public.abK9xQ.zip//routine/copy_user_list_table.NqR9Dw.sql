create function copy_user_list_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
BEGIN
	n:=0;
    
	delete from user_list;	
	
   	for rec in select * from user_list1 loop
    	INSERT into user_list(id, username, login, password, type, extra, site_id, publish_date, expired_date, single_user, guid, last_action_date)
			values (rec.id, rec.username, rec.login, rec.password, rec.type, rec.extra, rec.site_id, rec.publish_date, rec.expired_date, rec.single_user, rec.guid, rec.last_action_date);
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_user_list_table() owner to antonb2;

