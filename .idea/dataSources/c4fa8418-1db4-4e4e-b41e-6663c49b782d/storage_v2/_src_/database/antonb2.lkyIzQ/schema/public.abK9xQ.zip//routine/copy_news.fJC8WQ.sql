create function copy_news() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
	isVisible boolean := false;
	articleId integer;
    rec record;
BEGIN
	n:=0;
    
	delete from list_item;
	delete from list;
	
/*	INSERT INTO "public"."xslt_template" ("id", "module_id", "title", "xslt_visitor", "xslt_admin") VALUES (1, 1, 'newslist', NULL, NULL);*/

   	for rec in select * from list1 loop
    	INSERT into list(id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id, container_id, site_id)
			values (rec.id, rec.name, rec.lang_id, rec.frozen, rec.item_name, rec.image_width, rec.image_height, rec.module_id, rec.instance_name, rec.template_id, rec.parent_list_item_id, rec.container_id, 1);
		n:=n+1;
	end loop;
    
    for rec in select * from list_item1 loop
    	if (rec.visible = 1) then 
			isVisible := true;
		end if;
		
		select id into articleId from article where id = rec.article_id;
		if (articleId is not null) then
			INSERT into list_item(id, list_id, title, teaser_id, order_number, visible, link, image_link, document_link, type, view_date, publish_date, expired_date, created_by, created_date, last_modified_by, 
				last_modified_date, article_id, thumbnail_link, list_item_link, parameters, container_id, site_id, per_lang_id)
			values (rec.id, rec.list_id, rec.title, rec.teaser_id, rec.order_number, isVisible, rec.link, rec.image_link, rec.document_link, rec.type, rec.view_date, rec.publish_date, rec.expired_date, 
				rec.created_by, rec.created_date, rec.last_modified_by, rec.last_modified_date, rec.article_id, rec.thumbnail_link, rec.list_item_link, rec.parameters, rec.container_id, 1, null);
		end if;
		
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_news() owner to antonb2;

