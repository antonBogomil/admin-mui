create function product_prop(integer, character varying, character varying, integer, integer, character varying) returns character varying
  language plpgsql
as
$$
  /* New function body */
DECLARE
       rec record;
       p_id integer;
begin
     p_id = (select currval('pm_product_id_seq'));
     for rec IN select * from pm_attribute_type where name=$3
               and product_type_id=$4 limit 1 loop
     if (rec.type_name = 'select_dropdown') then
        if(rec.is_i18n='true') then
            insert into pm_attribute_value (product_id, type_id, int_value, lang_id)
                   values(p_id, rec.id, (select id from pm_predefined_values where
                   (select lower (str_value)) = (select lower ($2)) and
                   lang_id=$5 and type_id=rec.id), $5);
            return (select $6 || ' -> ' || rec.name || ' value was added for language ' || $5);
        elsif (rec.is_i18n='false' and $5=1) then
            insert into pm_attribute_value (product_id, type_id, int_value, lang_id)
                   values(p_id, rec.id, (select id from pm_predefined_values where
                   (select lower (str_value)) = (select lower ($2)) and
                   lang_id=$5 and type_id=rec.id), $5);
            return (select $6 || ' -> ' || rec.name || ' value was added for language ' || $5);
        end if;

     elsif(rec.type_name='number' and $5=1) then
        if ($2 != '' ) then
           insert into pm_attribute_value (product_id, type_id, int_value, lang_id)
                   values(p_id, rec.id, (select int8($2)), $5);
        ELSE
            insert into pm_attribute_value (product_id, type_id, int_value, lang_id)
                   values(p_id, rec.id, null, $5);
        end if;
        return (select $6 || ' -> ' || rec.name || ' value was added for language ' || $5);
     elsif((rec.type_name='string') or (rec.type_name='text') or (rec.type_name='checkbox')) then
        if(rec.is_i18n='true') then
            insert into pm_attribute_value (product_id, type_id, str_value, lang_id)
                    values(p_id, rec.id, (select replace($2, 'T00:00:00.000', '')), $5);
            return (select $6 || ' -> ' || rec.name || ' value was added for language ' || $5);

        elsif (rec.is_i18n='false' and $5=1) then
           insert into pm_attribute_value (product_id, type_id, str_value, lang_id)
                  values(p_id, rec.id, $2, $5);
           return (select $6 || ' -> ' || rec.name || ' value was added for language ' || $5);
        end if;

     elsif(rec.type_name='doc_file' and $5 =1) then
           insert into pm_attribute_value (product_id, type_id, str_value, lang_id)
                  values(p_id, rec.id, $2, $5);
           return (select $6 || ' -> ' || rec.name || ' (doc_file) value was added for language ' || $5);

     elsif(rec.type_name='thumbnail' and $5=1) then
          if ($2 != '' ) then
             insert into pm_attribute_value (product_id, type_id, str_value, advstr_value, lang_id)
                  values(p_id, rec.id, (select 'media/products/' || $2), (select 'media/products/' || $2), $5);
              return (select $6 || ' -> ' || rec.name || ' (thumbnail) value was added for language ' || $5);
          else
              insert into pm_attribute_value (product_id, type_id, str_value, advstr_value, lang_id)
                  values(p_id, rec.id, '/images/no_image_98.gif', '/images/no_image_98.gif', $5);
              return (select $6 || ' -> ' || rec.name || ' (thumbnail) value was added for language ' || $5);
          end if;

     elsif(rec.type_name='article') then
           insert into article (lang_id, head, text, class)
                  VALUES (1, 'Product description article', $2, 'product_article');
           insert into pm_attribute_value (product_id, type_id, int_value, lang_id)
                  values (p_id, rec.id, (select currval('article_id_seq')), $5);
           return (select $6 || ' -> ' || rec.name || ' (article) value was added for language ' || $5);
     end if;
end loop;
return (select $6 || ' -> ' || rec.name || ' value was !!!NOT!!! added for language ' || $5);
end;
$$;

alter function product_prop(integer, varchar, varchar, integer, integer, varchar) owner to antonb2;

