create function function6() returns integer
  language plpgsql
as
$$
DECLARE
   pageId int4;
    seqId int4;
    categoryRd record;
BEGIN
 
  RETURN NULL;
END;
$$;

alter function function6() owner to antonb2;

