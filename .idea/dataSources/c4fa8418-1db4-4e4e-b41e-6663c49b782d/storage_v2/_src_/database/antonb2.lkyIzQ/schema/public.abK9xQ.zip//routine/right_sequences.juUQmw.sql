create function right_sequences() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  tmp varchar;

BEGIN

	for rec in select * from pg_class where relowner = 16389 and relkind = 'r'
    loop 
		if (rec.relname != 'inq_answer_question' and 
	        rec.relname != 'image' and 
   	        rec.relname != 'job_dep2lang_presence' and 
            rec.relname != 'job_vac2lang_presence' and 
            rec.relname != 'pm_category_articles' and             
            rec.relname != 'pm_order' and
            rec.relname != 'pm_ideal_payment' and
            rec.relname != 'pm_payment_status' and
            rec.relname != 'pm_payment_kind' and
            rec.relname != 'pm_order_status' and            
            rec.relname != 'pm_product_status' and                        
            rec.relname != 'wcms_attribute' and                                    
            rec.relname != 'users_cookies' and
            rec.relname != 'roles' and            
            rec.relname != 'wcms_attr_template' and            
            rec.relname != 'wcms_attr_type' and                        
            rec.relname != 'wcms_attribute_set' and                                    
            rec.relname != 'images_set' and                                                
            rec.relname != 'string_resource' and
            rec.relname != 'universo_zip_codes' and            
        	rec.relname != 'inq_answer_option') 
        then
            execute 'select setval(\'' || rec.relname || '_id_seq' || '\', (select max(id) from "public"."' || rec.relname ||'"));';
	    	execute 'ALTER TABLE "public"."' || rec.relname ||'" ALTER COLUMN "id" SET DEFAULT nextval(\'' || rec.relname || '_id_seq' || '\')';
		end if;           
        
  		if (rec.relname != 'inq_answer_question' and 
	        rec.relname != 'image' and 
   	        rec.relname != 'job_dep2lang_presence' and 
            rec.relname != 'job_vac2lang_presence' and 
            rec.relname != 'job_strings' and 
            rec.relname != 'pm_category_articles' and             
            rec.relname != 'pm_order' and
            rec.relname != 'sl_company' and          
            rec.relname != 'sl_shop' and
            rec.relname != 'sl_region' and                          
            rec.relname != 'pm_ideal_payment' and
            rec.relname != 'pm_payment_status' and
            rec.relname != 'pm_payment_kind' and
            rec.relname != 'pm_order_status' and            
            rec.relname != 'pm_product_status' and                        
            rec.relname != 'wcms_attribute' and                                    
            rec.relname != 'users_cookies' and
            rec.relname != 'roles' and            
            rec.relname != 'wcms_attr_template' and            
            rec.relname != 'wcms_attr_type' and                        
            rec.relname != 'wcms_attribute_set' and                                    
            rec.relname != 'images_set' and                                                
            rec.relname != 'string_resource' and
            rec.relname != 'universo_zip_codes' and            
        	rec.relname != 'inq_answer_option') 
        then
            execute 'DROP SEQUENCE "public"."' || rec.relname || '_id_seq1"'; 
		end if;           
    end loop;
	return true;
END;
$$;

alter function right_sequences() owner to antonb2;

