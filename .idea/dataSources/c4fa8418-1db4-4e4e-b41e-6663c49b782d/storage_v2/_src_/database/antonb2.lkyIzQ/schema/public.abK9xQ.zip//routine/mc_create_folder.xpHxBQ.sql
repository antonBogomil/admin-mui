create function mc_create_folder(character varying, integer) returns integer
  language plpgsql
as
$$
declare
  inputPath alias for $1;
  containerId alias for $2;
  
    mcFolderId int4 :=1;
begin

  SELECT id INTO mcFolderId FROM mc_folder WHERE path=inputPath;
  IF mcFolderId IS NULL THEN
    SELECT nextval('mc_folder_id_seq') INTO mcFolderId;
      INSERT INTO mc_folder(id, path, container_id) 
        VALUES(mcFolderId, inputPath, containerId);
  END IF;

    return mcFolderId;
end;
$$;

alter function mc_create_folder(varchar, integer) owner to antonb2;

