create function job_insert_test_data() returns integer
  language plpgsql
as
$$
declare
    deptId int4 :=1;
    articleId int4 :=1;
    langId int4 :=1;
    vacancyId int4 :=1;
    fieldTypeId int4 :=1;
    stringId int4 :=1;
    templateId int4 :=1;

    ttlTypeId int4 :=1;
    ageTypeId int4 :=1;
    jTechTypeId int4 :=1;
    jobTimeTypeId int4 :=1;

    applicationId int4 :=1;

    genVacField1Id int4 :=1;
    genVacField2Id int4 :=1;
    genVacField3Id int4 :=1;

    -- constatnts
  GENERAL_DEPT_ID integer := 1;
  
    genTmp int4 :=1;
    
begin
    SELECT * FROM job_insert_menu(5, 1) INTO genTmp;
    -- ----------------------------------------------Departments
    -- General department
    INSERT INTO job_departments (id, title, email, description) 
      VALUES (GENERAL_DEPT_ID, 'Company', 'it@negeso.com', 'General company');
    SELECT setval('job_departments_id_seq', GENERAL_DEPT_ID) INTO deptId;

    INSERT INTO job_departments (title, email, description) 
      VALUES ('Sales', 'sales@negeso.com', 'Saling managers and technologiesn live here');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Software development', 'it@negeso.com', 'Software development');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Human resources', 'pr@negeso.com', 'Humain resources management and planning');
    INSERT INTO job_departments (title, email, description) 
      VALUES ('Analytics & statistics', 'sales@negeso.com', 'Analytic research and statistics colections');

    -- --------------------------------STANDARD TEMPLATE------------
  SELECT nextval('job_templates_id_seq') INTO templateId;
    INSERT INTO job_templates(id, sys_name) VALUES(templateId, 'job_common_fields');

  -- FIRST NAME
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Fist name');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Fist name_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'first_name');

  -- SECOND NAME
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Second name');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Second name_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'second_name');

  -- ADDRESS LINE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Address line');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Address line_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'address_line');

  -- PHONE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Phone');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Phone_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'phone');

  -- MOBILE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Mobile');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Mobile_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'mobile');

  -- EMAIL
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'email', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Email');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Email_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 1, templateId, 'email');

  -- BIRTHDAY
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'date', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Birthday');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Birthday_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 0, templateId, 'birthday');

  -- BIRTH_PLACE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Birthplace');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Birthplace_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 0, templateId, 'birthplace');

  -- CITIZENSHIP
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Citizenship');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Citizenship_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 0, templateId, 'citizenship');

  -- CV_FILE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'file', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Upload CV');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Upload CV_nl');

    INSERT INTO job_extra_fields (type_id, is_required, template_id, sys_name) 
      VALUES (fieldTypeId, 0, templateId, 'cv_file');

    -- ------------------------------------------------Field types
    -- Title
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO ttlTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (ttlTypeId, 'radio_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Title');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Title_nl');

    -- Mr option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (ttlTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Mr');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Mr_nl');

    -- Miss option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (ttlTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Miss');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Miss_nl');

    -- Age
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO ageTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (ageTypeId, 'number', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Age');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Age_nl');

    -- Java technology
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO jTechTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (jTechTypeId, 'check_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Java technology');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Java technology_nl');

    -- Servlets option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Servlets');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Servlets');

    -- JSP option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Java Server Pages (JSP)');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Java Server Pages (JSP)_nl');

    -- EJB option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jTechTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Enterprise Java Beans (EJB)');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Enterprise Java Beans (EJB)_nl');

    -- jobTime
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO jobTimeTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (jobTimeTypeId, 'select_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Job time');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Job time_nl');

    -- Full time
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jobTimeTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Full time');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Full time_nl');

    -- Half time
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jobTimeTypeId, 0, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Half time');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Half time_nl');


    -- ------------------------------------------------Vacancies
    -- general vacancy
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'This is the vacancy text', 'job');
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Sales manager', articleId, 'Team leader', '500', '1', now(), NULL, GENERAL_DEPT_ID);

  SELECT nextval('job_extra_fields_id_seq') INTO genVacField1Id;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id) 
      VALUES (genVacField1Id, ttlTypeId, 1, vacancyId);

  SELECT nextval('job_extra_fields_id_seq') INTO genVacField2Id;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id) 
      VALUES (genVacField2Id, ageTypeId, 0, vacancyId);

  SELECT nextval('job_extra_fields_id_seq') INTO genVacField3Id;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id) 
      VALUES (genVacField3Id, jTechTypeId, 0, vacancyId);

    -- IT department vacancy
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'This is the vacancy text', 'job');
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Java developer', articleId, NULL, '500', '3', now(), NULL, 2);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (ageTypeId, 0, vacancyId);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (jTechTypeId, 1, vacancyId);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (jobTimeTypeId, 0, vacancyId);


    -- Information manager
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'This is the vacancy text', 'job');
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Dirty information manager', articleId, 'Project manager', '500', '3', now(), NULL, 3);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (ttlTypeId, 1, vacancyId);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (ageTypeId, 0, vacancyId);

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id) 
      VALUES (jobTimeTypeId, 0, vacancyId);

    -- ------------------------------------------------Application
    -- general application
  SELECT nextval('job_applications_id_seq') INTO applicationId;
    INSERT INTO job_applications (id, name, surname, address, telephone, mobile, email, birthdate, birthplace, citizenship, cv, post_date)
        VALUES (applicationId, 'Jonny', 'Smith', 'New Avenu 115', '8-800-287-99-00', NULL, 'jonny@negeso.com', '1980-01-03','New-York', 'Washington', NULL, now());

    INSERT INTO job_application_field_values (application_id, extra_field_value_id, extra_field_value, extra_field_id) 
        VALUES (applicationId, 1, NULL, genVacField1Id);

    INSERT INTO job_application_field_values (application_id, extra_field_value_id, extra_field_value, extra_field_id) 
        VALUES (applicationId, NULL, '18', genVacField2Id);

    INSERT INTO job_application_field_values (application_id, extra_field_value_id, extra_field_value, extra_field_id) 
        VALUES (applicationId, NULL, '1,2,3', genVacField3Id);
        
    INSERT INTO job_dva (application_id, department_id, vacancy_id, application_status) 
      VALUES (applicationId, 2, 2, 'new');

    -- general department application

    -- concrete vacancy application


  

    return 1;
end;
$$;

alter function job_insert_test_data() owner to antonb2;

