create function tpl_generate_banner(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    pId int4;
begin
    select nextval('page_component_id_seq') into pId;
    insert into page_component
                 (id, page_id, class_name) values
                 (pId, pageId, 'banner-module-component');
    return pId;
end;
$$;

alter function tpl_generate_banner(integer) owner to antonb2;

