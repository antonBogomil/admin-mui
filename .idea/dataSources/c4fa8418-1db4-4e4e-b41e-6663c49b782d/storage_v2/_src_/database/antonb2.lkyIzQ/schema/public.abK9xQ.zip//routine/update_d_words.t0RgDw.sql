create function update_d_words() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
 
begin	


 for rec in select * from d_words_old loop

	select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text, class) values
        (articleId, 1, 'Enter your text here', (select article_old.text from article_old where article_old.id = rec.article_id), 'cls') ;
	insert into d_words(id, word, article_id) 
	VALUES (rec.id, rec.word, articleId);
    
  end loop;
  return true;
  
  end;
$$;

alter function update_d_words() owner to antonb2;

