create function tpl_generate_menu(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
begin
    insert into page_component
        (page_id, class_name) values
        (pageId, 'menu-component');
    return 1;
end;
$$;

alter function tpl_generate_menu(integer) owner to antonb2;

