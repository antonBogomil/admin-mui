create function reindex_all_indexes() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
  for rec in select * from pg_class where relkind = 'i' and relname not like 'pg_%' loop
  	execute 'REINDEX INDEX ' || rec.relname;
  end loop;
  return true;
END;
$$;

alter function reindex_all_indexes() owner to antonb2;

