create function update_meta_description() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  
begin	


 for rec in select page_old.meta_description, page_old.meta_keywords, page_old.filename from page_old loop
 
 
	update page set meta_description=rec.meta_description, meta_keywords=rec.meta_keywords
    	where page.filename=rec.filename;
    

  end loop;
  return true;
  
  end;
$$;

alter function update_meta_description() owner to antonb2;

