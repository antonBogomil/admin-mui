create function "incHeaderOrder"(character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  headerName alias for $1;
  currentOrder int := -1;
  maxOrder int := -1;
BEGIN

SELECT header.order_in_list FROM header WHERE header."name" = headerName INTO currentOrder;

IF currentOrder is null
-- name parameter is wrong
   THEN RETURN false;
END IF;

SELECT "getNextHeaderOrder"() INTO maxOrder;

IF currentOrder = maxOrder-1
-- it is already in max order
   THEN RETURN false;
END IF;

UPDATE header SET order_in_list = currentOrder WHERE header."order_in_list" = currentOrder+1;
UPDATE header SET order_in_list = currentOrder+1 WHERE header."name" = headerName;

RETURN TRUE;

END;
$$;

alter function "incHeaderOrder"(varchar) owner to antonb2;

