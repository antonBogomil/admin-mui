create function is_parent_category(integer, integer) returns boolean
  language plpgsql
as
$$
  /* New function body */

DECLARE
     cat_id alias for $1;
     parentid alias for $2;
BEGIN
     IF (cat_id = parentid) THEN
          RETURN TRUE;
     END IF;
     IF EXISTS (SELECT parent_id FROM pm_category where id = cat_id)THEN
        IF (parentid = (SELECT parent_id FROM pm_category where id = cat_id)) THEN
           RETURN TRUE;
        ELSE
            RETURN (SELECT is_parent_category((SELECT parent_id FROM pm_category where id = cat_id), parentid));
        END IF;
     ELSE
         RETURN FALSE;
     END IF;
END;
$$;

alter function is_parent_category(integer, integer) owner to antonb2;

