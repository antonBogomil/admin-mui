create function "add-animated-pf"() returns integer
  language plpgsql
as
$$
DECLARE
  rec record;  
  n INTEGER;
  wcmsAttrId INTEGER;
  oldImageSetName VARCHAR;
  newImageSetId INTEGER;
BEGIN
	n:=0;
	for rec in (select * from image where required_height = 426) loop
    	select name into oldImageSetName from images_set where image_set_id = rec.image_set_id;
        select wcms_attribute_set_id into wcmsAttrId from wcms_attribute where image_set_id = rec.image_set_id;

    	insert into images_set (name, max_width) values(oldImageSetName, 504);
		select max(image_set_id) into newImageSetId from images_set;
        
		update image set image_set_id = newImageSetId where image_id = rec.image_id;
		insert into animation_properties(image_set_id) values(newImageSetId);
		insert into wcms_attribute (image_set_id, name, wcms_attr_type_id, wcms_attribute_set_id,class) values(newImageSetId, '', 1, wcmsAttrId, 'animation');
    
    	n := n + 1;
    end loop;
    
	return n;
END;
$$;

alter function "add-animated-pf"() owner to antonb2;

