create function gl_insert_test_data() returns integer
  language plpgsql
as
$$
declare
    wordId int4 :=1;
    catId int4 :=1;
    articleId int4 :=1;
begin
    --English language lang_id=1
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible, container_id, attribute_set_id)
        VALUES (nextval('page_id_seq'), 1, 'dictionary_en.html', 'Dictionary', NULL, 'glossary_module', 'page', '2004-12-06 17:41:38.375', NULL, '2004-12-04 00:00:00', NULL, 1, NULL, NULL);

    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
           VALUES (nextval('menu_item_id_seq'), 7, 'Dictionary', 'dictionary_en.html', 4, NULL, 1, 'page');

    INSERT INTO page_element (id, page_id, table_name, domain_table_record_id, class_name, container_id)
        VALUES (nextval('page_element_id_seq'), currval('page_id_seq'), '0', 0, 'glossary-component', NULL);

    INSERT INTO page_element (id, page_id, table_name, domain_table_record_id, class_name, container_id)
        VALUES (nextval('page_element_id_seq'), currval('page_id_seq'), '0', 0, 'menu-component', NULL);

    --Dutch language lang_id=2
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible, container_id, attribute_set_id)
        VALUES (nextval('page_id_seq'), 2, 'dictionary_nl.html', 'Dictionary', NULL, 'glossary_module', 'page', '2004-12-06 17:41:38.375', NULL, '2004-12-04 00:00:00', NULL, 1, NULL, NULL);

    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
           VALUES (nextval('menu_item_id_seq'), 19, 'Dictionary', 'dictionary_nl.html', 4, NULL, 1, 'page');

    INSERT INTO page_element (id, page_id, table_name, domain_table_record_id, class_name, container_id)
        VALUES (nextval('page_element_id_seq'), currval('page_id_seq'), '0', 0, 'glossary-component', NULL);

    INSERT INTO page_element (id, page_id, table_name, domain_table_record_id, class_name, container_id)
        VALUES (nextval('page_element_id_seq'), currval('page_id_seq'), '0', 0, 'menu-component', NULL);

    --Alphabet
    INSERT INTO d_alphabet ("letter") VALUES ('A');
    INSERT INTO d_alphabet ("letter") VALUES ('B');
    INSERT INTO d_alphabet ("letter") VALUES ('C');
    INSERT INTO d_alphabet ("letter") VALUES ('D');
    INSERT INTO d_alphabet ("letter") VALUES ('E');
    INSERT INTO d_alphabet ("letter") VALUES ('F');
    INSERT INTO d_alphabet ("letter") VALUES ('G');
    INSERT INTO d_alphabet ("letter") VALUES ('H');
    INSERT INTO d_alphabet ("letter") VALUES ('I');
    INSERT INTO d_alphabet ("letter") VALUES ('J');
    INSERT INTO d_alphabet ("letter") VALUES ('K');
    INSERT INTO d_alphabet ("letter") VALUES ('L');
    INSERT INTO d_alphabet ("letter") VALUES ('M');
    INSERT INTO d_alphabet ("letter") VALUES ('N');
    INSERT INTO d_alphabet ("letter") VALUES ('O');
    INSERT INTO d_alphabet ("letter") VALUES ('P');
    INSERT INTO d_alphabet ("letter") VALUES ('Q');
    INSERT INTO d_alphabet ("letter") VALUES ('R');
    INSERT INTO d_alphabet ("letter") VALUES ('S');
    INSERT INTO d_alphabet ("letter") VALUES ('T');
    INSERT INTO d_alphabet ("letter") VALUES ('U');
    INSERT INTO d_alphabet ("letter") VALUES ('V');
    INSERT INTO d_alphabet ("letter") VALUES ('W');
    INSERT INTO d_alphabet ("letter") VALUES ('X');
    INSERT INTO d_alphabet ("letter") VALUES ('Y');
    INSERT INTO d_alphabet ("letter") VALUES ('Z');

    select into wordId last_value from d_words_id_seq;
    if wordId != 1 then
       wordId = wordId + 1;
    end if;

    select into catId last_value from d_category_id_seq;
    if catId != 1 then
       catId = catId + 1;
    end if;

    select into articleId last_value from article_id_seq;
    if articleId != 1 then
       articleId = articleId + 1;
    end if;

    --Category
    INSERT INTO d_category ("name") VALUES ('Category1');
    INSERT INTO d_category ("name") VALUES ('Category2');

    --Article
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'monkey desc', 'glossary_desc', NULL, NULL);
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'apple desc', 'glossary_desc', NULL, NULL);
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'penguin desc', 'glossary_desc', NULL, NULL);
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'magic desc', 'glossary_desc', NULL, NULL);
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'car <b>desc</b>', 'glossary_desc', NULL, NULL);
    INSERT INTO article (lang_id, head, text, "class", module_id, container_id)
        VALUES (NULL , 'Glossary', 'progr desc', 'glossary_desc', NULL, NULL);

    --Words
    INSERT INTO d_words ("word", "article_id")
        VALUES ('monkey', articleId);

    INSERT INTO d_words ("word", "article_id")
        VALUES ('apple', articleId+1);

    INSERT INTO d_words ("word", "article_id")
        VALUES ('penguin', articleId+2);

    INSERT INTO d_words ("word", "article_id")
        VALUES ('magic', articleId+3);

    INSERT INTO d_words ("word", "article_id")
        VALUES ('car', articleId+4);

    INSERT INTO d_words ("word", "article_id")
        VALUES ('program', articleId+5);

    -- Category-Word
    INSERT INTO d_cat_word ("category_id", "word_id")
        VALUES (catId, wordId );
    INSERT INTO d_cat_word ("category_id", "word_id")
        VALUES (catId+1, wordId );
    INSERT INTO d_cat_word ("category_id", "word_id")
        VALUES (catId+1, wordId+1 );


    return 1;
end;
$$;

alter function gl_insert_test_data() owner to antonb2;

