create function dc_insert_menu(integer, integer) returns integer
  language plpgsql
as
$$
declare
    parent_menu_id alias for $1;
    lng_id alias for $2;

    menu_item_id    INT4;
    menu_item_order INT4;
    page_id_    INT4;
begin
    SELECT nextval('menu_item_id_seq') INTO menu_item_id;
    SELECT INTO menu_item_order MAX(order_) FROM menu_item WHERE menu_id=parent_menu_id ;
    menu_item_order = menu_item_order + 1;
    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
        VALUES (menu_item_id, parent_menu_id, 'Document catalog', 'doc_module.html', menu_item_order, NULL, 1, 'page');

    SELECT nextval('page_id_seq') INTO page_id_;
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible)
        VALUES (page_id_, lng_id, 'doc_module.html', 'Document catalog', Null, 'document_catalog', 'page', '2004-02-27 11:52:46', NULL, NULL, NULL, 0);

    INSERT INTO page_element(page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_id_, '0','0','menu-component',NULL);
    INSERT INTO page_element(page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_id_, '0','0','document-catalog-component',NULL);
    
    return 1;
end;
$$;

alter function dc_insert_menu(integer, integer) owner to antonb2;

