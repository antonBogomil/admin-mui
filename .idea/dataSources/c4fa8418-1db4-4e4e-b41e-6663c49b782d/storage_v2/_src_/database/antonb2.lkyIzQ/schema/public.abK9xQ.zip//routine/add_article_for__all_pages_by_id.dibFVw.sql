create function "add_article_for _all_pages_by_id"(id integer) returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
	FOR rec IN select * from page LOOP    
	    perform tpl_generate_article_through_by_id(rec.id, $1);
	END LOOP;
    return true;
END;
$$;

alter function "add_article_for _all_pages_by_id"(integer) owner to antonb2;

