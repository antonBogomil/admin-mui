create function repair_statistics() returns integer
  strict
  language plpgsql
as
$$
DECLARE
    rec record;
BEGIN

    FOR rec IN SELECT * FROM sm_statistic_hit LOOP

       INSERT INTO sm_statistics(customer_ip, hit_date, step)
              VALUES(rec."visitor_ip" , rec."date", rec."step");

END LOOP;
RETURN 0;
END;
$$;

alter function repair_statistics() owner to antonb2;

