create function right_day(timestamp without time zone) returns integer
  language plpgsql
as
$$
  /* New function body */
DECLARE i integer;
today1 timestamp;
yearofdate double precision;
dayofyear2 integer;
Begin
today1 = (select now());
yearofdate = (SELECT EXTRACT(YEAR FROM $1));
dayofyear2 = (SELECT EXTRACT(DOY FROM $1));
if 0=(select mod((select cast ((SELECT EXTRACT(YEAR FROM today1)) AS int8)),  4))
   and (dayofyear2 > 59)
   and 0<>(select mod((select cast (yearofdate AS int8)),  4))
then
   return dayofyear2 + 1;
ELSIf 0<>(select mod((select cast ((SELECT EXTRACT(YEAR FROM today1)) AS int8)),  4))
   and (dayofyear2 > 59)
   and 0=(select mod((select cast (yearofdate AS int8)),  4))
then
     return dayofyear2 - 1;
end if;
return dayofyear2;
end
$$;

alter function right_day(timestamp) owner to antonb2;

