create function add_pm_page(integer, character varying, character varying, character varying, integer) returns integer
  language plpgsql
as
$$
DECLARE
  _langId alias for $1;
  _pageName alias for $2;
  _pageTitle alias for $3;
  _specialComponentName alias for $4;
  _orderInMenu alias for $5;

  --CONSTS
  PRODUCT_MODULE_PAGE_CLASS varchar := 'pm';
  MENU_COMPONENT_NAME varchar := 'menu-component';
--  SITE_ID integer := 1;

  menuItemId integer := -1;
  pageId integer := -1;
  siteId integer := 1;
  containerId integer := 1; 		
BEGIN
    -- Default container
  SELECT id INTO containerId FROM containers WHERE is_default = true;
  
  -- inserting page
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title,
                      contents, class, category, last_modified,
                      protected, publish_date, expired_date, visible, site_id, container_id, sitemap_prior, sitemap_freq)
  VALUES           (pageId, _langId, _pageName, _pageTitle,
                    NULL, PRODUCT_MODULE_PAGE_CLASS, 'page' , NULL,
                    'nodelete', NULL, NULL, TRUE, siteId, containerId, 0.5, 'DAILY');

  -- adding menu-component
  INSERT INTO page_component (page_id,  class_name)
  VALUES (pageId, MENU_COMPONENT_NAME);

  --adding special product module component
  INSERT INTO page_component (page_id,  class_name)
  VALUES (pageId, _specialComponentName);

  RETURN 1;
END;
$$;

alter function add_pm_page(integer, varchar, varchar, varchar, integer) owner to antonb2;

