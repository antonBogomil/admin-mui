create function tpl_create_article_with_address(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, langId, '', '
        	<strong>Plantenkwekerij De Kemp BV</strong><br>
			Kempweg 15, <br>
			5964ND Horst – Meterik <br><br>
			tel. 0031 (0)77 3982430<br>
			fax. 0031 (0)77 3985831');
    return articleId;
end;
$$;

alter function tpl_create_article_with_address(integer) owner to antonb2;

