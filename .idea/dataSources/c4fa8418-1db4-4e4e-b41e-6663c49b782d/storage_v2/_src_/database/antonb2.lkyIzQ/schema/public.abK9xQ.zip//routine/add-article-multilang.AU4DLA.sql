create function "add-article-multilang"("pageNamePart" character varying, "articleHeader" character varying) returns boolean
  language plpgsql
as
$$
DECLARE
  pageName alias for $1;
  header1 alias for $2;
  rec record;
  pageElementId int4;
  langId int4;
  articleId int4;
BEGIN
	for rec in select * from page where filename like pageName || '%' loop
	SELECT add_standard_component(rec.filename, 'article-component', null) INTO pageElementId;
      IF pageElementId = -1 THEN
          RETURN -1;
        END IF;           

      -- Article
      SELECT nextval('article_id_seq') INTO articleId;
        INSERT INTO article (id, lang_id, head, text, class)
        VALUES (articleId, rec.lang_id, header1, '<p>This is the article text</p>', NULL);
      
      -- page_component_params
      INSERT INTO page_component_params (element_id, name, value)
        VALUES (pageElementId, 'id', articleId);
    end loop;
 return true;
END;
$$;

alter function "add-article-multilang"(varchar, varchar) owner to antonb2;

