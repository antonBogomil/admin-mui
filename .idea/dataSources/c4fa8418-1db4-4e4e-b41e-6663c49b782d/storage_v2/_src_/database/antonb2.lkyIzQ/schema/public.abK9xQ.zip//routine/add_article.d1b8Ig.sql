create function add_article() returns boolean
  language plpgsql
as
$$
declare
  rec record;

begin
  for rec in select * from page loop
  perform tpl_generate_article_by_id(rec.id, 44);
  end loop;
  return true;
end;
$$;

alter function add_article() owner to antonb2;

