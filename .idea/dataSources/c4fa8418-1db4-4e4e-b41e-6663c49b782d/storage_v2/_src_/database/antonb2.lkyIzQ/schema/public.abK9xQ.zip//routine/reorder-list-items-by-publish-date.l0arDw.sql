create function "reorder-list-items-by-publish-date"() returns boolean
  language plpgsql
as
$$
DECLARE
	listRec record;
	listItemRec record;
    n int;
BEGIN
	for listRec in ( select * from list where template_id = 1) loop
    	update list_item set order_number = 0 where list_id = listRec.id;
        n := 0;
    	for listItemRec in (select * from list_item where list_id = listRec.id order by publish_date DESC) loop
    		update list_item set order_number = n where id = listItemRec.id;
            n:= n + 1;        		
        end loop;
    end loop;    
    
    return true;
END;
$$;

alter function "reorder-list-items-by-publish-date"() owner to antonb2;

