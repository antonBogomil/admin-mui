create function put_new_items() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  teaserId INTEGER;
BEGIN
	for rec in (select * from temp_table) loop
    	insert into article (lang_id, head, text, class)
        	values (1, 'Enter your text here', rec.teaser_text, 'cls');
        teaserId := (select currval('article_id_seq'));
        insert into article (lang_id, head, text, class)
        	values (1, 'Enter your text here', rec.article_text, 'cls');
        INSERT INTO list_item (list_id, title, 
        			teaser_id, order_number, 
                    link, image_link, 
                    document_link, type, 
                    view_date, publish_date, 
                    expired_date, created_by, 
                    created_date, last_modified_by, 
                    last_modified_date, article_id, 
                    thumbnail_link, list_item_link, 
                    site_id) 
                    
        values (    rec.list_id, rec.title,
        			teaserId, rec.order_number, 
                    rec.link, rec.image_link, 
                    rec.document_link, rec.type, 
                    rec.view_date, rec.publish_date, 
                    rec.expired_date, rec.created_by, 
                    rec.created_date, rec.last_modified_by, 
                    rec.last_modified_date, (select currval('article_id_seq')), 
                    rec.thumbnail_link, rec.list_item_link, 
                    1);
    end loop;
	return true;
END;
$$;

alter function put_new_items() owner to antonb2;

