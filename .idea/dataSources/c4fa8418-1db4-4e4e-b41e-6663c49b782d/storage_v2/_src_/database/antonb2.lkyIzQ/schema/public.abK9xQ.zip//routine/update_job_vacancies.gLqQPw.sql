create function update_job_vacancies() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
 
begin	


 for rec in select * from job_vacancies_old loop
 
	select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text, class) values
        (articleId, (select article_old.lang_id from article_old where article_old.lang_id = rec.article_id), 'Enter your text here', (select article_old.text from article_old where article_old.id = rec.article_id), 'cls') ;						
       
	insert into job_vacancies( id, title, position, article_id, salary, needed, publish_date, expire_date, type, department_id, education, profile) 
		VALUES ( rec.id, rec.title, rec.position, articleId, rec.salary, rec.needed, rec.publish_date, rec.expire_date, rec.type, rec.department_id, rec.education, rec.profile);
    

  end loop;
  return true;
  
  end;
$$;

alter function update_job_vacancies() owner to antonb2;

