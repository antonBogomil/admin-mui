create function update_pm_seq() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  com VARCHAR;
   com2 VARCHAR;
   ssss VARCHAR;
BEGIN
 for rec in SELECT * FROM pg_class where relkind = 'r' loop
	if EXISTS (select * from information_schema.columns where table_name = rec.relname and column_name='id') AND
      EXISTS (SELECT relname FROM pg_class where relname=(SELECT rec.relname || '_id_seq')) then
	com= (select 'select setval(''' || rec.relname || '_id_seq'', (select max(id) from ' || rec.relname ||  '))' ); 
   execute com;

  end if;
 end loop;
 return false;
END;
$$;

alter function update_pm_seq() owner to antonb2;

