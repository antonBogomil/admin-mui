create function correct_menu() returns boolean
  language plpgsql
as
$$
DECLARE
   rec record;
   rec2 record;
   parId integer;
   lang record;
BEGIN 
	for lang IN (select * from language where id > 1) loop 
      parId:= (select menu.id from menu left join page on menu.page_id = page.id  where page.filename = (select 'cms-help_' || lang.code || '.html'));
      for rec IN (select menu.*, page.filename from menu
      left join page on menu.page_id = page.id  where menu.lang_id = 1 and parent_id =2) loop
          for rec2 IN (select * from page where filename = (select replace(rec.filename, '_nl.html', (select('_'|| lang.code || '.html'))))) loop
              if ((select count(id) from menu where page_id = rec2.id) = 0) THEN
                  insert into menu (parent_id, page_id, lang_id, title, order_number, publish_date, site_id) values 
                  (parId, rec2.id, rec2.lang_id, rec2.title, rec.order_number, rec.publish_date, 1);
              end if;
          end loop;
      end loop;
    end loop;
    return true;
END;
$$;

alter function correct_menu() owner to antonb2;

