create function "addNewsComponent"() returns boolean
  language plpgsql
as
$$
  /* New function body */
Declare
i integer;
classPage varchar;
langId integer;
Begin

for i in 1..(select max(id) from page)
loop
    
     classPage := (select class from page where id=i);
    
    if classPage = 'simpleBlue'
    then
        insert into page_component (page_id,class_name)
        values (i,'list-component');
        langId := (select lang_id from page where id = i);
        if langId = 1
           then
               INSERT INTO page_component_params (element_id, name, value)
               VALUES ((select id from page_component order by id desc limit 1), 'listId', '1');
           end if;
        if langId = 2
           then
               INSERT INTO page_component_params (element_id, name, value)
               VALUES ((select id from page_component order by id desc limit 1), 'listId', '2');
           end if;
        if langId = 3
           then
            INSERT INTO page_component_params (element_id, name, value)
               VALUES ((select id from page_component order by id desc limit 1), 'listId', '3');
           end if;
   end if;
end loop;
return true;
end
$$;

alter function "addNewsComponent"() owner to antonb2;

