create function is_child_in_list(character varying, integer, integer, integer) returns boolean
  stable
  language plpgsql
as
$$
  /* New function body */
DECLARE
       cat_list alias for $1;
       cat_id alias for $2;
       lang_id alias for $3;
       site_id alias for $4;
       query VARCHAR;
       rec record;
BEGIN
     query:='
     SELECT pm_category.id
     FROM pm_category
     LEFT JOIN pm_cat2lang_presence ON (pm_cat2lang_presence.category_id =
     pm_category.id AND pm_cat2lang_presence.lang_id = laguageId)
     WHERE pm_category.id IN (categoriList)
     AND (SELECT is_parent_category(pm_category.id, parentId))
     AND (publish_date <= now()
     AND (expired_date >= now() OR expired_date IS NULL))
     AND ((pm_cat2lang_presence.id IS NULL) OR pm_cat2lang_presence.is_present)
     AND pm_category.site_id = siteId
     ';
     query = (SELECT replace (query, 'laguageId', lang_id));
     query = (SELECT replace (query, 'categoriList', cat_list));
     query = (SELECT replace (query, 'parentId', cat_id));
     query = (SELECT replace (query, 'siteId', site_id));
     FOR rec IN EXECUTE query LOOP
        RETURN TRUE;
     END LOOP;
     RETURN FALSE;
END;
$$;

alter function is_child_in_list(varchar, integer, integer, integer) owner to antonb2;

