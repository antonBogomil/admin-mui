create function correct_menu2() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
  i int4;
BEGIN
i:=2;
 for rec in select * from menu where parent_id is not null order by parent_id loop
 	update menu set parent_id = i where parent_id = rec.id;
 	update menu set id = i where id = rec.id;
    i:= i+1;
 end loop;
return true;
END;
$$;

alter function correct_menu2() owner to antonb2;

