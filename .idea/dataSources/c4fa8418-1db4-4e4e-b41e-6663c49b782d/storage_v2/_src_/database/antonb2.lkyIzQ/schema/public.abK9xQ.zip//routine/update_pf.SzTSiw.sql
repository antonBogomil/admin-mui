create function update_pf() returns boolean
  language plpgsql
as
$$
declare
  rec record;
begin
  UPDATE images_set SET number_of_images=1 WHERE name='front';
  UPDATE images_set SET number_of_images=2 WHERE name='simple';
  
  for rec in select * from images_set WHERE name='front' loop
    DELETE FROM image WHERE image_set_id=rec.image_set_id and _order>1;
    UPDATE image SET required_height=246 , required_width=371 , src='/site/media/picture_frame/front.jpg'
      WHERE image_set_id=rec.image_set_id;
  end loop;
  
  
  for rec in select * from images_set WHERE name='simple' loop
    DELETE FROM image WHERE image_set_id=rec.image_set_id and _order=3;
  end loop;

  return true;
end;
$$;

alter function update_pf() owner to antonb2;

