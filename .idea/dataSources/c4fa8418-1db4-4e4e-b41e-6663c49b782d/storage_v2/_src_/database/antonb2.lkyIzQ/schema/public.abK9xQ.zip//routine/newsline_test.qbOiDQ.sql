create function newsline_test() returns integer
  strict
  language plpgsql
as
$$
declare
    var_title constant text := 'No fresh news ';
    var_imageLink constant text := null;
    var_pageId integer := 8;
    var_teaserId integer;
    var_articleId integer;
    var_listItemId int4;
    var_itemsPerList constant integer := 1000;
    var_orderNumber integer;
    var_listId integer;
    i integer;
begin

  select into var_listItemId nextval('list_item_id_seq');

  for var_listId in 24..35 loop
      select into var_orderNumber max(order_number) from list_item
        where list_id = var_listId;
      if var_orderNumber is null then
        var_orderNumber := 0;
      end if;
      for i in 1..var_itemsPerList loop
        select tpl_create_article_with_text(var_pageId, var_title || 'summary')
          into var_teaserId;
        select tpl_create_article_with_text(var_pageId, var_title || 'text')
          into var_articleId;
        insert into list_item (id, list_id, title, teaser_id, order_number,
          visible, link, image_link, document_link, "type", view_date,
          publish_date, expired_date, created_by, created_date,
          last_modified_by, last_modified_date, article_id, thumbnail_link)
        values(var_listItemId, var_listId, var_title || var_listItemId,
           var_teaserId, var_orderNumber + i, 1, NULL, var_imageLink, NULL,
           NULL, NULL, now(), NULL, 1, now(), 1, now(), var_articleId, NULL);
        var_listItemId := var_listItemId + 1;
      end loop;
  end loop;
  return 0;
end;
$$;

alter function newsline_test() owner to antonb2;

