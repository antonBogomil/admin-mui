create function add_contact_to_group() returns boolean
  language plpgsql
as
$$
Declare i integer;
typeContact varchar;
contactId integer;
existRow integer;
flag integer;
Begin

for i in 1..(select max(id) from contact)
loop
    typeContact = (select type from contact where contact.id=i);
    existRow = (select id from cb_cont_group where cb_cont_group.contact_id = i limit 1 );
    if ((typeContact='contact_book') and (existRow is null))
       then
           insert into cb_cont_group(contact_id,group_id) values(i,3);
    end if;
end loop;
return true;
end
$$;

alter function add_contact_to_group() owner to antonb2;

