create function add_art_one2() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  keyPm VARCHAR;
  countId INT;
begin

  for rec in select * from pm_category_articles loop
    select count(pm_category_articles.category_id) from pm_category_articles 
      where pm_category_articles.category_id=rec.category_id into countId and pm_category_articles.article_id in
 (select id from article where article.head='CATEGORY_OVERVIEW');
    IF (countId > 1) THEN
      delete from pm_category_articles where pm_category_articles.category_id=rec.category_id 
      and pm_category_articles.article_id=rec.article_id;
    END IF;                            
    
    /*select count(pm_category_articles.category_id) from pm_category_articles 
      where pm_category_articles.category_id=rec.category_id into countId and pm_category_articles.article_id in
 (select id from article where article.head='PRODUCTS_OVERVIEW');
    IF (countId > 1) THEN
      delete from pm_category_articles where pm_category_articles.category_id=rec.category_id 
      and pm_category_articles.article_id=rec.article_id;
    END IF;  
    */
  end loop;
  return true;
end;
$$;

alter function add_art_one2() owner to antonb2;

