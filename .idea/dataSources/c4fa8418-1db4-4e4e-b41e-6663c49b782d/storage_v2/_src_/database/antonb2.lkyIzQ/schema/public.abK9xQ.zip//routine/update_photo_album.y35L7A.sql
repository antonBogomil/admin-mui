create function update_photo_album() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  thImgId int4;
  mcId int4;
  imgId int4;
  mcPath VARCHAR;
begin	


 for rec in select * from photo_album_old loop

	select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text) values
        (articleId, 1, 'Enter your text here', (select article_old.text from article_old where article_old.id = rec.article_id)) ;
		
		
	select nextval('image_image_id_seq') into imgId;
    insert into image (image_id,  src , alt , max_width, max_height) 
		values(
			imgId,		
			(select image_old.src from image_old where image_old.image_id = rec.image_id),
			(select image_old.alt from image_old where image_old.image_id = rec.image_id),
			(select image_old.max_width from image_old where image_old.image_id = rec.image_id),
			(select image_old.max_height from image_old where image_old.image_id = rec.image_id)
		);
		
		
	select nextval('image_image_id_seq') into thImgId;
    insert into image (image_id,  src , alt , max_width, max_height) 
		values(
			thImgId,		
			(select image_old.src from image_old where image_old.image_id = rec.image_id),
			(select image_old.alt from image_old where image_old.image_id = rec.image_id),
			(select image_old.max_width from image_old where image_old.image_id = rec.image_id),
			(select image_old.max_height from image_old where image_old.image_id = rec.image_id)
		);		
		
        select mc_folder_old.path from mc_folder_old where mc_folder_old.id = rec.mc_folder_id into mcPath;
        IF  mcPath IS not NULL THEN 
        
			select nextval('mc_folder_id_seq') into mcId;
    		insert into mc_folder (id, path,  site_id) values(mcId,  (select mc_folder_old.path from mc_folder_old where mc_folder_old.id = rec.mc_folder_id), 1) ;		
			insert into photo_album(id, name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) 
				VALUES (rec.id, rec.name, 1, rec.parent_id, articleId, mcId, imgId, thImgId);
        ELSE
        	insert into photo_album(id, name, lang_id, parent_id, article_id, mc_folder_id, image_id, thumbnail_id) 
				VALUES (rec.id, rec.name, 1, rec.parent_id, articleId, NULL, imgId, thImgId);
        END IF;		

	
    


  end loop;
  return true;
  
  end;
$$;

alter function update_photo_album() owner to antonb2;

