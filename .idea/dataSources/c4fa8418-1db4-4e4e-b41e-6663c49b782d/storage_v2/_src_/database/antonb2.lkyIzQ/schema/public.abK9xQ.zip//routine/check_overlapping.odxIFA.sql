create function check_overlapping() returns trigger
  language plpgsql
as
$$
DECLARE
found record;
BEGIN
	IF	NEW.rp_id IS NULL OR 
    	NEW.ro_id IS NULL OR 
        NEW.begin_date IS NULL OR 
        NEW.end_date IS NULL 
    THEN
    	RETURN NEW;
    END IF;
	SELECT * INTO found 
    FROM rental_object_price rop 
    WHERE 	rop.id != NEW.id AND
    		rop.rp_id = NEW.rp_id AND 
    		rop.ro_id = NEW.ro_id AND 
    		daterange(rop.begin_date, (rop.end_date + INTERVAL '1day')::date) && 
            daterange(NEW.begin_date, (NEW.end_date + INTERVAL '1day')::date) 
    LIMIT 1;
    IF found IS NOT NULL THEN
    	RAISE EXCEPTION 'Overlapping with date interval in row %', found;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_overlapping() owner to antonb2;

