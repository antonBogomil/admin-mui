create function split_region(character varying, character varying) returns boolean
  language plpgsql
as
$$
declare
  codes text[];
  start INTEGER; 
  count INTEGER;
  i INTEGER;
begin
	codes = (select string_to_array($2,','));
	start :=array_lower(codes,1);
	count :=array_upper(codes,1);
    IF start is not null THEN
		FOR i IN start..count LOOP
	        IF (SELECT substring($1,1,4) BETWEEN  substring(codes[i],1,4) 
    	        AND  substring(codes[i],6,4)  ) 
                THEN return true;
	        END IF;
		END LOOP;
	END IF;
  return false;
end;
$$;

alter function split_region(varchar, varchar) owner to antonb2;

