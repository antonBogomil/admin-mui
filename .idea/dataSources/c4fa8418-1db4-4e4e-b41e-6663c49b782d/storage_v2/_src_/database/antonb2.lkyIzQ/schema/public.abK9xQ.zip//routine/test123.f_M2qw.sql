create function test123() returns boolean
  language plpgsql
as
$$
BEGIN
   INSERT INTO job_vac2lang_presence (j_vac_id, lang_id, is_present) VALUES ((select id from job_vacancies), 1, true);
   RETURN TRUE;      
END;
$$;

alter function test123() owner to antonb2;

