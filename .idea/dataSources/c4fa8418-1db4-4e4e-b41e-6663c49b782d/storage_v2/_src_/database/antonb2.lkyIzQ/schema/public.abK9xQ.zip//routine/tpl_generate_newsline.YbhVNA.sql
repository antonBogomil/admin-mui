create function tpl_generate_newsline(integer, integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    newslineNumber alias for $2;
    langId int4;
    elementId int4;
begin
	select lang_id into langId from page where id = pageId;
	
	select nextval('page_element_id_seq') into elementId;
	insert into page_element 
		(id,page_id,table_name,domain_table_record_id,class_name,container_id) values 
		(elementId,pageId,'0','0','news-line-component', NULL);
	
	insert into page_element_params 
		(element_id,name,value) values 
		(elementId,'itemsPerPage','1');
		
		
	IF langId = '1' THEN
	   	IF newslineNumber = '1' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','3');
		END IF;
	   	IF newslineNumber = '2' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','8');
		END IF;
	   	IF newslineNumber = '3' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','13');
		END IF;
	END IF;
	
	IF langId = '2' THEN
	   	IF newslineNumber = '1' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','1');
		END IF;
	   	IF newslineNumber = '2' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','6');
		END IF;
	   	IF newslineNumber = '3' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','11');
		END IF;
	END IF;
	
	IF langId = '3' THEN
	   	IF newslineNumber = '1' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','2');
		END IF;
	   	IF newslineNumber = '2' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','7');
		END IF;
	   	IF newslineNumber = '3' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','12');
		END IF;
	END IF;
	
	IF langId = '4' THEN
	   	IF newslineNumber = '1' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','4');
		END IF;
	   	IF newslineNumber = '2' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','9');
		END IF;
	   	IF newslineNumber = '3' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','14');
		END IF;
	END IF;
	
	IF langId = '5' THEN
	   	IF newslineNumber = '1' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','5');
		END IF;
	   	IF newslineNumber = '2' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','10');
		END IF;
	   	IF newslineNumber = '3' THEN
			insert into page_element_params 
				(element_id,name,value) values 
				(elementId,'lists','15');
		END IF;
	END IF;
		
	return 1;	
end;
$$;

alter function tpl_generate_newsline(integer, integer) owner to antonb2;

