create function tpl_add_pm_shop(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
begin
	insert into page_component 
		(page_id, class_name) values (pageId, 'pm-shopping-cart');
	return pageId;
end;
$$;

alter function tpl_add_pm_shop(integer) owner to antonb2;

