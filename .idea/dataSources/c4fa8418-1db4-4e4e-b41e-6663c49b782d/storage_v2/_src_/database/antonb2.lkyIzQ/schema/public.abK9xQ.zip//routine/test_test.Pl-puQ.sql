create function test_test() returns integer
  language plpgsql
as
$$
declare
    var_articleIdSeq integer;
    var_testIdSeq integer;
begin
    /* Insert values into the article table */
    select into var_articleIdSeq last_value from article_id_seq;
    if var_articleIdSeq > 1 then
       var_articleIdSeq := var_articleIdSeq + 1;
    end if;
    select into var_testIdSeq last_value from test_id_seq;
    if var_testIdSeq > 1 then
       var_testIdSeq := var_testIdSeq + 1;
    end if;

    delete from article where class = 'test_question' or class = 'test_result';
    delete from test;

  /* answers */
  insert into article (head, text, class) VALUES ('', 'Niet waar. Het klopt wel dat wanneer je de pil slikt je lichaam niet meer maandelijks een eitje afstoot. Maar het is niet zo dat er daardoor op latere leeftijd meer eitjes in de eierstokken zitten waardoor je later in de overgang zou komen. Deze eitjes worden namelijk ook via het lichaam opgenomen.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Waar. Het oestrogeen wordt ook geproduceerd in het vetweefsel –zij het in geringe mate- en van oestrogeen is bekend dat het bepaalde verschijnselen van de overgang verminderd.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. Ook andere verschijnselen zoals wisselende stemmingen en vermoeidheid kunnen de eerste tekenen van de overgang zijn. Al voordat de menstruatie uitblijft kan er sprake zijn van overgangsverschijnselen.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. De mate waarin vrouwen overgangsverschijnselen ervaren verschilt sterk. Er zijn ook vrouwen die aangeven de overgang juist als een opluchting te zien vanwege het uitblijven van de menstruatie en de daarbij behorende ongemakken.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Waar. Bij de man vinden de veranderingen echter veel geleidelijker plaats dan bij de vrouw. Echt lichamelijke verschijnselen treden bij de man doorgaans niet op. Toch maken veel mannen tussen ongeveer het vijfenveertigste en vijfenvijftigste jaar een geestelijke crisis door. Gekscherend wordt deze overgang wel eens de penopauze genoemd.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. Gemiddeld duurt de overgang tussen de 5 en 10 jaar. Maar de overgang kan ook korter of langer duren.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Waar. Er is geen verband tussen ongemakken rond de menstruatie en overgangsverschijnselen.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. Zowel vrouwen met een gezonde als ongezonde levensstijl kunnen overgangsverschijnselen krijgen. Een goede conditie kan er wel voor zorgen dat overgangsverschijnselen in mindere mate aanwezig zijn.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. De menopauze is iets anders dan de overgang. De menopauze betreft alleen het moment van de laatste menstruatie, terwijl de overgang een hele periode beslaat.', 'test_question');
  insert into article (head, text, class) VALUES ('', 'Niet waar. De mate van overgangsverschijnselen is niet erfelijk.', 'test_question');

    /* results */
    insert into article (head, text, class) VALUES ('', 'Je weet nog niet zo heel veel over de overgang, en met jou zijn er vele andere vrouwen in Nederland die er eigenlijk nog maar weinig vanaf weten. Neem eens de tijd om rustig door deze website heen te bladeren voor meer informatie over deze periode in je leven en veel tips die een positieve bijdrage kunnen leveren tijdens je overgang. Veel surfplezier!', 'test_result');
    insert into article (head, text, class) VALUES ('', 'Je weet al best veel over de overgang maar er is ook veel wat je nog niet weet. Gelukkig kan je dat allemaal opzoeken op onze website. Behalve veel informatie staan er ook veel tips op deze website die een positieve bijdrage kunnen leveren tijdens je overgang. Veel surfplezier!', 'test_result');
    insert into article (head, text, class) VALUES ('', 'Je mag jezelf een ware kenner van de overgang noemen. Je bent waarschijnlijk ervaringsdeskundige of je hebt je goed verdiept in de overgang. Hopelijk vind je ondanks je grote kennis toch nog nieuwe, nuttige en leuke informatie vindt op deze website. En mocht je nog tips of aanvullingen voor ons hebben dan horen we dit natuurlijk graag.', 'test_result');

    insert into test (title) values ('Test jouw kennis van de overgang.');

    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 1, 'Als je de pil hebt gebruikt als anticonceptiemiddel kom je later in de overgang.', var_articleIdSeq, false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 2, 'Slanke vrouwen hebben meer overgangsverschijnselen dan gezette vrouwen.', var_articleIdSeq+1, true);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 3, 'Je merkt dat de overgang begonnen is door een onregelmatige menstruatiecyclus en/of opvliegers.', var_articleIdSeq+2, false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 4, 'Alle vrouwen ervaren tijdens de overgang overgangsverschijnselen.', var_articleIdSeq+3 , false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 5, 'Mannen maken ook een soort overgang door.', var_articleIdSeq+4, true);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 6, 'Binnen 5 jaar is de overgang toch echt wel voorbij.', var_articleIdSeq+5, false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 7, 'Een menstruatie die altijd gekenmerkt werd door veel ongemakken zegt dit niets over de mate van overgangsverschijnselen die je zult ervaren.', var_articleIdSeq+6, true);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 8, 'Als je gezond eet en voldoende beweegt krijg je geen overgangsverschijnselen.', var_articleIdSeq+7, false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 9, 'De overgang en de menopauze zijn twee woorden met dezelfde betekenis.', var_articleIdSeq+8, false);
    insert into test_question (test_id, order_number, title, article_id, result) values (var_testIdSeq, 10, 'Als je moeder veel overgangsverschijnselen had is het zeer waarschijnlijk dat jij er ook veel zult krijgen.', var_articleIdSeq+9, false);

    insert into test_result (test_id, left_limit, right_limit, article_id) values (var_testIdSeq, 0, 16, var_articleIdSeq+10);
    insert into test_result (test_id, left_limit, right_limit, article_id) values (var_testIdSeq, 17, 33, var_articleIdSeq+11);
    insert into test_result (test_id, left_limit, right_limit, article_id) values (var_testIdSeq, 34, 50, var_articleIdSeq+12);

    raise notice 'done';
    return 0;
end;
$$;

alter function test_test() owner to antonb2;

