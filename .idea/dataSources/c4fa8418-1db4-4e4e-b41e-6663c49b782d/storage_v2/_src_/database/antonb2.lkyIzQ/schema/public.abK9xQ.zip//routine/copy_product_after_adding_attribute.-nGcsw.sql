create function copy_product_after_adding_attribute() returns boolean
  language plpgsql
as
$$
declare
 rec record;
 
begin
for rec in select * from pm_product where type_id=33 loop
	insert into pm_attribute_value (product_id, type_id, str_value, int_value, advstr_value, lang_id, money_value, real_value) values (rec.id, (select max(id) from pm_attribute_type where product_type_id=33), NULL, NULL, NULL, 1, NULL, NULL);
end loop;
return null;
end
$$;

alter function copy_product_after_adding_attribute() owner to antonb2;

