create function add_standard_component(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
  --
    -- Create standard component
    -- INPUT:
    -- pageName - page name to add component
    -- componentName - name of the component
    -- pageClassName - class name to set for page (if NULL class is not changed)
    --
    -- RETURN:
    -- id - of created page_component record
    -- -1 - page with pageName is not found
    -- 
    
DECLARE
  pageName alias for $1;
  componentName alias for $2;
  pageClassName alias for $3;

  pageRd  RECORD;
  articleId integer := -1;
  pageElementId integer := -1;
BEGIN

  SELECT * INTO pageRd FROM page WHERE filename=pageName;
  IF pageRd.id IS NULL THEN
      RETURN -1;
    END IF;

  SELECT nextval('page_component_id_seq') INTO pageElementId;
  INSERT INTO page_component (id, page_id,  class_name)
    VALUES (pageElementId, pageRd.id, componentName);
  

  IF pageClassName IS NOT NULL THEN
    -- update class name
    RAISE NOTICE 'Setting page class to: %',pageClassName;
    UPDATE page SET class=pageClassName, protected='nodelete' WHERE id=pageRd.id;
  ELSE
    UPDATE page SET protected='nodelete' WHERE id=pageRd.id;
  END IF;

  RETURN pageElementId;
END;
$$;

alter function add_standard_component(varchar, varchar, varchar) owner to antonb2;

