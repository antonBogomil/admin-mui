create function add_component_to_all_pages() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
	for rec in select id from page where id not in (select page_id from page_component where page_component.class_name='advanced-search-component' ) loop	
    	insert into page_component(page_id, class_name) values(rec.id,'advanced-search-component');
	end loop;
	return true;
end;
$$;

alter function add_component_to_all_pages() owner to antonb2;

