create function create_faq(bigint) returns integer
  language plpgsql
as
$$
DECLARE

    siteId alias for $1;
    
    -- constatnts
    -- LIST_MODULE_ID integer := 3;
	
    -- you can move it to input param for more flexability
    DEFAULT_FAQ_TYPE varchar := 'faqlink';
	DEFAULT_FAQ_NAME varchar := 'FAQ';
    DEFAULT_FAQ_PAGE_NAME varchar := 'faq.html';
    -------------------------------------------------------
    
    LIST_COMPONENT_NAME varchar := 'list-component';
	LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';
	
   	moduleId integer := NULL;	
    pageId integer := NULL;
    pageElementId integer := NULL;
	langId integer := NULL;
	
    templateId integer := -1;
   
	faqComponentListId integer := -1;
    firstCategoryListId integer := -1;
    articleId integer := -1;
    listItemId integer := -1;
   
    categoryName varchar := 'Category 1';
    questionsList varchar := 'Question list for category 1';
	
   
   
  

BEGIN
  
  Select id INTO moduleId FROM module WHERE site_id = siteId and name = 'faq';
  select id,lang_id INTO pageId,langId FROM page WHERE filename = DEFAULT_FAQ_PAGE_NAME and site_id = siteId;
  
  IF moduleId IS NULL OR pageId IS NULL OR langId IS NULL THEN
	RETURN -1;
  END IF;
  
    -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = DEFAULT_FAQ_TYPE) AND (module_id = moduleId);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, moduleId, DEFAULT_FAQ_TYPE)
    ;
  END IF;

  -- list
  SELECT nextval('list_id_seq') INTO faqComponentListId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id,site_id)
    VALUES (faqComponentListId, DEFAULT_FAQ_NAME, langId, 1, '', 0, 0, moduleId, DEFAULT_FAQ_NAME, templateId,siteId)
  ;

  UPDATE page SET class=DEFAULT_FAQ_TYPE, protected='nodelete' WHERE id=pageId;

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'This is the FAQ sample text', NULL);
  
  -- list_item
  SELECT nextval('list_item_id_seq') INTO listItemId;
    INSERT INTO list_item (id, list_id, title, teaser_id, order_number, visible, site_id)
    VALUES (listItemId, faqComponentListId, categoryName, articleId, 1, true, siteId)
  ;

  -- list
  SELECT nextval('list_id_seq') INTO firstCategoryListId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, parent_list_item_id,site_id)
    VALUES (firstCategoryListId, questionsList, langId, 1, '', 0, 0, moduleId, NULL, templateId, listItemId,siteId)
  ;

  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'faq-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'listId', faqComponentListId);

  	
  RETURN faqComponentListId;
END;
$$;

alter function create_faq(bigint) owner to antonb2;

