create function job_insert_menu(integer, integer) returns integer
  language plpgsql
as
$$
declare
    parent_menu_id alias for $1;
    lng_id alias for $2;

    menu_item_id    INT4;
    menu_item_order INT4;
    page_id_    INT4;
    page_element_id INT4;
    third_level_menu_id INT4;
    lang_code varchar(2);

begin
    SELECT nextval('menu_item_id_seq') INTO menu_item_id;
    SELECT INTO menu_item_order MAX(order_) FROM menu_item WHERE menu_id=parent_menu_id ;
    menu_item_order = menu_item_order + 1;
    
    SELECT code INTO lang_code FROM language WHERE id=lng_id;
    
    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
        VALUES (menu_item_id, parent_menu_id, 'Job', 'job' || lang_code || '.html', menu_item_order, NULL, 1, 'page');

    SELECT nextval('page_id_seq') INTO page_id_;
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible)
        VALUES (page_id_, lng_id, 'job' || lang_code || '.html', 'Job', Null, 'job', 'page', '2004-02-27 11:52:46', NULL, NULL, NULL, 0);

    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (nextval('page_element_id_seq'), page_id_, '0','0','menu-component',NULL);
    SELECT nextval('page_element_id_seq') INTO page_element_id;
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_element_id, page_id_, '0','0','job-module-component',NULL);
    INSERT INTO page_element_params(id, element_id, name, value)
        VALUES (nextval('page_element_params_id_seq'), page_element_id, 'start','DepartmentsView');

    SELECT nextval('menu_id_seq') INTO third_level_menu_id;
    INSERT INTO menu (id, lang_id, parent_menu_item_id, "level", frozen, "class")
           VALUES (third_level_menu_id, lng_id, menu_item_id, 3, 0, NULL);


    SELECT nextval('menu_item_id_seq') INTO menu_item_id;
    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
        VALUES (menu_item_id, third_level_menu_id, 'DepartmentsView', 'departments_view.html', 1, NULL, 1, 'page');
    SELECT nextval('page_id_seq') INTO page_id_;
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible)
        VALUES (page_id_, lng_id, 'departments_view.html', 'DepartmentsView', Null, 'job', 'page', '2004-02-27 11:52:46', NULL, NULL, NULL, 0);
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (nextval('page_element_id_seq'), page_id_, '0','0','menu-component',NULL);
    SELECT nextval('page_element_id_seq') INTO page_element_id;
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_element_id, page_id_, '0','0','job-module-component',NULL);
    INSERT INTO page_element_params(id, element_id, name, value)
        VALUES (nextval('page_element_params_id_seq'), page_element_id, 'start','DepartmentsView');

    SELECT nextval('menu_item_id_seq') INTO menu_item_id;
    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
        VALUES (menu_item_id, third_level_menu_id, 'AllVacanciesView', 'all_vacancies_view.html', 2, NULL, 1, 'page');
    SELECT nextval('page_id_seq') INTO page_id_;
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible)
        VALUES (page_id_, lng_id, 'all_vacancies_view.html', 'AllVacanciesView', Null, 'job', 'page', '2004-02-27 11:52:46', NULL, NULL, NULL, 0);
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (nextval('page_element_id_seq'), page_id_, '0','0','menu-component',NULL);
    SELECT nextval('page_element_id_seq') INTO page_element_id;
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_element_id, page_id_, '0','0','job-module-component',NULL);
    INSERT INTO page_element_params(id, element_id, name, value)
        VALUES (nextval('page_element_params_id_seq'), page_element_id, 'start','AllVacanciesView');

    SELECT nextval('menu_item_id_seq') INTO menu_item_id;
    INSERT INTO menu_item (id, menu_id, title, link, order_, "class", visible, link_type)
        VALUES (menu_item_id, third_level_menu_id, 'GeneralApplicationForm', 'general_application_form.html', 3, NULL, 1, 'page');
    SELECT nextval('page_id_seq') INTO page_id_;
    INSERT INTO page (id, lang_id, filename, title, contents, "class", category, last_modified, protected, publish_date, expired_date, visible)
        VALUES (page_id_, lng_id, 'general_application_form.html', 'GeneralApplicationForm', Null, 'job', 'page', '2004-02-27 11:52:46', NULL, NULL, NULL, 0);
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (nextval('page_element_id_seq'), page_id_, '0','0','menu-component',NULL);
    SELECT nextval('page_element_id_seq') INTO page_element_id;
    INSERT INTO page_element(id, page_id, table_name, domain_table_record_id, class_name, container_id) VALUES
       (page_element_id, page_id_, '0','0','job-module-component',NULL);
    INSERT INTO page_element_params(id, element_id, name, value)
        VALUES (nextval('page_element_params_id_seq'), page_element_id, 'start','GeneralApplicationForm');


    return 1;
end;
$$;

alter function job_insert_menu(integer, integer) owner to antonb2;

