create function update_products_zoom() returns integer
  language plpgsql
as
$$
DECLARE
	rec record;
	n integer := 0;
    zoomValue integer := null;
    imageLink varchar := '';
BEGIN
	for rec in (select * from pm_product) loop
    	select str_value into imageLink from pm_attribute_value 
        	where product_id = rec.id and type_id = 14;
    	select int_value into zoomValue from pm_attribute_value 
        	where product_id = rec.id and type_id = 56;
    	if (imageLink <> '' and (zoomValue is null or zoomValue <> 20)) 
        then        
        	n := n + 1;
            update pm_attribute_value set int_value = 20
	            where product_id = rec.id and type_id = 56;
        end if;
    end loop;
    
	return n;
END;
$$;

alter function update_products_zoom() owner to antonb2;

