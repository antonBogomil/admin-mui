create function add_pm_furl_cat() returns boolean
  language plpgsql
as
$$
declare
  recCat record;
  recCatRS record;
  recProd record;
  langCode VARCHAR;
  catURL VARCHAR;
  titleProd VARCHAR;
begin       

  	for recCat in select * from pm_category where parent_id=1 loop    
    
	  	for recCatRS in select * from string_resource where string_resource.id=recCat.rs_title loop        
        	select "language".code from "language" where id=recCatRS.lang_id into langCode;            

                
              insert into friendly_url(entity_id, lang_id, entity_type_id, link, alternative_link) 
                  values(recCat.id, recCatRS.lang_id, 0, 
                  replace(lower(recCatRS.text),' ','_')||'/', 
                  replace(lower(recCatRS.text),' ','_')||'/');
	    
    	
	    end loop;
    end loop;
   	return true;
    
end;
$$;

alter function add_pm_furl_cat() owner to antonb2;

