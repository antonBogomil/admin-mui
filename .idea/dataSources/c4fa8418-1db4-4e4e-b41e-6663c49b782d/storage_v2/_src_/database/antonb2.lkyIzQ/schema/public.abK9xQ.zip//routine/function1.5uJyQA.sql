create function function1(integer) returns character varying
  language plpgsql
as
$$
DECLARE
  categoryId alias for $1;
  parentCategoryId integer;
  hash varchar;
  parentCatHash varchar;
BEGIN
	hash := 000;
    IF(categoryId > '1') THEN
      SELECT order_number,parent_id INTO hash, parentCategoryId 
      	FROM pm_category WHERE id = categoryId;   
    END IF;
	RETURN hash;
END;

/*SELECT find_category_tree(parentCategoryId) || hash INTO hash;  */
$$;

alter function function1(integer) owner to antonb2;

