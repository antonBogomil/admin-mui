create function get_category_level(integer) returns integer
  language plpgsql
as
$$
  /* New function body */
DECLARE
     cat_id alias for $1;
BEGIN
     IF EXISTS (SELECT parent_id FROM pm_category where id = cat_id)THEN
        RETURN 1 + (SELECT get_category_level ((SELECT parent_id FROM pm_category where id = cat_id)));
     ELSE
         RETURN 0;
     END IF;
END;
$$;

alter function get_category_level(integer) owner to antonb2;

