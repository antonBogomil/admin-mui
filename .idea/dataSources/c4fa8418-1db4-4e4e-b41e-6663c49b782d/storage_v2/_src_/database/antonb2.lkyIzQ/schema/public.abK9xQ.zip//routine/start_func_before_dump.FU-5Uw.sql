create function start_func_before_dump() returns boolean
  language plpgsql
as
$$
BEGIN
  ALTER TABLE list_item ADD COLUMN menu_item_id INTEGER;
  ALTER TABLE guestbook_enumerator ADD COLUMN email VARCHAR;
  ALTER TABLE pm_payment_mail_template ADD COLUMN subject VARCHAR(255);
  ALTER TABLE pm_payment_mail_template ADD COLUMN attachment VARCHAR;
  ALTER TABLE site ADD COLUMN conf_xml TEXT;
  ALTER TABLE site ADD COLUMN mentrix_xml TEXT;
  ALTER TABLE site ADD COLUMN site_name VARCHAR(255);
END;
$$;

alter function start_func_before_dump() owner to antonb2;

