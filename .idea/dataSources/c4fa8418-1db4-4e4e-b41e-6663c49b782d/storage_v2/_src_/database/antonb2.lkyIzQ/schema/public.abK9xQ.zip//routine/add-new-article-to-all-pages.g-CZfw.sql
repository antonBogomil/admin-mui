create function "add-new-article-to-all-pages"(integer) returns boolean
  language plpgsql
as
$$
DECLARE
  articleId alias for $1;
  rec record;  
BEGIN
	FOR rec IN select * from page LOOP    
		perform tpl_generate_article_by_id(rec.id, articleId);
	END LOOP;
    return true;
END;
$$;

alter function "add-new-article-to-all-pages"(integer) owner to antonb2;

