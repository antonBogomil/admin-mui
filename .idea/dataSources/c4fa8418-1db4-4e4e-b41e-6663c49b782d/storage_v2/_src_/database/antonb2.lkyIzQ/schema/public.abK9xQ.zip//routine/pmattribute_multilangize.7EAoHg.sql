create function pmattribute_multilangize(integer, integer) returns integer
  language plpgsql
as
$$
DECLARE
	langId ALIAS FOR $1;
	attributeId ALIAS FOR $2;
	langRd RECORD;
    pm_attribute_valRd RECORD;
BEGIN
 FOR langRd IN SELECT * FROM language WHERE language.id!=langId LOOP
  FOR pm_attribute_valRd IN SELECT * FROM pm_attribute_value WHERE type_id=attributeId AND lang_id=langId LOOP
   INSERT INTO pm_attribute_value (product_id, type_id, str_value, lang_id) VALUES (pm_attribute_valRd.product_id, attributeId, pm_attribute_valRd.str_value, langRd.id);
 END LOOP;
END LOOP;
RETURN 1;
END;
$$;

alter function pmattribute_multilangize(integer, integer) owner to antonb2;

