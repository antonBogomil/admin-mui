create function tpl_create_banner() returns integer
  language plpgsql
as
$$
declare
    pageId int4;
    seqId int4;
    categoryRd record;
begin
     FOR categoryRd IN SELECT * from page where page.category <> 'popup'
          LOOP
          pageId = categoryRd.id;
          select nextval('page_component_id_seq') into seqId;
          insert into page_component
                 (id, page_id, class_name) values
                 (seqId, pageId, 'banner-module-component');
          END LOOP;
     RETURN 1;
end;
$$;

alter function tpl_create_banner() owner to antonb2;

