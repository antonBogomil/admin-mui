create function add_site(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  siteName alias for $1;
  siteUrl alias for $2;

BEGIN

insert into site (name, template_name, lang_id, conf_xml, created_date, last_modified, status, expired)
values(siteName, 'site_template', 1, NULL, now(), now(), 'production', false);

insert into site_url (site_id, url) values(currval('site_id_seq'), siteUrl);
insert into site_property (site_id, name, value) values(currval('site_id_seq'), 'menu.max.depth', 1);
insert into site_property (site_id, name, value) values(currval('site_id_seq'), 'menu.top.items.limit', 3);

INSERT INTO groups (name, role_id, site_id) VALUES ('Administrators', 'administrator', currval('site_id_seq'));

INSERT INTO user_list (username,login,password,type,site_id)
 VALUES ('Administrator','admin',md5('y7wt26'),'administrator',currval('site_id_seq'));
INSERT INTO members (group_id, user_id) VALUES (currval('groups_id_seq'), currval('user_list_id_seq'));

INSERT INTO groups (name, role_id, site_id) VALUES ('Guests', 'guest', currval('site_id_seq'));


------------------------------------------------ INSERT INTO MODULE ---------------------------------------------------------------------

INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ('News module', '2004-03-10 00:00:00', NULL, NULL, 1, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Product module', '2004-06-04 00:00:00', NULL, '?command=pm-get-entry-page', 2, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'FAQ', '2004-03-10 00:00:00', NULL, NULL, 3, currval('site_id_seq'), TRUE);
--INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Jobs-module', '2004-06-04 00:00:00', NULL, 'browse_vacancies', 4, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Security module', '2004-03-10 00:00:00', NULL, 'user_mngr', 4, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Photo album', '2004-03-10 00:00:00', NULL, NULL, 5, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Newsletter module', '2004-03-10 00:00:00', NULL, '?command=nl-browse-category', 6, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Media catalog', '2004-03-10 00:00:00', NULL, '?command=list-directory-command', 7, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Login module', '2004-03-10 00:00:00', NULL, 'visitor_mngr', 8, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Site statistics', '2004-03-10 00:00:00', NULL, '/statistics', 9, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Special pages', '2004-03-10 00:00:00', NULL, 'popuplist_editor', 10, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Ticker-streamer', NULL, NULL, NULL, 11, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Form manager', '2004-10-09 00:00:00', NULL, '?command=manage-forms', 12, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Web poll', '2004-10-09 00:00:00', NULL, NULL, 13, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Event calendar module', '2004-10-09 00:00:00', NULL, '?command=get-event-schedule-command', 14, currval('site_id_seq'), TRUE);
--INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Label module', '2004-03-10 00:00:00', NULL, '?command=manage-labels-command', 15, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Store locator', '2005-01-28 00:00:00', NULL, 'store_locator', 16, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Site dynamics', '2004-10-09 00:00:00', NULL, '?command=site-dynamics-command', 17, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Contact book', '2005-03-01 00:00:00', NULL, 'contact_book', 18, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Inquiry module', '2005-03-02 00:00:00', NULL, '/admin/inquiry', 19, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Dictionary', '2005-03-11 00:00:00', NULL, 'glossary', 20, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Job module', '2005-04-05 06:30:00', NULL, 'j_module', 21, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Document module', '2005-04-12 06:30:00', NULL, 'document_module', 22, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ( 'Forum', '2005-04-12 06:30:00', NULL, '/mvnforum/mvnforumadmin/index', 23, currval('site_id_seq'), TRUE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ('langhenkel','10.02.2006 0:00:00',null,'/admin/langhenkel/menu.html',24,currval('site_id_seq'), FALSE);
INSERT INTO module ( name, golive, expired, url, order_number, site_id, hide_from_user) VALUES ('search','10.02.2006 0:00:00',null,'/admin/search',25,currval('site_id_seq'), FALSE);

-- Main menu for the first language
INSERT INTO menu ( lang_id, parent_menu_item_id, level, site_id) VALUES ( 1, NULL, 1, currval('site_id_seq'));
-- "Home page" in main menu
INSERT INTO menu_item (menu_id, title, link,  order_, link_type) VALUES ( currval('menu_id_seq'), 'Home page','home.html',1,'page');

-- Special pages menu for the first language
INSERT INTO menu ( lang_id, parent_menu_item_id, level, site_id) VALUES ( 1, NULL, 0, currval('site_id_seq'));

-- "Error page" in "Special pages" menu
INSERT INTO menu_item ( menu_id, title, link,  order_, link_type) VALUES ( currval('menu_id_seq'), 'Resource not found','error.html',1,'page');
-- "Access denied" in "Special pages" menu
INSERT INTO menu_item ( menu_id, title, link,  order_, link_type) VALUES ( currval('menu_id_seq'), 'Access denied','access_denied.html',2,'page');
-- "Mail success" in "Special pages" menu
INSERT INTO menu_item ( menu_id, title, link,  order_, link_type) VALUES ( currval('menu_id_seq'), 'Mail success','success.html',3,'page');
-- "Mail failure" in "Special pages" menu
INSERT INTO menu_item ( menu_id, title, link,  order_, link_type) VALUES ( currval('menu_id_seq'), 'Mail failure','failure.html',4,'page');



-- Article for the frontpage
INSERT INTO article (lang_id, text) VALUES (1,'This is the frontpage text');

INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES (1,'index.html','Welcome',NULL,'frontpage','frontpage','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component (page_id, class_name) values (currval('page_id_seq'), 'menu-component');
insert into page_component (page_id, class_name) values (currval('page_id_seq'), 'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));

-- Article for the homepage
INSERT INTO article (lang_id, text) VALUES (1,'This is the homepage text');

-- home page
INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES (1,'home.html','Welcome',NULL,'homepage','page','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component ( page_id, class_name) values ( currval('page_id_seq'), 'menu-component');
insert into page_component ( page_id, class_name) values ( currval('page_id_seq'), 'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));

-- Article for the error page
INSERT INTO article (lang_id, text) VALUES (1,'Resourse not found');

-- "Page not found"
INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES (1,'error.html','Resource not found',NULL,NULL,'not_found','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'menu-component');
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));


-- Articles for "mailed" pages
INSERT INTO article (lang_id, text) VALUES (1,'Successfully mailed text');
-- "Mail success"
INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES (1,'success.html','Success',NULL,NULL,'mail_success','2004-03-06 16:28:54','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'menu-component');
insert into page_component (page_id, class_name) values (currval('page_id_seq'),  'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));

INSERT INTO article (lang_id, text) VALUES (1,'Mailed with failure');
-- "Mail failure"
INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES ( 1,'failure.html','Failure',NULL,NULL,'mail_failure','2004-03-06 16:29:19','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'menu-component');
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));

-- Article for the "Access denied" page
INSERT INTO article (lang_id, text) VALUES (1,'Access is denied');
-- "Access denied"
INSERT INTO page (lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, attribute_set_id, site_id) VALUES ( 1,'access_denied.html','Access denied',NULL,NULL,'access_denied','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, null,currval('site_id_seq'));
insert into page_component (page_id, class_name) values (currval('page_id_seq'),  'menu-component');
insert into page_component ( page_id, class_name) values (currval('page_id_seq'), 'article-component');
insert into page_component_params (element_id, name, value) values (currval('page_component_id_seq'), 'id', currval('article_id_seq'));

    return 1;
END;
$$;

alter function add_site(varchar, varchar) owner to antonb2;

