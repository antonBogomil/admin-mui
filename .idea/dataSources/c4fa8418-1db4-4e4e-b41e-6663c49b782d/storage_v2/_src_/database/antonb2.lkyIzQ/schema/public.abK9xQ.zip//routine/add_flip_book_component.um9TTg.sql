create function add_flip_book_component() returns boolean
  language plpgsql
as
$$
DECLARE
  rec  record;
BEGIN
  FOR rec IN select * from page where class='flip_book' loop
  	if (not exists (select * from page_component where page_id = rec.id and class_name='flipBookComponent')) THEN
    	insert into page_component(page_id, class_name) values (rec.id, 'flipBookComponent');
    end if;
  end loop;
  RETURN true;
END;
$$;

alter function add_flip_book_component() owner to antonb2;

