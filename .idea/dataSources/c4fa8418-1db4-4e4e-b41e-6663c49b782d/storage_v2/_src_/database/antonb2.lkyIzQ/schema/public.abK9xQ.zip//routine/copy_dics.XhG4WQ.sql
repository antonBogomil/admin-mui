create function copy_dics() returns integer
  language plpgsql
as
$$
DECLARE
 rec record;
 n int4;
 tmp_id int4;
 tmp_entry_id varchar;
BEGIN
	n:=0;	
	FOR rec IN select * from tmp_dic1 LOOP
		insert into dictionary(id, dictionary_file_id,entry_id,lang_code,entry) 
               	values(rec.id,rec.dictionary_file_id,rec.entry_id,rec.lang_code,rec.entry);                   
		n:= n+1;		
    END LOOP;
    return n;
END;
$$;

alter function copy_dics() owner to antonb2;

