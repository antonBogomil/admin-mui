create function "add-through-article-to-all-pages"() returns boolean
  language plpgsql
as
$$
DECLARE
  rec record;
BEGIN
	FOR rec IN select * from page LOOP    
	    perform tpl_generate_article_through_by_id(rec.id, 39);
	END LOOP;
    return true;
END;
$$;

alter function "add-through-article-to-all-pages"() owner to antonb2;

