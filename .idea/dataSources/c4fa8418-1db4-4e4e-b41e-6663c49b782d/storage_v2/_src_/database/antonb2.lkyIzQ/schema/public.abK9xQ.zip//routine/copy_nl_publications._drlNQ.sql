create function copy_nl_publications() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
	rec record;
	rec1 record;
	
	pubState integer := 1;
	i18nInt integer;
	i18nBoolean boolean := false;
    mailTemp integer := 1;
BEGIN
	n:=0;
		
   	for rec in select * from nl_publication1 loop    									
		update nl_publication_i18n_fields set text = (select text from article where id = (select article_id from nl_publ2article1 where id = rec.id));
        
		n:=n+1;
	end loop;

    return n;
END;
$$;

alter function copy_nl_publications() owner to antonb2;

