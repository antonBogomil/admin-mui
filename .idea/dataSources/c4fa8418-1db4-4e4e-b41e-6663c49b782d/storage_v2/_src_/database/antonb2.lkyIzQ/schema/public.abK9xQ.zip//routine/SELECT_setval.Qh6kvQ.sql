create function "SELECT setval"() returns boolean
  language plpgsql
as
$$
DECLARE
BEGIN
  SELECT setval('ss_order_id_seq', (select max(id)+1 from ss_order) +1);
  RETURN TRUE;
END;
$$;

alter function "SELECT setval"() owner to antonb2;

