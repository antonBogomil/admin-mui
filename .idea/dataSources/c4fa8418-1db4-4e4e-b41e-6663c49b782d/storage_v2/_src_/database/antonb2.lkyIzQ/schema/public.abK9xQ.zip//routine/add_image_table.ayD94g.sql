create function add_image_table() returns integer
  language plpgsql
as
$$
DECLARE
	n integer;
    rec record;
    
BEGIN

for rec in select * from page where (page.lang_id=8) loop
	insert into image(image_set_id, src, required_height, required_width,_order)  
		 values (rec.attribute_set_id,'media/banners/en_banner_15.jpg','147', '1200', '15'); 
    end loop;
   return n;
END;
$$;

alter function add_image_table() owner to antonb2;

