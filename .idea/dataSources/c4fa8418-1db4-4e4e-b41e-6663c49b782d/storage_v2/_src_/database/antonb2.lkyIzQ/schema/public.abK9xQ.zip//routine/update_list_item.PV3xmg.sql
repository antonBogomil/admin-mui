create function update_list_item() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleTs int4;
  articleId int4;
 
begin	


 for rec in select * from list_item_old loop
 
	select nextval('article_id_seq') into articleTs;
    insert into article
        (id, lang_id, head, text, class) values
        (articleTs, (select article_old.lang_id from article_old where article_old.lang_id = rec.teaser_id), 'Enter your text here', (select article_old.text from article_old where article_old.id = rec.teaser_id), 'cls') ;						
       

	select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, head, text, class) values
        (articleId, (select article_old.lang_id from article_old where article_old.lang_id = rec.article_id), 'Enter your text here', (select article_old.text from article_old where article_old.id = rec.article_id), 'cls') ;						
       
	insert into list_item(id, list_id, title, teaser_id, order_number, visible, link, image_link, document_link, type, view_date, publish_date, expired_date, created_by, created_date, last_modified_by, last_modified_date, article_id, thumbnail_link, list_item_link, parameters, container_id, site_id) 
		VALUES (rec.id, rec.list_id, rec.title, articleTs, rec.order_number, rec.visible, rec.link, rec.image_link, rec.document_link, rec.type, rec.view_date, rec.publish_date, rec.expired_date, rec.created_by, rec.created_date, 1, rec.last_modified_date, articleId, rec.thumbnail_link, rec.list_item_link, rec.parameters, rec.container_id, rec.site_id);
    

  end loop;
  return true;
  
  end;
$$;

alter function update_list_item() owner to antonb2;

