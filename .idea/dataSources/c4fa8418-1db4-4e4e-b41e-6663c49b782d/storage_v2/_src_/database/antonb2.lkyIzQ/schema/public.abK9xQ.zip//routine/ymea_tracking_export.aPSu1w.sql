create function ymea_tracking_export(integer[], date[]) returns character varying
  language plpgsql
as
$$
declare
  weekNumbers alias for $1;
  weeks alias for $2;
  person tracking_person%rowtype;
  question tracking_question%rowtype;
  qid record;
  pos int4;
  res varchar;
  curWeek int4;
  temp varchar;
begin
  res := now() || '
';
  res := res || '--------- Vragen (%) ---------------
';
  pos := 1;
  for question in select * from tracking_question where type = 'number' order by position loop
    res := res || pos || '. ' || question.title || '
';
    pos := pos + 1;
  end loop;
  res := res || '--------- Vragen (+/-) --------------
';
  pos := 1;
  for question in select * from tracking_question where type = 'checkbox' order by position loop
    res := res || pos || '. ' || question.title || '
';
    pos := pos + 1;
  end loop;
  for person in select * from tracking_person order by name loop
    res := res || '
------------------------------------
';
    
    res := res || 'Naam;' || coalesce(person.name,'') || ';
';
    res := res || 'E-mail;' || coalesce(person.email,'') || ';
';
    res := res || 'Wachtwoord;' || coalesce(person.password,'') || ';
';
    if person.reminder then temp := '+'; else temp := '-'; end if;
    res := res || 'Ja, ik wil graagiedere week een herinnering via de e-mail ontvangen om de patroonvolger van mijn overgangsverschijnselen bij te werken op de website. (deze herinneringsmail kan op ieder moment worden opgezegd);' || temp || ';
';
    if person.harvest then temp := '+'; else temp := '-'; end if;
    res := res || 'Ja, ik wil ook graag door Ymea op de hoogte gehouden worden van nieuwe producten, ontwikkelingen en nieuwtjes. (Deze e-mail kan op ieder moment worden opgezegd);' || temp || ';
';
    res := res || 'Geboortejaar;' || coalesce(person.birthday,'') || ';
';
    res := res || 'Hoe lang denk je dat je al in de overgang bent?;' || coalesce(person.q2,'') || ';
';
    res := res || 'Gebruik je een product tegen overgangsverschijnselen?;' || coalesce(person.q3,'') || ';
';
    res := res || 'Wanneer je de vorige vraag met ja hebt beantwoord, hoe lang gebruik je dit product al?;' || coalesce(person.q4,'') || ';
';
    res := res || 'Wanneer je Ymea of Ymea Plus gebruikt, hoeveel tabletten/ capsules gebruik je van dit product per dag?;' || coalesce(person.q5,'') || ';
';
    res := res || '
';
    
    -- PRINT WEEK NUMBERS
    res := res || 'Week;';
    for curWeek in 1..array_upper(weekNumbers, 1) loop
      res := res || weekNumbers[curWeek] || ';';
    end loop;
    res := res || '
';
    
    -- FOR EACH NUMERIC QUESTION, PRINT WEEKLY ANSWERS
    res := res || 'Vraag(%)
';
    pos := 1;
    for qid in select id from tracking_question where type = 'number' order by position loop
      res := res || pos || ';';
      for curWeek in 1..array_upper(weeks, 1) loop
        res := res || get_visit_value(person.id, qid.id, weeks[curWeek][1], weeks[curWeek][2], 'number') || ';';
      end loop;
      res := res || '
';
      pos := pos + 1;
    end loop;
    
    -- FOR EACH BOOLEAN QUESTION, PRINT WEEKLY ANSWERS
    res := res || 'Vraag(+/-)
';
    pos := 1;
    for qid in select id from tracking_question where type = 'checkbox' order by position loop
      res := res || pos || ';';
      for curWeek in 1..array_upper(weeks, 1) loop
        res := res || get_visit_value(person.id, qid.id, weeks[curWeek][1], weeks[curWeek][2], 'checkbox') || ';';
      end loop;
      res := res || '
';
      pos := pos + 1;
    end loop;
    
  end loop;
  return res;
end;
$$;

alter function ymea_tracking_export(integer[], date[]) owner to antonb2;

