create function sort_date(timestamp without time zone) returns integer
  language plpgsql
as
$$
  /* New function body */
DECLARE 
dayofyear1 integer;
dayofyear2 integer;
begin
dayofyear1 = (SELECT right_day($1));
dayofyear2 = (SELECT EXTRACT(DOY FROM (select now())));
if dayofyear2 > dayofyear1 then
   return dayofyear1 + 1000;
else
    RETURN dayofyear1;
end if;
end
$$;

alter function sort_date(timestamp) owner to antonb2;

