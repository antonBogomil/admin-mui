create function add_art_contact() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
  langId int4;  
begin
  for rec in select * from page where lang_id = 4 AND id = 157 loop
    perform tpl_generate_article_through_by_id(rec.id,
    	(SELECT id from article WHERE head='slogan' AND lang_id=4 LIMIT 1));
  end loop;
  return true;
end;
$$;

alter function add_art_contact() owner to antonb2;

