create function tick_add_subscriber(integer, integer, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  _nlCatId alias for $1;
  _langId alias for $2;
  _email alias for $3;
  _fname alias for $4;
  _sName alias for $5;
  subscriberId integer := -1;
  siteId integer := 1;
BEGIN
  SELECT nextval('nl_subscriber_id_seq') INTO subscriberId;
  
  INSERT INTO nl_subscriber (id, email, sname, fname, site_id)
  VALUES (subscriberId, _email, _sname, _fname, siteId);

  INSERT INTO nl_subscription (subscriber_id, lang_id, category_id, is_html)
  VALUES (subscriberId, _langId, _nlCatId, true);

  RETURN subscriberId;

END;
$$;

alter function tick_add_subscriber(integer, integer, varchar, varchar, varchar) owner to antonb2;

