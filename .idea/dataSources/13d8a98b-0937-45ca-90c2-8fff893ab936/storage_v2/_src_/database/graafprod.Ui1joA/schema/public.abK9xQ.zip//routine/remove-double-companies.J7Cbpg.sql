create function "remove-double-companies"() returns integer
  language plpgsql
as
$$
DECLARE
 rec record;
 rec1 record;
 n int4;
 s VARCHAR;
BEGIN
	n:=0;
	FOR rec IN select * from skd_company LOOP
		FOR rec1 IN select * from skd_company where vwa_license = rec.vwa_license and id > rec.id LOOP
			if( (rec1.name = rec.name)  and 
            	rec.user_id = 1 and
            	--(rec1.email = rec.email) and
                --(rec1.address = rec.address) and 
                --(rec1.certificate_number = rec.certificate_number) and
                --(rec1.status = rec.status) and
   				--(rec1.cattle = rec.cattle) and 
				--(rec1.calves = rec.calves) and 
				--(rec1.pigs = rec.pigs) and 
				--(rec1.sheep_goats = rec.sheep_goats) and
                --(rec1.horses = rec.horses) and 
                --(rec1.o_export_module = rec.o_export_module) and 
                --(rec1.t_export_module = rec.t_export_module) and
                --(rec1.t_transport_module = rec.t_transport_module) and 
                --(rec1.ubn_number = rec.ubn_number) and 
                --(rec1.second_calves = rec.second_calves) and
                --(rec1.second_sheep_goats = rec.second_sheep_goats) and 
                --(rec1.graziery = rec.graziery) and 
                (rec1.company_type = rec.company_type)
               ) then
				delete from skd_company where id = rec.id;
               	n:= n+1;
            end if;
  		END LOOP;
    END LOOP;
    return n;
END;
$$;

alter function "remove-double-companies"() owner to graafprod;

