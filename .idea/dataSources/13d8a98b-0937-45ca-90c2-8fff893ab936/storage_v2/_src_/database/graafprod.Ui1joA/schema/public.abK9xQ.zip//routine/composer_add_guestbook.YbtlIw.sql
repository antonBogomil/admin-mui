create function composer_add_guestbook(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    gbName alias for $1;
    pageName alias for $2;

    gbEnumId integer := -1;
    pageElementId integer := -1;
    pageId integer := -1;
    siteId integer := 1;

    -- constatnts
    LIST_MODULE_ID integer := 29;
    GB_PAGE_CLASS varchar := 'guestbook';
    GB_PAGE_COMPONENT_CLASS varchar := 'guestbook-component';
    GB_PAGE_COMPONENT_ELEMENT varchar := 'gb_id';
    

BEGIN

  -- guestbook_enumerator
  SELECT nextval('guestbook_enumerator_id_seq') INTO gbEnumId;
    INSERT INTO guestbook_enumerator (id, name, site_id)
    VALUES (gbEnumId, gbName, siteId)
  ;

  -- page
  SELECT id INTO pageId FROM page WHERE filename=pageName;
  IF pageId IS NULL THEN
    RETURN -1;
  END IF;
  
  -- page_element
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, GB_PAGE_COMPONENT_CLASS);
  
  -- page_element_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, GB_PAGE_COMPONENT_ELEMENT, gbEnumId);

  UPDATE page SET class=GB_PAGE_CLASS, protected='nodelete' WHERE id=pageId;

RETURN 1;
END;
$$;

alter function composer_add_guestbook(varchar, varchar) owner to graafprod;

