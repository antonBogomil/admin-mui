create function composer_add_faq(character varying) returns integer
  language plpgsql
as
$$
DECLARE
    pageName alias for $1;
BEGIN


  RETURN 1;
END;
$$;

alter function composer_add_faq(varchar) owner to graafprod;

