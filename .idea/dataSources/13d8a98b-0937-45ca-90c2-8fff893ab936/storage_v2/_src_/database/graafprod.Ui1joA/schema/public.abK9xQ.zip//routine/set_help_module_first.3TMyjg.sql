create function set_help_module_first() returns boolean
  language plpgsql
as
$$
DECLARE
	rec record;
BEGIN
	for rec in (select * from module) loop
		update module set order_number = rec.order_number + 1 where id = rec.id;
    end loop;
	update module set order_number = 1 where id = 43;
    return true;
END;
$$;

alter function set_help_module_first() owner to graafprod;

