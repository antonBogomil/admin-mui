create function cb_delete_cb_cont_group_contact() returns trigger
  language plpgsql
as
$$
BEGIN
     DELETE FROM contact
     WHERE id=OLD.contact_id AND type='contact_book';
     RETURN OLD;
END;
$$;

alter function cb_delete_cb_cont_group_contact() owner to graafprod;

