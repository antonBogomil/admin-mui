create function insert_spec_pages() returns boolean
  language plpgsql
as
$$
declare
       rec record;
       rec2 record;
       rec3 record;
       lang integer;
       lang1 integer;
       menuiId integer;
       visi BOOLEAN;
BEGIN
     FOR rec in select * FROM page_old loop
         if not EXISTS (select * from page where page.filename = rec.filename) then

            lang1:= rec.lang_id;
            if lang1 > 1 THEN
               lang1:= rec.lang_id + 1;
            end if;
            
            visi:= false;
            if rec.visible = 1 THEN
               visi:= true;
            end if;
            INSERT INTO page (lang_id, filename, title, contents, class, category,
            last_modified, protected, publish_date, expired_date, visible, container_id,
            attribute_set_id, site_id, is_search) VALUES
            (lang1, rec.filename, rec.title, rec.contents, rec.class, rec.category,
            rec.last_modified, rec.protected, rec.publish_date, rec.expired_date, visi, 1,
            rec.attribute_set_id, 1, TRUE);
            
            select * into rec2 from menu_item_old where link = rec.filename;
            
            lang:= rec2.lang_id;
            if lang > 1 THEN
               lang:= rec2.lang_id + 1;
            end if;
            
            menuiId:= (select id from menu where level = 0 AND lang_id = lang);
            
            INSERT INTO menu_item (menu_id, title, link, order_, class, link_type)
            VALUES (menuiId,
            rec2.title, rec2.link,
            (select max(id) + 1 from menu_item where menu_id = menuiId),
            rec2.class,
            rec2.link_type);
            
            for rec3 IN select * from page_element_old where page_id = rec.id loop
                insert into page_component (page_id, class_name) VALUES
                ((select max(id) from page), rec3.class_name);
                if rec3.class_name = 'article-component' THEN
                   select * INTO rec2 from article_old where id =
                   (select value from page_element_params_old where element_id =
                   rec3.id)::INT4;
                   
                   insert into article (lang_id, head, text, class,
                   last_modified) VALUES
                   (lang1, rec2.head, rec2.text, rec2.class, (select now()));
                   
                   insert into page_component_params (element_id, name, value) VALUES
                   ((select max(id) from page_component), 'id', (select max(id) from article));
                end if;
            end loop;
         end if;
     end loop;
     return true;
END;
$$;

alter function insert_spec_pages() owner to graafprod;

