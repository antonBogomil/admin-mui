create function add_multilang_pm() returns boolean
  language plpgsql
as
$$
declare
  rec record;  
  articleId int4;
  temp int4;
begin
  for rec in 
select * from pm_attribute_value where pm_attribute_value.type_id in (
select id from pm_attribute_type where pm_attribute_type.product_type_id=3 and 
(name='afmetingen_tuinhuizen' or name='typenummer' or name='wanddikte' or
name='binnenmaat' or name='fundamentmaat' or name='oppervlakte' or name='inhoud' or
name='wandhoogte' or name='nokhoogte' or name='dakoppervlak' or name='fund_balken' or
name='regengoot_set' or name='deur_type' or name='dagmaat_deur' or name='raam_type' or
name='afmeting_raam' or name='roedeverdeling' or name='beglazing') ) loop    	
    insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
    	values(rec.product_id,rec.type_id,rec.str_value,2);

    insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
    	values(rec.product_id,rec.type_id,rec.str_value,3);
        
    insert into pm_attribute_value(product_id,type_id,str_value,lang_id) 
    	values(rec.product_id,rec.type_id,rec.str_value,4);
  end loop;
  return true;
end;
$$;

alter function add_multilang_pm() owner to graafprod;

