create function copy_artcile() returns boolean
  language plpgsql
as
$$
declare
  rec record;

begin

    for rec in select * from page loop
        INSERT INTO page_component(page_id,class_name)
          VALUES (rec.id,'article-component');
        INSERT INTO page_component_params(element_id,name,value)
          VALUES ((SELECT MAX(id) FROM page_component LIMIT 1),'id', (SELECT id FROM article WHERE head='footer' LIMIT 1));
    end loop;

  return true;
end;
$$;

alter function copy_artcile() owner to graafprod;

