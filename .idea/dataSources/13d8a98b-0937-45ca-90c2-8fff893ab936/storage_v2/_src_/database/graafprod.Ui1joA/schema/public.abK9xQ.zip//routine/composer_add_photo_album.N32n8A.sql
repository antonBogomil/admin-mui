create function composer_add_photo_album(character varying, integer, integer, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  listTitle alias for $1;
  imageWidth alias for $2;
  imageHeight alias for $3;
  listPageName alias for $4;
  pageContents alias for $5;

  -- constatnts
  LIST_MODULE_ID integer := 7;
  LIST_PAGE_CLASS varchar := 'photo_album';
  LIST_INSTANCE_NAME varchar := 'Photo album';
  TEMPLATE_NAME varchar := 'photo_album';

  langId integer := -1;
  pageId integer := -1;
  listId integer := -1;
  pageElementId integer := -1;
  templateId integer := -1;
  pContents varchar := '';
BEGIN
  SELECT lang_id INTO langId FROM page WHERE filename=listPageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;
  
  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = TEMPLATE_NAME) AND (module_id = MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, TEMPLATE_NAME)
    ;
  END IF;
  
  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id)
    VALUES (listId, listTitle, langId, 1, '', imageWidth, imageHeight, LIST_MODULE_ID, LIST_INSTANCE_NAME, templateId)
  ;

  pContents := replace(pageContents, '$id', listId);
  
  SELECT id INTO pageId FROM page WHERE filename=listPageName;
  IF pageId IS NULL THEN
    RETURN -1;
  END IF;

  UPDATE page SET class=LIST_PAGE_CLASS, protected='nodelete', contents=pContents WHERE id=pageId;
  

  RETURN listId;
END;
$$;

alter function composer_add_photo_album(varchar, integer, integer, varchar, varchar) owner to graafprod;

