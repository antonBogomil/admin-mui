create function tpl_create_article(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    langId int4;
    articleId int4;
begin
    select lang_id into langId from page where id = pageId;
    select nextval('article_id_seq') into articleId;
    insert into article
        (id, lang_id, text) values
        (articleId, langId, '<p>Page is under construction</p>');
    return articleId;
end;
$$;

alter function tpl_create_article(integer) owner to graafprod;

