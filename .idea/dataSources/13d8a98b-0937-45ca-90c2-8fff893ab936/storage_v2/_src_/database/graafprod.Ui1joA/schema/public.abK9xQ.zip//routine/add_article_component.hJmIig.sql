create function add_article_component(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  pageName alias for $1;
  componentName alias for $2;
  pageClassName alias for $3;

  langId integer := -1;
  articleId integer := -1;
  pageElementId integer := -1;
BEGIN

  SELECT add_standard_component(pageName, componentName, pageClassName) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;
  
  SELECT lang_id INTO langId FROM page WHERE filename=pageName;

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
    INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', '<p>This is the article text</p>', NULL);
  
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'id', articleId);

  RETURN articleId;
END;
$$;

alter function add_article_component(varchar, varchar, varchar) owner to graafprod;

