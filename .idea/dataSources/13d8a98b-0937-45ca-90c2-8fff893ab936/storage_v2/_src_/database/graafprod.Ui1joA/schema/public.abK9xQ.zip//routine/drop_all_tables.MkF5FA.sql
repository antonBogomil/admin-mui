create function drop_all_tables() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  sname varchar;
begin
  sname := 'public';
  for rec in select * from pg_tables where schemaname = 'public' loop
    execute 'drop table ' || rec.tablename || ' cascade';
  end loop;
  return true;
end;
$$;

alter function drop_all_tables() owner to graafprod;

