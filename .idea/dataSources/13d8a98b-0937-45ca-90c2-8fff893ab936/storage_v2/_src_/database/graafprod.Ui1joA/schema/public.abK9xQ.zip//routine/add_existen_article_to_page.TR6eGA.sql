create function add_existen_article_to_page(character varying, character varying, character varying, integer) returns integer
  language plpgsql
as
$$
DECLARE
  pageName alias for $1;
  componentName alias for $2;
  pageClassName alias for $3;
  articleId alias for $4;

  pageElementId integer := -1;
BEGIN

  SELECT add_standard_component(pageName, componentName, pageClassName) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;

   -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'id', articleId);

  RETURN articleId;
END;
$$;

alter function add_existen_article_to_page(varchar, varchar, varchar, integer) owner to graafprod;

