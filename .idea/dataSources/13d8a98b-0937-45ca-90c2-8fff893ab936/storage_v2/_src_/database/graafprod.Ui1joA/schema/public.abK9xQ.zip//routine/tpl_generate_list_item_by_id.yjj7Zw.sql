create function tpl_generate_list_item_by_id(integer) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    pageElemId int4;
begin
    select nextval('page_component_id_seq') into pageElemId;
    insert into page_component
        (id, page_id, class_name) values
        (pageElemId, pageId, 'list-item-component');
    return pageElemId;
end;
$$;

alter function tpl_generate_list_item_by_id(integer) owner to graafprod;

