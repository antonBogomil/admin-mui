create function "add-dict"(integer, character varying, character varying) returns boolean
  language plpgsql
as
$$
DECLARE
 fileId alias for $1;
 constName alias for $2;
 constValue alias for $3;
 rec varchar;
BEGIN 
    for rec in (select code from core_reference) loop
    insert into dictionary(dictionary_file_id,entry_id, lang_code, entry) 
values(fileId,constName, rec, constValue);
    end loop;
    return true;
END;
$$;

alter function "add-dict"(integer, varchar, varchar) owner to graafprod;

