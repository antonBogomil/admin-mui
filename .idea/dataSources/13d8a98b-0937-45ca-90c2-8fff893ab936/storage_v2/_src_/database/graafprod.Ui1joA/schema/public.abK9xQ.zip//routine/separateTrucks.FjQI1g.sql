create function "separateTrucks"() returns integer
  language plpgsql
as
$$
DECLARE
  n int4 := 0;
  rec record;
  Number varchar;
BEGIN
	for rec in select * from skd_truck where characterise like '%;%' loop
		for Number in (select regexp_split_to_table(characterise, ';') from skd_truck where id = rec.id) loop
        	insert into skd_truck (characterise, approval_date, approval_number, 
							   booklet_number, chassis_number, lv1_m2, lv2_m2, 
                               lv3_m2, lv4_m2, lv5_m2, tractor, fourgon, 
                               trailer, semitrailer, company_id) 
	        values(Number, rec.approval_date, rec.approval_number, 
            	   rec.booklet_number, rec.chassis_number, rec.lv1_m2, rec.lv2_m2, 
	               rec.lv3_m2, rec.lv4_m2, rec.lv5_m2, rec.tractor, rec.fourgon, 
    	           rec.trailer, rec.semitrailer, rec.company_id);
            delete from skd_truck where id = rec.id;
            n:=n+1;
        end loop;
	end loop;
    
	return n;
END;
$$;

alter function "separateTrucks"() owner to graafprod;

