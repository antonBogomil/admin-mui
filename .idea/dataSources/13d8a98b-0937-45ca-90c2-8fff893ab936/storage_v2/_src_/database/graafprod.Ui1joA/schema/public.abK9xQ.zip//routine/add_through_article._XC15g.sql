create function add_through_article() returns boolean
  language plpgsql
as
$$
declare
  rec record;
  articleId int4;
begin
  for rec in select DISTINCT ON (id) * from page where not(lang_id=1) loop
    perform tpl_generate_article_through_by_id(rec.id,  
    (SELECT id from article WHERE head='footer' and article.lang_id=rec.lang_id LIMIT 1));
  end loop;
  return true;
end;
$$;

alter function add_through_article() owner to graafprod;

