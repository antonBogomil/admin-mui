create function event_in_period(date, date, date, text) returns boolean
  language plpgsql
as
$$
declare
    event_start_date alias for $1;
    event_end_date alias for $2;
    start_date alias for $3;
    period alias for $4;
    end_date date;
begin
    end_date := start_date + period::interval;
    if event_start_date <= start_date and event_end_date >= start_date then
       return true;
    end if;
    if event_start_date >= start_date and event_end_date < end_date then
       return true;
    end if;
    if event_start_date < end_date and event_end_date >= end_date then
       return true;
    end if;
    return FALSE;
end;
$$;

alter function event_in_period(date, date, date, text) owner to graafprod;

