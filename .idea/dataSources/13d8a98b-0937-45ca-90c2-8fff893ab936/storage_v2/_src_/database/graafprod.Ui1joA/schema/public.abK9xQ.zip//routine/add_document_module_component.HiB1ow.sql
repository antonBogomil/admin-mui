create function add_document_module_component(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
    pageName alias for $1;
    componentName alias for $2;
    pageClass alias for $3;

    addRet int;
BEGIN
    SELECT add_standard_component(pageName, componentName, pageClass) INTO addRet;
    IF addRet=-1 THEN
        RETURN -1;
    END IF;
RETURN 1;
END;
$$;

alter function add_document_module_component(varchar, varchar, varchar) owner to graafprod;

