create function add_language(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  langCode alias for $1;
  langTitle alias for $2;
  rec record;
  categoryRd RECORD;
  langId integer := -1;
  menuId integer := -1;
  menuItemId integer := -1;
  pageId integer := -1;
  articleId integer := -1;
  pageElementId integer := -1;
  siteId integer := 1;
  containerId integer := 1; 		
  titleGroup varchar;
BEGIN

  -- add new language
  SELECT nextval('language_id_seq') INTO langId;
  INSERT INTO language (id, language, code)
    VALUES (langId, langTitle, langCode);

  ----------------------------------------------------------
  -- add main menu
  ----------------------------------------------------------
  SELECT nextval('menu_id_seq') INTO menuId;
  INSERT INTO menu (id, lang_id, parent_menu_item_id, level, site_id)
  VALUES (menuId, langId, NULL, 1, siteId);

  -- Content page
  INSERT INTO menu_item (menu_id, title, link,  order_, class, link_type)
  VALUES (menuId, 'Content page','content_' || langCode || '.html',1,NULL,'page');

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Page is under construction', NULL);

  -- Default container
  SELECT id INTO containerId FROM containers WHERE is_default = true;
  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'content_' || langCode || '.html','Welcome',NULL,'contentpage','page','2004-02-27 11:52:46',NULL,NULL,NULL, TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);

  -- "Front page"
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id,lang_id, head, text, class)
  VALUES (articleId,langId,'head','This is the frontpage text',NULL);

  -- page
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'index_' || langCode || '.html','Welcome',NULL,'frontpage','frontpage','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);
  
  -- menu-component
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- artilce-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);


  ----------------------------------------------------------
  -- add special pages menu
  ----------------------------------------------------------
  -- Special pages menu for the first language
  SELECT nextval('menu_id_seq') INTO menuId;
  INSERT INTO menu (id, lang_id, parent_menu_item_id, level, site_id) 
  VALUES (menuId, langId, NULL, 0, siteId);
  
  -----------------
  -- "Error page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Resource not found', 'error_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Resourse not found', NULL);
  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'error_' || langCode || '.html','Resource not found', NULL, NULL,'not_found','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  



  -----------------
  -- "Mail success page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Mail success', 'success_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  IF langCode='nl' THEN
    INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'Uw bericht is met succes verzonden.', NULL);
  ELSE
    INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'Your data was successfully sent.', NULL);
  END IF; 

  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'success_' || langCode || '.html','Success', NULL, NULL,'mail_success','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);


  -----------------
  -- "Mail failure page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Mail failure', 'failure_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  IF langCode='nl' THEN
    INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'Uw bericht is niet verstuurd, probeert u later nog eens.', NULL);
  ELSE
    INSERT INTO article (id, lang_id, head, text, class)
    VALUES (articleId, langId, 'head', 'Sorry, but your data was not sent. Please try again later.', NULL);
  END IF; 

  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'failure_' || langCode || '.html','Failure', NULL, NULL,'mail_failure','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);

  -----------------
  -- "Access denied page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Access denied', 'access_denied_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Access is denied', NULL);
  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'access_denied_' || langCode || '.html','Access denied', NULL, NULL,'access_denied','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId); 
  

  -----------------
  -- "Disclaimer page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Disclaimer', 'disclaimer_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Page is under construction.', NULL);

  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'disclaimer_' || langCode || '.html','Disclaimer', NULL, NULL,'page','2004-02-27 11:52:46','nodelete',NULL,NULL,TRUE, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  -----------------
  -- "Privacy statement page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Privacy statement', 'privacy_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Page is under construction.', NULL);

  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'privacy_' || langCode || '.html','Privacy statement', NULL, NULL,'page','2004-02-27 11:52:46','nodelete',NULL,NULL,true, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  -----------------
  -- "Colofon page" in "Special pages" menu
  SELECT nextval('menu_item_id_seq') INTO menuItemId;
  INSERT INTO menu_item (id, menu_id, title, link,  order_, class, link_type) 
  VALUES (menuItemId, menuId, 'Colofon', 'colofon_' || langCode || '.html', 1, NULL, 'page');
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'head', 'Page is under construction.', NULL);

  
  -- Page 
  SELECT nextval('page_id_seq') INTO pageId;
  INSERT INTO page (id, lang_id, filename, title, contents, class, category, last_modified, protected, publish_date, expired_date, visible, site_id, container_id)
  VALUES (pageId, langId,'colofon_' || langCode || '.html','Colofon', NULL, NULL,'page','2004-02-27 11:52:46','nodelete',NULL,NULL,true, siteId, containerId);

  -- menu-component 
  insert into page_component (page_id,  class_name)
  values (pageId, 'menu-component');

  -- article-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id,  class_name)
  values (pageElementId, pageId, 'article-component');
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);


  
  -- Newsletter Module  
  FOR rec in SELECT DISTINCT ON (id) id from nl_group loop	
	select title from nl_group_i18n_fields where group_id=rec.id into titleGroup;
	insert into nl_group_i18n_fields(title,group_id,lang_id)   values(titleGroup || ' (' || langCode || ')',rec.id,langId);
  END LOOP;

  FOR rec in SELECT DISTINCT ON (id) id from nl_publication loop	
	select title from nl_publication_i18n_fields where publication_id=rec.id into titleGroup;
	insert into nl_publication_i18n_fields(publication_id,title,lang_id)   values(rec.id,titleGroup || ' (' || langCode || ')',langId);
  END LOOP;  
  
  RETURN 1;
END;
$$;

alter function add_language(varchar, varchar) owner to graafprod;

