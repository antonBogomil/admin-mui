create function add_product_module(character varying, character varying, character varying, character varying, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  _pageName alias for $1;
  _langCode alias for $2;
  _shoppingCartPage alias for $3;
  _checkOutPage alias for $4;
  _accountPage alias for $5;
  _shopLoginPage alias for $6;
  _registerPage alias for $7;

  PRODUCT_MODULE_COMPONENT_NAME varchar := 'product-module-main';
  SHOPPING_CART_COMPONENT_NAME varchar := 'pm-shopping-cart';
  CHECK_OUT_COMPONENT_NAME varchar := 'pm-checkout';
  ACCOUNT_COMPONENT_NAME varchar := 'pm-customer-account';
  SHOP_LOGIN_COMPONENT_NAME varchar := 'pm-customer-login';
  REGISTER_COMPONENT_NAME varchar := 'pm-customer-register';
  PRODUCT_MODULE_PAGE_CLASS varchar := 'pm';
  RESULT_SUCCESS integer := 1;

  errorCode integer := -1;
  menuId integer := null;
  langId integer := -1;
  pageRd RECORD;
BEGIN 
  --check page exists
  SELECT * INTO pageRd FROM page WHERE filename=_pageName;
  IF pageRd.id IS NULL THEN
      RETURN -1;
  END IF;

  --check language code is correct
  SELECT id INTO langId
  FROM language
  WHERE code = _langCode
  LIMIT 1;
  if langId IS NULL THEN
     RETURN -2;
  END IF;

  --retrieving menu_id for non-default languages
  SELECT menu_id INTO menuId
  FROM menu_item
  WHERE link = 'access_denied_' || _langCode || '.html'
  lIMIT 1;

  --retrieving menu_id for default language
  If menuId IS NULL THEN
      SELECT menu_id INTO menuId
      FROM menu_item
      WHERE link = 'access_denied.html'
      lIMIT 1;
      IF menuId IS NULL THEN
         -- can't find menu id
         RETURN -3;
      END IF;
  END IF;

  SELECT add_standard_component(_pageName,
                                PRODUCT_MODULE_COMPONENT_NAME,
                                PRODUCT_MODULE_PAGE_CLASS) INTO errorCode;
  IF errorCode = -1 THEN
      --can't add product module component
      RETURN -4;
  END IF;

  IF _shoppingCartPage IS NOT NULL THEN
    PERFORM add_pm_page(menuId, langId, _shoppingCartPage, 'Shopping cart', SHOPPING_CART_COMPONENT_NAME, 1);
  END IF;
  IF _checkOutPage IS NOT NULL THEN
    PERFORM add_pm_page(menuId, langId, _checkOutPage, 'Checkout', CHECK_OUT_COMPONENT_NAME, 2);
  END IF;
  IF _accountPage IS NOT NULL THEN
    PERFORM add_pm_page(menuId, langId, _accountPage, 'Account', ACCOUNT_COMPONENT_NAME, 3);
  END IF;
  IF _shopLoginPage IS NOT NULL THEN
    PERFORM add_pm_page(menuId, langId, _shopLoginPage, 'Shop login', SHOP_LOGIN_COMPONENT_NAME, 4);
  END IF;
  IF _registerPage IS NOT NULL THEN
    PERFORM add_pm_page(menuId, langId, _registerPage, 'Shop login', REGISTER_COMPONENT_NAME, 5);
  END IF;
  
  RETURN RESULT_SUCCESS;
END;
$$;

alter function add_product_module(varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to graafprod;

