create function is_dynamic(timestamp without time zone, timestamp without time zone, integer) returns boolean
  language plpgsql
as
$$
declare
    publish alias for $1;
    expires alias for $2;
    num_days alias for $3;
    filter_start timestamp := now();
    filter_end timestamp;
begin
    filter_end := filter_start + (num_days || ' days')::interval;
    if publish is not null and expires is not null and expires <= publish then
        return FALSE;
    end if;
    if expires is not null and filter_start <= expires and expires <= filter_end then
        return TRUE;
    end if;
    if publish is not null and filter_start <= publish and publish <= filter_end then
        return TRUE;
    end if;
    return FALSE;
end;
$$;

alter function is_dynamic(timestamp, timestamp, integer) owner to graafprod;

