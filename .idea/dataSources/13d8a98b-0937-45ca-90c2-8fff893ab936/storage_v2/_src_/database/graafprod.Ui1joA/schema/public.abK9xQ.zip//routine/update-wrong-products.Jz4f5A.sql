create function "update-wrong-products"() returns integer
  language plpgsql
as
$$
DECLARE
  rec record;
  rec1 record;
  n INTEGER:=0;
  prodTypeId integer;
  pmAttrValId integer;
BEGIN
	for rec in (select * from pm_product where type_id = 12) loop
		for rec1 in (select * from pm_attribute_value where product_id = rec.id) 
        loop
	        select product_type_id into prodTypeId from pm_attribute_type
            where id = (select type_id from pm_attribute_value 
            			where id = rec1.id);
            if (prodTypeId <> 12) then 
            	select id into pmAttrValId from pm_attribute_type 
            	where rs_name = (select rs_name 
                            	 from pm_attribute_type 
                                 where id = rec1.type_id) 
                and product_type_id = 12;

                update pm_attribute_value 
                set type_id = pmAttrValId                	
            	where id = rec1.id;
                
                n:= n+1;
            end if;
        end loop;
    end loop;
    return n;
END;
$$;

alter function "update-wrong-products"() owner to graafprod;

