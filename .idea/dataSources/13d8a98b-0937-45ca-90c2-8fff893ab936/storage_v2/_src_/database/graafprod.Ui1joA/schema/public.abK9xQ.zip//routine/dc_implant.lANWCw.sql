create function dc_implant(integer) returns integer
  language plpgsql
as
$$
declare
    siteId alias for $1;
    rootCategoryId int4 :=1;
    categoryId int4 :=1;
    documentId int4 :=1;
    mcFolderId int4 :=1;
    
begin
    -- --------------------------------SETUP ROOT FOLDER/CATEGORY ------------
  SELECT id INTO rootCategoryId FROM dc_category WHERE parent_id IS NULL;
  IF rootCategoryId IS NULL THEN
      -- -------------------------------- ROOT FOLDER/CATEGORY ------------
      mcFolderId = mc_create_folder('media/documents/', NULL, siteId);

    SELECT nextval('dc_category_id_seq') INTO rootCategoryId;
      INSERT INTO dc_category(id, name, mc_folder_id, order_number, site_id) 
        VALUES(rootCategoryId, 'Root category', mcFolderId, rootCategoryId, siteId);

  END IF;
    return 1;
end;
$$;

alter function dc_implant(integer) owner to graafprod;

