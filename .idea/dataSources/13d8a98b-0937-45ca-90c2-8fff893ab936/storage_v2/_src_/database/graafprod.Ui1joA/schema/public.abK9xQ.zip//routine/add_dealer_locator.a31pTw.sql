create function add_dealer_locator(character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE    
    typeName alias for $1;
    pageName alias for $2;

    langId integer := -1;
    pageElementId integer := -1;
 
    pageId integer := -1;
    articleId integer := -1;
BEGIN  

	SELECT lang_id INTO langId FROM page WHERE filename=pageName;
	IF langId IS NULL THEN
    RETURN -1;
  END IF;
	
  SELECT id INTO pageId FROM page WHERE filename=pageName;
  IF pageId IS NULL THEN
    RETURN -1;
  END IF;

  UPDATE page SET class=typeName, protected='nodelete' WHERE id=pageId;

  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'custom', 'This is the text', NULL);
  
  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'article-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'custom', 'This is the text', NULL);
  
  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'article-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  
  --shop_locator
  
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'shop_locator1', 'This is the text', NULL);
  
  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'article-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  
  -- Article
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, head, text, class)
  VALUES (articleId, langId, 'shop_locator2', 'This is the text', NULL);
  
  -- page_component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'article-component');
  -- page_element_params
  insert into page_component_params (element_id, name, value)
  values (pageElementId, 'id', articleId);
  
  -- contact-book-component
  SELECT nextval('page_component_id_seq') INTO pageElementId;
  insert into page_component (id, page_id, class_name)
  values (pageElementId, pageId, 'contact-book-component');
  
  RETURN 1;
END;
$$;

alter function add_dealer_locator(varchar, varchar) owner to graafprod;

