create function find_category_tree(integer) returns character varying
  language plpgsql
as
$$
DECLARE
  categoryId alias for $1;
  parentCategoryId integer;
  hash varchar;
  parentCatHash varchar;
BEGIN
	hash := '0';
    SELECT order_number,parent_id INTO hash, parentCategoryId 
      	FROM pm_category WHERE id = categoryId;    
    SELECT lpad(hash,3,'0') INTO hash;
    IF(parentCategoryId <> 1) THEN
      SELECT order_number,parent_id INTO hash, parentCategoryId 
      	FROM pm_category WHERE id = categoryId;    
	  SELECT find_category_tree(parentCategoryId) || lpad(hash,3,'0') INTO hash;
    END IF;
	RETURN hash;
END;
$$;

alter function find_category_tree(integer) owner to graafprod;

