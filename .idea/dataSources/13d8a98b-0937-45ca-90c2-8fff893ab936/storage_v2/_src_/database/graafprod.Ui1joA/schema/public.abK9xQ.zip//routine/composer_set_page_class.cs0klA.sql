create function composer_set_page_class(character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
  --
    -- Create standard component
    -- INPUT:
    -- pageName - page name to add component
    -- pageClassName - class name to set for page (if NULL class is not changed)
    --
    -- RETURN:
    -- -1 - page with pageName is not found
    
DECLARE
  pageName alias for $1;
  pageClassName alias for $2;
  protectedValue alias for $3;

  pageRd  RECORD;
BEGIN
  SELECT * INTO pageRd FROM page WHERE filename=pageName;
  IF pageRd.id IS NULL THEN
      RETURN -1;
    END IF;

  UPDATE page SET class=pageClassName, protected=protectedValue WHERE id=pageRd.id;

  RETURN pageRd.id;
END;
$$;

alter function composer_set_page_class(varchar, varchar, varchar) owner to graafprod;

