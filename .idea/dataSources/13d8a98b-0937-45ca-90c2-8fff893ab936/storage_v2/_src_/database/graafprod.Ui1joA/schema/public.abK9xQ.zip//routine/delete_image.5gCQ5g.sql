create function delete_image() returns trigger
  language plpgsql
as
$$
BEGIN
  delete from image where image_id = old.image_id or image_id = old.thumbnail_id;
  RETURN NULL;
END;
$$;

alter function delete_image() owner to graafprod;

