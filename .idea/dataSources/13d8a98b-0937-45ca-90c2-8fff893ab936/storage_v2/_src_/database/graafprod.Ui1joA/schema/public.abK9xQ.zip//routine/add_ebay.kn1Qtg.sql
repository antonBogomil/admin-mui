create function add_ebay() returns integer
  language plpgsql
as
$$
declare
    var_order integer;
    var_pageIdSeq integer;
    var_menuId integer;
begin
    select into var_order max(order_number)+1 from module;
    INSERT INTO module (name, golive, url, order_number) VALUES ('Ebay module', '2005-06-12', '?command=ebay-get-categories-command', var_order);

  begin
       insert into page (lang_id, filename, title, "class", visible) VALUES (1, 'bazaar.html', 'Bazaar', 'ebay', 0);
       insert into page (lang_id, filename, title, "class", visible) VALUES (2, 'bazaarnl.html', 'Bazaar', 'ebay', 0);
    exception
       when unique_violation then
        raise exception 'Can not insert record to a "page". Sequence incorrect?';
  end;
     
    select into var_pageIdSeq last_value from page_id_seq;

    insert into page_element (page_id, table_name, domain_table_record_id, class_name) VALUES (var_pageIdSeq-1, '', 0, 'menu-component');
    insert into page_element (page_id, table_name, domain_table_record_id, class_name) VALUES (var_pageIdSeq, '', 0, 'menu-component');
    insert into page_element (page_id, table_name, domain_table_record_id, class_name) VALUES (var_pageIdSeq-1, '', 0, 'ebay-component');
    insert into page_element (page_id, table_name, domain_table_record_id, class_name) VALUES (var_pageIdSeq, '', 0, 'ebay-component');

  select into var_menuId id from menu where lang_id = 1 and level = 1;
    select into var_order order_ from menu_item where title = 'Products';
    if not found then
       var_order := 1;
    else
       update menu_item set order_ = order_ + 1 where menu_id = var_menuId and order_ > var_order;
       var_order := var_order + 1;
    end if;
    begin
      insert into menu_item (menu_id, title, link, order_, visible) VALUES (var_menuId, 'Bazaar', 'bazaar.html', var_order, 1);
    exception
       when unique_violation then
        raise exception 'Can not insert record to a "menu_item". Sequence incorrect?';
  end;
  select into var_menuId id from menu where lang_id = 2 and level = 1;
    select into var_order order_ from menu_item where title = 'Producten';
    if not found then
       var_order := 1;
    else
       update menu_item set order_ = order_ + 1 where menu_id = var_menuId and order_ > var_order;
       var_order := var_order + 1;
    end if;
    insert into menu_item (menu_id, title, link, order_, visible) VALUES (var_menuId, 'Bazaar', 'bazaarnl.html', var_order, 1);
    
    raise notice 'add_ebay done';
    return 0;
end;
$$;

alter function add_ebay() owner to graafprod;

