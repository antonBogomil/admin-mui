create function create_attribute_from_template(character varying) returns bigint
  strict
  language plpgsql
as
$$
DECLARE
       template_name ALIAS FOR $1;
	   tmp_image_pr_set record;
       tmp_attr record;
       templ record;
       attribute_set record;
       attribute record;
       tmp_image_set record;
       tmp_image record;
       new_image_set_id bigint;
       new_image_id bigint;
       templ_iset_id  bigint;
       new_attribute_set_id  bigint;
BEGIN
     -- get template
     SELECT * INTO templ FROM wcms_attr_template
     WHERE wcms_attr_template.name = template_name;
     IF templ.wcms_templ_id IS NULL THEN
        RETURN NULL;
     END IF;

     -- get attribute_set
     SELECT * INTO attribute_set FROM wcms_attribute_set
     WHERE wcms_attribute_set.wcms_templ_id = templ.wcms_templ_id;
     IF attribute_set.wcms_attribute_set_id IS NULL THEN
        RETURN NULL;
     END IF;
     -- create new (non template) attribute set
     SELECT nextval('wcms_attribute_set_wcms_attribute_set_id_seq')
            INTO new_attribute_set_id;
     INSERT INTO wcms_attribute_set (wcms_attribute_set_id, wcms_templ_id)
     VALUES (new_attribute_set_id, NULL);
     
     -- get attributes
     FOR tmp_attr IN SELECT * FROM wcms_attribute
          WHERE wcms_attribute.wcms_attribute_set_id = attribute_set.wcms_attribute_set_id
     LOOP
         -- get images_set
         SELECT * INTO tmp_image_set FROM images_set
         WHERE images_set.image_set_id = tmp_attr.image_set_id;
         new_image_set_id = NULL;
         IF tmp_image_set.image_set_id IS NOT NULL THEN
            --create new image set
            SELECT nextval('images_set_image_set_id_seq') INTO new_image_set_id;
            INSERT INTO images_set (image_set_id, name, required_width,
            required_height, max_width, max_height, min_width, min_height,
            number_of_images)
            VALUES(new_image_set_id, tmp_image_set.name, tmp_image_set.required_width,
            tmp_image_set.required_height, tmp_image_set.max_width,
            tmp_image_set.max_height, tmp_image_set.min_width, tmp_image_set.min_height,
            tmp_image_set.number_of_images);

			-- get image properties
	        SELECT * INTO tmp_image_pr_set FROM animation_properties
         	WHERE animation_properties.image_set_id = tmp_attr.image_set_id;
            IF tmp_image_pr_set.image_set_id IS NOT NULL THEN
	            --create new image properties			
	            INSERT INTO animation_properties(id, image_set_id, delay, 
	            speed_of_animation, step)
	            VALUES(nextval('animation_properties_id_seq'), new_image_set_id, tmp_image_pr_set.delay, 
	            tmp_image_pr_set.speed_of_animation, tmp_image_pr_set.step);
			END IF;
			
            -- create images
            FOR tmp_image IN SELECT * FROM image
            WHERE image.image_set_id = tmp_image_set.image_set_id
            LOOP
                INSERT INTO image (image_id, image_set_id, src, alt, max_width,
                                   max_height, min_width, min_height,
                                   required_width, required_height, _order)
                VALUES (nextval('image_image_id_seq'), new_image_set_id,
                       tmp_image.src, tmp_image.alt, tmp_image.max_width,
                       tmp_image.max_height, tmp_image.min_width,
                       tmp_image.min_height, tmp_image.required_width,
                       tmp_image.required_height, tmp_image._order);
            END LOOP;
         END IF;

         -- create new attribute
         INSERT INTO wcms_attribute (wcms_attr_id, wcms_attr_type_id,
                name, image_set_id, wcms_attribute_set_id, str_value, class)
         VALUES (nextval('wcms_attribute_wcms_attr_id_seq'),
                tmp_attr.wcms_attr_type_id,
                tmp_attr.name, new_image_set_id,
                new_attribute_set_id,
                tmp_attr.str_value, tmp_attr.class);
     END LOOP;

     RETURN new_attribute_set_id;
     
--     SELECT * FROM wcms_attribute
--     WHERE


END;
$$;

alter function create_attribute_from_template(varchar) owner to graafprod;

