create function add_article_to_page(integer) returns integer
  language plpgsql
as
$$
declare
  pageId alias for $1;
  articleId int4;
begin
    select tpl_create_article(271) into articleId;
    perform tpl_generate_article_by_id(271, articleId);
  return 1;
end;
$$;

alter function add_article_to_page(integer) owner to graafprod;

