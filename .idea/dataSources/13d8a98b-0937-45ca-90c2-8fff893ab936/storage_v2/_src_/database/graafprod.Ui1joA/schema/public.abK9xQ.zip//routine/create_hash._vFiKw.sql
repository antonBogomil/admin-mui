create function create_hash(integer) returns character varying
  language plpgsql
as
$$
DECLARE
 productId alias for $1;
 categoryId int4;
 hash varchar;
 caregoryHash varchar;
BEGIN
 SELECT order_number, category_id INTO hash, categoryId 
 FROM pm_product WHERE id = productId; 
 SELECT find_category_tree(categoryId) INTO caregoryHash;
 SELECT caregoryHash || lpad(hash,3,'0') INTO hash;
 RETURN hash;
END;
$$;

alter function create_hash(integer) owner to graafprod;

