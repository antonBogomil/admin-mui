create view wcms_attr_view as
SELECT wa.wcms_attr_id,
       wa.wcms_attribute_set_id,
       watype.name              AS type_name,
       watype.wcms_attr_type_id AS type_id,
       wa.name                  AS attribute_name,
       wa.str_value,
       wa.class,
       imgset.image_set_id,
       imgset.required_width    AS image_set_req_width,
       imgset.required_height   AS image_set_req_height,
       imgset.max_width         AS image_set_max_width,
       imgset.max_height        AS image_set_max_height,
       imgset.min_width         AS image_set_min_width,
       imgset.min_height        AS image_set_min_height,
       imgset.number_of_images,
       img.image_id             AS img_id,
       img.src                  AS img_src,
       img.alt                  AS img_alt,
       img.max_width            AS img_max_width,
       img.max_height           AS img_max_height,
       img.min_width            AS img_min_width,
       img.min_height           AS img_min_height,
       img.required_width       AS img_req_width,
       img.required_height      AS img_req_height,
       img._order               AS img_order,
       img.link                 AS img_link,
       img.target               AS img_target
FROM wcms_attribute wa,
     images_set imgset,
     wcms_attr_type watype,
     image img
WHERE ((((wa.image_set_id IS NOT NULL) AND (watype.wcms_attr_type_id = wa.wcms_attr_type_id)) AND
        (img.image_set_id = wa.image_set_id)) AND (imgset.image_set_id = wa.image_set_id))
ORDER BY imgset.image_set_id, img._order;

alter table wcms_attr_view
  owner to graafprod;

