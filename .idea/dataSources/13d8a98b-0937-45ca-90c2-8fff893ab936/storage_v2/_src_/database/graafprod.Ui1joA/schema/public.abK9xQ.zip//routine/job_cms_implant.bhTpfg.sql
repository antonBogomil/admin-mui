create function job_cms_implant() returns integer
  language plpgsql
as
$$
declare
    deptId int4 :=1;
    articleId int4 :=1;
    langId int4 :=1;
    vacancyId int4 :=1;
    fieldTypeId int4 :=1;
    stringId int4 :=1;
    templateId int4 :=1;

    ttlTypeId int4 :=1;
    ageTypeId int4 :=1;
    jTechTypeId int4 :=1;
    jobTimeTypeId int4 :=1;
    cityTypeId int4 :=1;
    postcodeTypeId int4 :=1;
    
    fieldId int4 := NULL;

    -- constatnts
  GENERAL_DEPT_ID integer := 1;
  
    genTmp int4 :=1;
    
begin
    -- General department
    INSERT INTO job_departments (id, title, email, description) 
      VALUES (GENERAL_DEPT_ID, 'Company', 'job@negeso.com', 'General company');
    SELECT setval('job_departments_id_seq', GENERAL_DEPT_ID) INTO deptId;

    -- general vacancy
  SELECT nextval('article_id_seq') INTO articleId;
  INSERT INTO article (id, lang_id, text, class)
    VALUES (articleId, langId, 'This is the vacancy text', 'job');
    
  SELECT nextval('job_vacancies_id_seq') INTO vacancyId;
    INSERT INTO job_vacancies (id, title, article_id, position, salary, needed, publish_date, expire_date, department_id) 
      VALUES (vacancyId, 'Sales manager', articleId, 'Team leader', '500', '1', now(), NULL, GENERAL_DEPT_ID);

    -- --------------------------------STANDARD TEMPLATE------------
  SELECT nextval('job_templates_id_seq') INTO templateId;
    INSERT INTO job_templates(id, sys_name) VALUES(templateId, 'job_common_fields');

  -- FIRST NAME
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'First name');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Voornaam');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'first_name', 1);

  -- SECOND NAME
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Surname');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Achternaam');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'second_name', 2);

  -- PHONE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Phone');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Telefoon');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'phone', 3);

  -- MOBILE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Mobile');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Mobiel');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'mobile', 4);

  -- EMAIL
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'email', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Email');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Email');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'email', 5);

  -- BIRTHDAY
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'date', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Date of Birth');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Geboortedatum');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, FALSE, vacancyId, 'birthday', 6);

  -- BIRTH_PLACE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Place of Birth');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Geboorteplaats');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, FALSE, vacancyId, 'birthplace', 7);

  -- CITIZENSHIP
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Citizenship');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Nationaliteit');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, FALSE, vacancyId, 'citizenship', 8);

  -- CV_FILE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'file', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Upload CV');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Upload CV');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, FALSE, vacancyId, 'cv_file', 9);

  -- ADDRESS LINE
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO fieldTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (fieldTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Street address');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Straat + huisnummer');

    INSERT INTO job_extra_fields (type_id, is_required, vacancy_id, sys_name, order_number) 
      VALUES (fieldTypeId, TRUE, vacancyId, 'address_line', 10);

    -- ------------------------------------------------Field types
    -- Post code
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO postcodeTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (postcodeTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Postalcode');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Postcode');

    -- City
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO cityTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (cityTypeId, 'string', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'City');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Stad');

    -- Title
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO ttlTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (ttlTypeId, 'radio_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Gender');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Geslacht');

    -- Mr option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (ttlTypeId, TRUE, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Male');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Man');

    -- Miss option
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (ttlTypeId, FALSE, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Female');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Vrouw');

    -- jobTime
  SELECT nextval('job_strings_id_seq') INTO stringId;
  SELECT nextval('job_field_types_id_seq') INTO jobTimeTypeId;
    INSERT INTO job_field_types (id, type, title_id) 
      VALUES (jobTimeTypeId, 'select_box', stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Job time');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Dienstverband');

    -- Full time
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jobTimeTypeId, FALSE, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Full time');  
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Fulltime');

    -- Half time
  SELECT nextval('job_strings_id_seq') INTO stringId;
    INSERT INTO job_field_options (field_type_id, is_default, title_id) 
      VALUES (jobTimeTypeId, FALSE, stringId);

    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 2, 'Half time');
    INSERT INTO job_strings (id, lang_id, value) VALUES (stringId, 1, 'Parttime');



  SELECT nextval('job_extra_fields_id_seq') INTO fieldId;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id, order_number) 
      VALUES (fieldId, cityTypeId, TRUE, vacancyId, 12);

  SELECT nextval('job_extra_fields_id_seq') INTO fieldId;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id, order_number) 
      VALUES (fieldId, postcodeTypeId, TRUE, vacancyId, 13);

  SELECT nextval('job_extra_fields_id_seq') INTO fieldId;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id, order_number) 
      VALUES (fieldId, ttlTypeId, TRUE, vacancyId, 14);

  SELECT nextval('job_extra_fields_id_seq') INTO fieldId;
    INSERT INTO job_extra_fields (id, type_id, is_required, vacancy_id, order_number) 
      VALUES (fieldId, jTechTypeId, FALSE, vacancyId, 15);

    return 1;
end;
$$;

alter function job_cms_implant() owner to graafprod;

