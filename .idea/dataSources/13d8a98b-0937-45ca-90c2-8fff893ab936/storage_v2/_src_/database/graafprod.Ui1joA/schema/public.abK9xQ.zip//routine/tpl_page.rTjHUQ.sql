create function tpl_page(integer, character varying, character varying) returns integer
  language plpgsql
as
$$
declare
  pageId alias for $1;
  templateStr alias for $2;
  pathInMenu alias for $3;
  template varchar;
  articleId int4;
  listId int4;
  langId int4;
begin
  select lang_id from page where id=pageId into langId;
  template := templateStr;
  IF template = 'special' THEN
  template := 'simple';
  END IF;
  IF template <> 'popup' THEN
    perform tpl_generate_banner(pageId);
  END IF;
  IF template = 'popup' THEN
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
  END IF;
  IF template = 'simple' OR template = 'mail' THEN
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    perform tpl_generate_article_through_by_id(pageId,
    	(SELECT id from article WHERE head='footer' AND lang_id=langId LIMIT 1));
  END IF;
  IF template = 'two_articles' THEN
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
  END IF;
  IF template = 'news_art_pics_li' THEN
    perform tpl_generate_menu(pageId);
    select tpl_create_article(pageId) into articleId;
    perform tpl_generate_article_by_id(pageId, articleId);
    select tpl_create_list(pageId, pathInMenu, 'news_module', 'newslist') into listId;
    perform tpl_generate_list_by_id(pageId, listId);
    perform tpl_generate_list_item_by_id(pageId);
  END IF;
  IF template = 'news_pics_big_li' THEN
    perform tpl_generate_menu(pageId);
    select tpl_create_list(pageId, pathInMenu, 'news_module', 'newslist') into listId;
    perform tpl_generate_list_by_id(pageId, listId);
    perform tpl_generate_list_item_by_id(pageId);
  END IF;
  update page set class = template where id = pageId;
  return 1;
end;
$$;

alter function tpl_page(integer, varchar, varchar) owner to graafprod;

