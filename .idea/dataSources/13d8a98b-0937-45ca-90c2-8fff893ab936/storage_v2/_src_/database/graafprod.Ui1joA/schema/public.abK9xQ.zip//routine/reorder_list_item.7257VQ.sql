create function reorder_list_item() returns trigger
  language plpgsql
as
$$
BEGIN
  UPDATE list_item SET order_number=order_number-1 WHERE list_id = old.list_id AND order_number > old.order_number;
  RETURN NULL;
END;
$$;

alter function reorder_list_item() owner to graafprod;

