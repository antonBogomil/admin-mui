create function add_newslist(character varying, character varying, integer, integer, character varying, character varying) returns integer
  language plpgsql
as
$$
DECLARE
  listTitle alias for $1;
  listType alias for $2;
  imageWidth alias for $3;
  imageHeight alias for $4;
  listPageName alias for $5;
  listItemPageName alias for $6;

  -- constatnts
  LIST_MODULE_ID integer := 1;
  LIST_COMPONENT_NAME varchar := 'list-component';
  LIST_ITEM_COMPONENT_NAME varchar := 'list-item-component';
  LIST_PAGE_CLASS varchar := 'news';
  LIST_ITEM_PAGE_CLASS varchar := 'search_news';

  langId integer := -1;
  listId integer := -1;
  pageElementId integer := -1;
  templateId integer := -1;
  siteId integer := 1;

BEGIN
  SELECT lang_id INTO langId FROM page WHERE filename=listPageName;
  IF langId IS NULL THEN
    RETURN -1;
  END IF;
  
  -- xslt_template
  SELECT id INTO templateId FROM xslt_template WHERE (title = listType) AND (module_id = MODULE_ID);
  IF templateId IS NULL THEN
    -- new list type - create template
    SELECT nextval('xslt_template_id_seq') INTO templateId;
      INSERT INTO xslt_template (id, module_id, title)
      VALUES (templateId, LIST_MODULE_ID, listType)
    ;
  END IF;
  
  -- list
  SELECT nextval('list_id_seq') INTO listId;
    INSERT INTO list (id, name, lang_id, frozen, item_name, image_width, image_height, module_id, instance_name, template_id, site_id)
    VALUES (listId, listTitle, langId, 1, '', imageWidth, imageHeight, LIST_MODULE_ID, listTitle, templateId, siteId)
  ;

  -- add list component
  SELECT add_standard_component(listPageName, LIST_COMPONENT_NAME, LIST_PAGE_CLASS) INTO pageElementId;
  IF pageElementId = -1 THEN
      RETURN -1;
    END IF;
  -- page_component_params
  INSERT INTO page_component_params (element_id, name, value)
    VALUES (pageElementId, 'listId', listId);

  IF listItemPageName IS NOT NULL THEN
    -- add list-item component
    SELECT add_standard_component(listItemPageName, LIST_ITEM_COMPONENT_NAME, LIST_ITEM_PAGE_CLASS) INTO pageElementId;
    IF pageElementId = -1 THEN
        RETURN -2;
      END IF;
  END IF;

  RETURN listId;
END;
$$;

alter function add_newslist(varchar, varchar, integer, integer, varchar, varchar) owner to graafprod;

