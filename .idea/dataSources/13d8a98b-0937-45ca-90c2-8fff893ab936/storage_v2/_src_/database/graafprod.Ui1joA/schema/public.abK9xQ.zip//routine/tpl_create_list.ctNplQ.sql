create function tpl_create_list(integer, character varying, character varying, character varying) returns integer
  language plpgsql
as
$$
declare
    pageId alias for $1;
    listName alias for $2;
    moduleName alias for $3;
    xsltTemplateTitle alias for $4;
    langId int4;
    listId int4;
    moduleId int4;
    xsltTemplateId int4;
begin
    select lang_id into langId from page where id = pageId;
    select id into moduleId from module where name = moduleName;
    select id into xsltTemplateId from xslt_template where title = xsltTemplateTitle;
    select nextval('list_id_seq') into listId;
    insert into list
        (id, name, instance_name, template_id, lang_id, frozen, item_name, module_id) values
        (listId, listName, listName, xsltTemplateId, langId, 1, '', moduleId);
    return listId;
end;
$$;

alter function tpl_create_list(integer, varchar, varchar, varchar) owner to graafprod;

